######################################
#                                    #
#  Code for:                         #
#    Shared friends > shared enemies #
#  Code author:                      #
#    Sara Germain                    #
#  Code contents:                    #
#    Bayesian analysis using JAGS    #
#    Three sensitivity analyses      #
#    Model validation                #
#    Figures and tables              #
#                                    #
######################################


## SET INITIAL CONDITIONS, THEN SOURCE CODE ##

WRITE.INX.MODEL = F  # *** PUBLISHED = T, but run one time only  ***
FINAL.VALIDATIONS = F  # *** PUBLISHED = T, but run one time only  ***

RUN.DENSITY = F # *** PUBLISHED = T in Appendix S1 only ***
RUN.MODEL = F # *** PUBLISHED = T in Appendix S1 only ***

INCLUDE.BOTH = T # include species capable of both AM and EM   *** PUBLISHED = T  ***
INCLUDE.ERICOID = T # include species forming ericoid mycorrhizae   *** PUBLISHED = T  ***

AMvEM = F # *** PUBLISHED = T in Appendix S1 only ***

RUN.SA1=F # *** PUBLISHED = T in Appendix S1 only ***
RUN.SA2=F # *** PUBLISHED = T in Appendix S1 only ***
RUN.SA3=F # *** PUBLISHED = T in Appendix S1 only ***

guild_designations<-read.csv("./Data_Setup/Raw_Data/guild_designations.csv",na.strings='NULL')
guild_designations$SPECIES <- as.character(guild_designations$SPECIES)
guild_designations$GUILD <- as.character(guild_designations$GUILD)

##########################################################################################################-
#########################################         LIBFUN        ##########################################-
#----------------------------------------------------------------------------------------------------------

# library(WILD6900)
library(verification)
library(grid)
library(gridExtra)
library(cowplot)
library(MASS)
library(scales)
library(ROCR)
library(PresenceAbsence)
library(stringr)
library(ggplot2)

loadRData <- function(fileName){   #loads an RData file, and returns it
  load(fileName)
  get(ls()[ls() != "fileName"])
}

base_breaks <- function(n = 10){
  function(x) {
    axisTicks(log10(range(x, na.rm = TRUE)), log = TRUE, n = n)
  }
}

BA.function = function(tree.DBH){
  return(0.0001*(pi*((0.5*tree.DBH)^2)))
} # BA in square meters

class.sum=function(truth,predicted){
  xt=table(truth,round(predicted+0.000001))
  pcc=round(100*sum(diag(xt))/sum(xt),2)
  spec=round(100*xt[1,1]/sum(xt[1,]),2)
  sens=round(100*xt[2,2]/sum(xt[2,]),2)
  kap=round(kappa(xt)[1],4)
  au=round(roc.area(truth,predicted)$A,4)
  return(cbind(c("Percent Correctly Classified = ","Specificity = ","Sensitivity = ","Kappa =","AUC= "),c(pcc,spec,sens,kap,au)))
}

theme_prefs <- theme_classic() + theme(axis.title.x = element_text(size=10),
                                       axis.title.y = element_text(size=10),
                                       axis.text.x = element_text(size=10, colour='black'),
                                       axis.text.y = element_text(size=10, colour='black'),
                                       axis.ticks = element_line(colour='black'),
                                       legend.text = element_text(size=8),
                                       legend.title = element_text(size=8),
                                       plot.title=element_text(size=12,hjust=0.5, vjust=-3))

##########################################################################################################

##########################################################################################################-
########################################       MODEL SETUP      ##########################################-
#----------------------------------------------------------------------------------------------------------

if(WRITE.INX.MODEL==T){
  sink("Jags/Code/tree_mod_BIG_hegyirich_INX.jags")
  cat("
      model{
      # Priors
      for(q in 1:nplots){
      beta0[q] ~ dnorm(mu, tau)  ## intercept: logit of expected survival probability per [random] plot
      }
      mu ~ dnorm(0, 1) 
      sd ~ dunif(0, 1) ## use gamma or unif if need pos numbers only (but unif needs upper bound)
      tau <- 1 / (sd * sd) 
      
      beta1 ~ dnorm(0, 0.33)
      beta2 ~ dnorm(0, 0.33)
      beta3 ~ dnorm(0, 0.33)
      beta4 ~ dnorm(0, 0.33)  
      beta5 ~ dnorm(0, 0.33)
      beta6 ~ dnorm(0, 0.33)
      beta7 ~ dnorm(0, 0.33)

      # Likelihood
      for (i in 1:ntrees){
      survival[i] ~ dbern(prob[i])
      logit(prob[i]) <- beta0[plots[i]] + beta1 * param[i,1] + beta2 * param[i,2] + beta3 * param[i,3] + beta4 * param[i,4] + beta5 * param[i,5] + beta6 * param[i,2] * param[i,4] + beta7 * param[i,3] * param[i,5]
      }  #i
      } # end of model
      ", fill = TRUE)
  sink()
}

##########################################################################################################

##########################################################################################################-
########################################         ANALYSIS       ##########################################-
#----------------------------------------------------------------------------------------------------------

if(RUN.MODEL==T){
  for(m in c(5,10,15,20)){ # neighborhood radii considered
    for(x in c('ericoidDIFF.bothDIFF','ericoidSAME.bothDIFF','ericoidDIFF.bothSAME','ericoidSAME.bothSAME')){ # species guild assignments considered
      for(DBH.quant in c(0.1,0.9, 1)){ # diameter quantiles considered, where 0.1 = small only, 0.9 = large only, and '1' indicates all diameters
        rm(final.datt)
        final.datt <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.20200928.Rdata', sep = '')) # final.datt *** PUBLISHED = .20200928.Rdata  ***
        
        if(RUN.DENSITY==T){
        density <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep = '')) # final.datt *** PUBLISHED in Appendix S1 = .DENSITYonly.20201020.Rdata  ***
        final.datt <- merge(final.datt,density[,c("ID",grep(paste('den.cons.',m,sep = ''),colnames(density),value=T,fixed=T),
                                                grep(paste('den.diff.',m,sep = ''),colnames(density),value=T,fixed=T),
                                                grep(paste('den.same.',m,sep = ''),colnames(density),value=T,fixed=T))],by=c('ID'))
        
        }
        
        ##########################################################################################################-
        #########################################       DATA SETUP      ##########################################-
        #----------------------------------------------------------------------------------------------------------
        
        min.num <-2 # minimum number of subsetted individuals necessary to be included in analyses
        
        ### ---------------------- SUBSET TREES BY DIAMETER ---------------------- ###
        {
          final.datt$REAL_DBH <- exp(final.datt$DBH)
          
          ## set threshold per plot / species
          species <- aggregate(final.datt$ID,by=list(final.datt$PLOT,final.datt$SPECIES),FUN=nrow)
          species$QUANT <-NA
          species<-species[,-3]
          
          for(i in 1:nrow(species)){ # shows the DBH at the given quantile
            species[i,'QUANT'] <- quantile(final.datt[final.datt$SPECIES == species[i,'Group.2'] &
                                                        final.datt$PLOT == species[i,'Group.1'],'REAL_DBH'],DBH.quant)
          }
          species<-species[order(species$Group.1),]
          
          final.datt$SUB <- NA
          for(i in 1:nrow(final.datt)){
            
            ifelse(DBH.quant == 1,
                   final.datt[i,'SUB'] <- 1, 
                   ifelse(DBH.quant > 0.5,
                          final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] >= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                              species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0), 
                          final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] <= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                              species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0)) )
          }
          
          subset.all <- final.datt[final.datt$SUB==1,]
        }
        
        ### ---------------------- SUBSET TREES BY SPECIES ---------------------- ###
        {
          
          if(AMvEM==T){
            
            subset.tree <- subset.all[subset.all$SPECIES %in% c('PIPO','PILO','ABBI','PIFL','PIPU','PIEN','PSME.G','PIED','ABCO','TSHE','ABAM','PSME.M','ABPR','ABGR','PIMO','PILA','ABMA'),] ## EM species
            subset.shrub <- subset.all[subset.all$SPECIES %in% c('JUSC','TABR','THPL','CADE'),] ## AM spp
            
          } else {
            
            subset.tree <- subset.all[subset.all$SPECIES %in% c('PIPO','PILO','ABBI','PIFL','PIPU','PIEN','PSME.G','PIED','JUSC','ABCO','TSHE','ABAM','TABR','PSME.M','ABPR','ABGR','THPL','PIMO','PILA','CADE','ABMA'),] # trees aka single-stem, non-vegetatively reproducing spp
            
            if(INCLUDE.BOTH==F & INCLUDE.ERICOID==F){
              subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD %in% c('ericoid','both'),'SPECIES']),]
              
            } else if(INCLUDE.BOTH==F & INCLUDE.ERICOID==T){
              subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='both','SPECIES']),]
              
            } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==F){
              subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='ericoid','SPECIES']),]
              
            } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==T){
              subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES),]
            }
          }
          
          subset.all$SPECIES_NUM <- as.numeric(as.factor(subset.all$SPECIES))
          subset.tree$SPECIES_NUM <- as.numeric(as.factor(subset.tree$SPECIES))
          subset.shrub$SPECIES_NUM <- as.numeric(as.factor(subset.shrub$SPECIES))
          
          subset.all$BA <- BA.function(subset.all$REAL_DBH)
          subset.tree$BA <- BA.function(subset.tree$REAL_DBH)
          subset.shrub$BA <- BA.function(subset.shrub$REAL_DBH)
          
        }
        
        ### ---------------------- SUBSET TREES BY min.num ---------------------- ###
        {
          all.summary <- aggregate(subset.all$STEM_TAG, by=list(subset.all$PLOT,subset.all$SPECIES), FUN=NROW)
          tree.summary <- aggregate(subset.tree$STEM_TAG, by=list(subset.tree$PLOT,subset.tree$SPECIES), FUN=NROW)
          shrub.summary <- aggregate(subset.shrub$STEM_TAG, by=list(subset.shrub$PLOT,subset.shrub$SPECIES), FUN=NROW)
          
          plenty.all <- all.summary[all.summary$x >= min.num,]
          plenty.tree <- tree.summary[tree.summary$x >= min.num,]
          plenty.shrub <- shrub.summary[shrub.summary$x >= min.num,]
          
          subset.all$keep <- ifelse(subset.all$PLOT==1 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==1,'Group.2']), 1,
                                    ifelse(subset.all$PLOT==2 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==2,'Group.2']), 1,
                                           ifelse(subset.all$PLOT==3 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==3,'Group.2']), 1,0)))
          subset.all <- subset.all[subset.all$keep == 1,] 
          
          subset.tree$keep <- ifelse(subset.tree$PLOT==1 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==1,'Group.2']), 1,
                                     ifelse(subset.tree$PLOT==2 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==2,'Group.2']), 1,
                                            ifelse(subset.tree$PLOT==3 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==3,'Group.2']), 1,0)))
          subset.tree <- subset.tree[subset.tree$keep == 1,]                                     
          
          subset.shrub$keep <- ifelse(subset.shrub$PLOT==1 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==1,'Group.2']), 1,
                                      ifelse(subset.shrub$PLOT==2 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==2,'Group.2']), 1,
                                             ifelse(subset.shrub$PLOT==3 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==3,'Group.2']), 1,0)))
          subset.shrub <- subset.shrub[subset.shrub$keep == 1,]                                
          
        }
        
        
        ##########################################################################################################
        
        ##########################################################################################################-
        ########################################        RUN MODELS      ##########################################-
        #----------------------------------------------------------------------------------------------------------
        
        if(RUN.MODEL==T){
          for(g in c('all','tree','shrub')){
            
            anal.datt <- eval(parse(text= paste('subset.', g, sep = '')))   # choose which dataset to use for analysis
            
            ##########################################################################################################-
            #########################################       PARAMETERIZE      ##########################################-
            #----------------------------------------------------------------------------------------------------------
            
            ## covariates
            trees <- anal.datt$ID 
            plots <- anal.datt$PLOT
            
            if(RUN.DENSITY==T){
              cons <- anal.datt[,grep(paste('den.cons.',m,sep = ''), colnames(anal.datt), fixed = TRUE, value = TRUE)]
              het.s <- anal.datt[,grep(paste('den.same.',m,sep = ''), colnames(anal.datt), fixed = TRUE, value = TRUE)]
              het.d <- anal.datt[,grep(paste('den.diff.',m,sep = ''), colnames(anal.datt), fixed = TRUE, value = TRUE)]
            } else {
              cons <- anal.datt[,grep('con.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
              het.s <- anal.datt[,grep('het.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
              het.d <- anal.datt[,grep('het.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
            }
            
            rich.s <- anal.datt[,grep('rich.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
            rich.d <- anal.datt[,grep('rich.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
            
            param <- as.matrix(cbind(cons,het.s,het.d,rich.s,rich.d))
            
            survival <- anal.datt$DA
            survival <- ifelse(survival==1,0,1)
            
            ##########################################################################################################
            
            ##########################################################################################################-
            #########################################       RUN MODELS      ##########################################-
            #----------------------------------------------------------------------------------------------------------
            
            jags_data <- list(survival = survival, plots = plots, param = param,
                              ntrees = length(trees), nplots = length(unique(plots))) 
            
            track.params <- c("beta0", "beta1", "beta2", "beta3", "beta4", "beta5", "beta6", "beta7")
            
            nC <- 5
            nI <- 20000
            nB <- 3000
            nT <- 1
            
            hegyirich_INX_model <- jagsUI::jags(data = jags_data,
                                                parameters.to.save = track.params, 
                                                model.file = "Jags/Code/tree_mod_BIG_hegyirich_INX.jags", 
                                                n.chains = nC, n.iter = nI, 
                                                n.burnin = nB, n.thin = nT, parallel = TRUE)
            
           if(AMvEM==T){
             g <- ifelse(g == 'tree','EM','AM')
           }
             # save(hegyirich_INX_model, file = paste('Jags/Output/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,'quant_noB_noE.Rdata', sep = '')) #used
            save(hegyirich_INX_model, file = paste('Jags/Output.AMvEM/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,'quant.Rdata', sep = '')) #used
            
            ##########################################################################################################
            
            rm(hegyirich_INX_model)
            rm(jags_data)
            rm(anal.datt)
            rm(survival)
            rm(param)    
          }
        } # end analysis per dataset permutation
        
        
      }
    }
  } # end all
}

##########################################################################################################

##########################################################################################################-
###################################        SA1: AUC COMPARISON       #####################################-
#----------------------------------------------------------------------------------------------------------

### HEGYI ###
if(RUN.SA1==T){
### ---------------------- AUC Comparison ---------------------- ###

AUC.table <- as.data.frame(matrix(ncol = 3, nrow = length(dir('Jags/Output.SA1.Hegyi/'))))
colnames(AUC.table) <- c('model', 'AUC','DIC')

for(a in 1:nrow(AUC.table)){
  print( paste('Now on: ', a, ' of ',length(dir('Jags/Output.SA1.Hegyi/')), sep = '' ))
  
  #### SET PARAMETERS FOR DATA SETUP ####
  d = dir('Jags/Output.SA1.Hegyi/')[a]
  
  INCLUDE.BOTH <- ifelse(str_detect(d, 'noB')==T, FALSE, TRUE)
  INCLUDE.ERICOID <- ifelse(str_detect(d, 'noE')==T, FALSE, TRUE)
  
  g <- ifelse(str_detect(d, 'all')==T, 'all',
              ifelse(str_detect(d, 'tree')==T, 'tree', 'shrub'))
  x <- ifelse(str_detect(d, 'ericoidDIFF.bothDIFF')==T, 'ericoidDIFF.bothDIFF',
              ifelse(str_detect(d,'ericoidSAME.bothDIFF')==T, 'ericoidSAME.bothDIFF', 
                     ifelse(str_detect(d,'ericoidDIFF.bothSAME')==T, 'ericoidDIFF.bothSAME', 'ericoidSAME.bothSAME')))
  m <- ifelse(str_detect(d, '_5m')==T, 5,
              ifelse(str_detect(d, '_10m')==T, 10,
                     ifelse(str_detect(d, '_15m')==T, 15, 20)))
  DBH.quant <- ifelse(str_detect(d, '_0.1quant')==T, 0.1,
                      ifelse(str_detect(d, '_0.9quant')==T, 0.9,1))
  
  print( paste(g,'_',x,'_',m,'m_',DBH.quant,'quant :   Both = ', INCLUDE.BOTH, ', Ericoid = ', INCLUDE.ERICOID, sep = '') )
  
  ##########################################################################################################-
  #########################################       DATA SETUP      ##########################################-
  #----------------------------------------------------------------------------------------------------------
  
  #### GET DATA ####
  final.datt <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.20200928.Rdata', sep = '')) # final.datt # *** PUBLISHED = .20200928.Rdata ***
  
  min.num <-2 # minimum number of subsetted individuals necessary to be included in analyses
  
  ### ---------------------- SUBSET TREES BY DIAMETER ---------------------- ###
  {
    final.datt$REAL_DBH <- exp(final.datt$DBH)
    
    ## set threshold per plot / species
    species <- aggregate(final.datt$ID,by=list(final.datt$PLOT,final.datt$SPECIES),FUN=nrow)
    species$QUANT <-NA
    species<-species[,-3]
    
    for(i in 1:nrow(species)){ # shows the DBH at the given quantile
      species[i,'QUANT'] <- quantile(final.datt[final.datt$SPECIES == species[i,'Group.2'] &
                                                  final.datt$PLOT == species[i,'Group.1'],'REAL_DBH'],DBH.quant)
    }
    species<-species[order(species$Group.1),]
    
    final.datt$SUB <- NA
    for(i in 1:nrow(final.datt)){
      
      ifelse(DBH.quant == 1,
             final.datt[i,'SUB'] <- 1, 
             ifelse(DBH.quant > 0.5,
                    final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] >= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                        species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0), 
                    final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] <= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                        species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0)) )
    }
    
    subset.all <- final.datt[final.datt$SUB==1,]
  }
  
  ### ---------------------- SUBSET TREES BY SPECIES ---------------------- ###
  {
    subset.tree <- subset.all[subset.all$SPECIES %in% c('PIPO','PILO','ABBI','PIFL','PIPU','PIEN','PSME.G','PIED','JUSC','ABCO','TSHE','ABAM','TABR','PSME.M','ABPR','ABGR','THPL','PIMO','PILA','CADE','ABMA'),] # trees aka single-stem, non-vegetatively reproducing spp
    
    if(INCLUDE.BOTH==F & INCLUDE.ERICOID==F){
      subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD %in% c('ericoid','both'),'SPECIES']),]
      
    } else if(INCLUDE.BOTH==F & INCLUDE.ERICOID==T){
      subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='both','SPECIES']),]
      
    } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==F){
      subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='ericoid','SPECIES']),]
      
    } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==T){
      subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES),]
    }
    
    subset.all$SPECIES_NUM <- as.numeric(as.factor(subset.all$SPECIES))
    subset.tree$SPECIES_NUM <- as.numeric(as.factor(subset.tree$SPECIES))
    subset.shrub$SPECIES_NUM <- as.numeric(as.factor(subset.shrub$SPECIES))
    
    subset.all$BA <- BA.function(subset.all$REAL_DBH)
    subset.tree$BA <- BA.function(subset.tree$REAL_DBH)
    subset.shrub$BA <- BA.function(subset.shrub$REAL_DBH)
  }
  
  ### ---------------------- SUBSET TREES BY min.num ---------------------- ###
  {
    all.summary <- aggregate(subset.all$STEM_TAG, by=list(subset.all$PLOT,subset.all$SPECIES), FUN=NROW)
    tree.summary <- aggregate(subset.tree$STEM_TAG, by=list(subset.tree$PLOT,subset.tree$SPECIES), FUN=NROW)
    shrub.summary <- aggregate(subset.shrub$STEM_TAG, by=list(subset.shrub$PLOT,subset.shrub$SPECIES), FUN=NROW)
    
    plenty.all <- all.summary[all.summary$x >= min.num,]
    plenty.tree <- tree.summary[tree.summary$x >= min.num,]
    plenty.shrub <- shrub.summary[shrub.summary$x >= min.num,]
    
    subset.all$keep <- ifelse(subset.all$PLOT==1 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==1,'Group.2']), 1,
                              ifelse(subset.all$PLOT==2 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==2,'Group.2']), 1,
                                     ifelse(subset.all$PLOT==3 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==3,'Group.2']), 1,0)))
    subset.all <- subset.all[subset.all$keep == 1,] 
    
    subset.tree$keep <- ifelse(subset.tree$PLOT==1 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==1,'Group.2']), 1,
                               ifelse(subset.tree$PLOT==2 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==2,'Group.2']), 1,
                                      ifelse(subset.tree$PLOT==3 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==3,'Group.2']), 1,0)))
    subset.tree <- subset.tree[subset.tree$keep == 1,]                                     
    
    subset.shrub$keep <- ifelse(subset.shrub$PLOT==1 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==1,'Group.2']), 1,
                                ifelse(subset.shrub$PLOT==2 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==2,'Group.2']), 1,
                                       ifelse(subset.shrub$PLOT==3 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==3,'Group.2']), 1,0)))
    subset.shrub <- subset.shrub[subset.shrub$keep == 1,]                                
    
  }
  
  ##########################################################################################################
  
  #### GET MODELS ####
  model <-loadRData(paste('Jags/Output.SA1.Hegyi/',d,sep=''))
  output <- as.data.frame(model$summary)
  output <- output[-nrow(output),]
  
  ## covariates
  anal.datt <- eval(parse(text = paste('subset',g,sep='.')))
  plots <- anal.datt$PLOT
  
  cons <- anal.datt[,grep('con.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  het.s <- anal.datt[,grep('het.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  het.d <- anal.datt[,grep('het.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  rich.s <- anal.datt[,grep('rich.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  rich.d <- anal.datt[,grep('rich.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  
  param <- as.matrix(cbind(cons,het.s,het.d,rich.s,rich.d))
  
  survival <- anal.datt$DA
  survival <- ifelse(survival==1,0,1)
  
  # linear model: use estimated betas to calculate survival probability / classification
  Xmat <- model.matrix(~as.factor(plots) + cons + het.s + het.d + rich.s + rich.d + (het.s*rich.s) + (het.d*rich.d) - 1) # with interaction 
  prob <- plogis(Xmat %*% output$mean)
  
  #create auc.roc plot
  ObsPred <- data.frame(survival, Predicted=prob)
  ObsPred$ID <- anal.datt$STEM_TAG
  ObsPred <- ObsPred[,c(3,1,2)]
  
  AUC <- roc.area(ObsPred[,2], ObsPred[,3])$A
  AUC.table[a,'AUC'] <- AUC
  AUC.table[a,'DIC'] <- model$DIC
  AUC.table[a,'model'] <- paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
  
  
  rm(final.datt)
  rm(anal.datt)
  rm(model)
  rm(output)
  rm(AUC)
  rm(ObsPred)
}

AUC.table <- AUC.table[order(AUC.table$model),]
AUC.table$AUC <- round (AUC.table$AUC, 4)
# save(AUC.table,file = 'Tables/AUC_comparison_432models.Rdata')


### ---------------------- Best of AUC Comparison ---------------------- ###
### the following data frames are pasted into the excel table created for the SI, "Model_Comparison"

treesDF.all <- AUC.table[AUC.table$model %in% grep('tree_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('_1quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(treesDF.all, file = 'Tables/AUC_comparison_tree_All.csv', row.names = F)

treesDF.big <- AUC.table[AUC.table$model %in% grep('tree_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('0.9quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(treesDF.big, file = 'Tables/AUC_comparison_tree_Big.csv', row.names = F)

treesDF.small <- AUC.table[AUC.table$model %in% grep('tree_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('0.1quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(treesDF.small, file = 'Tables/AUC_comparison_tree_Small.csv', row.names = F)


shrubDF.all <- AUC.table[AUC.table$model %in% grep('shrub_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('_1quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(shrubDF.all, file = 'Tables/AUC_comparison_shrub_All.csv', row.names = F)

shrubDF.big <- AUC.table[AUC.table$model %in% grep('shrub_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('0.9quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(shrubDF.big, file = 'Tables/AUC_comparison_shrub_Big.csv', row.names = F)

shrubDF.small <- AUC.table[AUC.table$model %in% grep('shrub_', AUC.table$model, value = T, fixed = T) &
                             AUC.table$model %in% grep('0.1quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(shrubDF.small, file = 'Tables/AUC_comparison_shrub_Small.csv', row.names = F)


allDF.all <- AUC.table[AUC.table$model %in% grep('all_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('_1quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(allDF.all, file = 'Tables/AUC_comparison_all_All.csv', row.names = F)

allDF.big <- AUC.table[AUC.table$model %in% grep('all_', AUC.table$model, value = T, fixed = T) &
                           AUC.table$model %in% grep('0.9quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(allDF.big, file = 'Tables/AUC_comparison_all_Big.csv', row.names = F)

allDF.small <- AUC.table[AUC.table$model %in% grep('all_', AUC.table$model, value = T, fixed = T) &
                             AUC.table$model %in% grep('0.1quant', AUC.table$model, value = T, fixed = T), ]
# write.csv(allDF.small, file = 'Tables/AUC_comparison_all_Small.csv', row.names = F)
}


### DENSITY ###
if(RUN.SA1==T){
  ### ---------------------- AUC Comparison ---------------------- ###
  
  AUC.table.DEN <- as.data.frame(matrix(ncol = 3, nrow = length(dir('Jags/Output.SA1.Density/'))))
  colnames(AUC.table.DEN) <- c('model', 'AUC.den','DIC.den')
  
  for(a in 1:nrow(AUC.table.DEN)){
    print( paste('Now on: ', a, ' of ',length(dir('Jags/Output.SA1.Density/')), sep = '' ))
    
    #### SET PARAMETERS FOR DATA SETUP ####
    d = dir('Jags/Output.SA1.Density/')[a]
    
    INCLUDE.BOTH <- ifelse(str_detect(d, 'noB')==T, FALSE, TRUE)
    INCLUDE.ERICOID <- ifelse(str_detect(d, 'noE')==T, FALSE, TRUE)
    
    g <- ifelse(str_detect(d, 'all')==T, 'all',
                ifelse(str_detect(d, 'tree')==T, 'tree', 'shrub'))
    x <- ifelse(str_detect(d, 'ericoidDIFF.bothDIFF')==T, 'ericoidDIFF.bothDIFF',
                ifelse(str_detect(d,'ericoidSAME.bothDIFF')==T, 'ericoidSAME.bothDIFF', 
                       ifelse(str_detect(d,'ericoidDIFF.bothSAME')==T, 'ericoidDIFF.bothSAME', 'ericoidSAME.bothSAME')))
    m <- ifelse(str_detect(d, '_5m')==T, 5,
                ifelse(str_detect(d, '_10m')==T, 10,
                       ifelse(str_detect(d, '_15m')==T, 15, 20)))
    DBH.quant <- ifelse(str_detect(d, '_0.1quant')==T, 0.1,
                        ifelse(str_detect(d, '_0.9quant')==T, 0.9,1))
    
    print( paste(g,'_',x,'_',m,'m_',DBH.quant,'quant :   Both = ', INCLUDE.BOTH, ', Ericoid = ', INCLUDE.ERICOID, sep = '') )
    
    ##########################################################################################################-
    #########################################       DATA SETUP      ##########################################-
    #----------------------------------------------------------------------------------------------------------
    
    #### GET DATA ####-
    final.datt <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.20200928.Rdata', sep = '')) # final.datt  # *** PUBLISHED = .20200928.Rdata ***
    
    density <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep = '')) # final.datt # *** PUBLISHED in Appendix S1 = .DENSITYonly.20201020.Rdata ***
    final.datt <- merge(final.datt,density[,c("ID",grep(paste('den.cons.',m,sep = ''),colnames(density),value=T,fixed=T),
                                              grep(paste('den.diff.',m,sep = ''),colnames(density),value=T,fixed=T),
                                              grep(paste('den.same.',m,sep = ''),colnames(density),value=T,fixed=T))],by=c('ID'))
    
    min.num <-2 # minimum number of subsetted individuals necessary to be included in analyses
    
    ### ---------------------- SUBSET TREES BY DIAMETER ---------------------- ###
    {
      final.datt$REAL_DBH <- exp(final.datt$DBH)
      
      ## set threshold per plot / species
      species <- aggregate(final.datt$ID,by=list(final.datt$PLOT,final.datt$SPECIES),FUN=nrow)
      species$QUANT <-NA
      species<-species[,-3]
      
      for(i in 1:nrow(species)){ # shows the DBH at the given quantile
        species[i,'QUANT'] <- quantile(final.datt[final.datt$SPECIES == species[i,'Group.2'] &
                                                    final.datt$PLOT == species[i,'Group.1'],'REAL_DBH'],DBH.quant)
      }
      species<-species[order(species$Group.1),]
      
      final.datt$SUB <- NA
      for(i in 1:nrow(final.datt)){
        
        ifelse(DBH.quant == 1,
               final.datt[i,'SUB'] <- 1, 
               ifelse(DBH.quant > 0.5,
                      final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] >= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                          species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0), 
                      final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] <= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                          species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0)) )
      }
      
      subset.all <- final.datt[final.datt$SUB==1,]
    }
    
    ### ---------------------- SUBSET TREES BY SPECIES ---------------------- ###
    {
      subset.tree <- subset.all[subset.all$SPECIES %in% c('PIPO','PILO','ABBI','PIFL','PIPU','PIEN','PSME.G','PIED','JUSC','ABCO','TSHE','ABAM','TABR','PSME.M','ABPR','ABGR','THPL','PIMO','PILA','CADE','ABMA'),] # trees aka single-stem, non-vegetatively reproducing spp
      
      if(INCLUDE.BOTH==F & INCLUDE.ERICOID==F){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD %in% c('ericoid','both'),'SPECIES']),]
        
      } else if(INCLUDE.BOTH==F & INCLUDE.ERICOID==T){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='both','SPECIES']),]
        
      } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==F){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='ericoid','SPECIES']),]
        
      } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==T){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES),]
      }
      
      subset.all$SPECIES_NUM <- as.numeric(as.factor(subset.all$SPECIES))
      subset.tree$SPECIES_NUM <- as.numeric(as.factor(subset.tree$SPECIES))
      subset.shrub$SPECIES_NUM <- as.numeric(as.factor(subset.shrub$SPECIES))
      
      subset.all$BA <- BA.function(subset.all$REAL_DBH)
      subset.tree$BA <- BA.function(subset.tree$REAL_DBH)
      subset.shrub$BA <- BA.function(subset.shrub$REAL_DBH)
    }
    
    ### ---------------------- SUBSET TREES BY min.num ---------------------- ###
    {
      all.summary <- aggregate(subset.all$STEM_TAG, by=list(subset.all$PLOT,subset.all$SPECIES), FUN=NROW)
      tree.summary <- aggregate(subset.tree$STEM_TAG, by=list(subset.tree$PLOT,subset.tree$SPECIES), FUN=NROW)
      shrub.summary <- aggregate(subset.shrub$STEM_TAG, by=list(subset.shrub$PLOT,subset.shrub$SPECIES), FUN=NROW)
      
      plenty.all <- all.summary[all.summary$x >= min.num,]
      plenty.tree <- tree.summary[tree.summary$x >= min.num,]
      plenty.shrub <- shrub.summary[shrub.summary$x >= min.num,]
      
      subset.all$keep <- ifelse(subset.all$PLOT==1 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==1,'Group.2']), 1,
                                ifelse(subset.all$PLOT==2 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==2,'Group.2']), 1,
                                       ifelse(subset.all$PLOT==3 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==3,'Group.2']), 1,0)))
      subset.all <- subset.all[subset.all$keep == 1,] 
      
      subset.tree$keep <- ifelse(subset.tree$PLOT==1 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==1,'Group.2']), 1,
                                 ifelse(subset.tree$PLOT==2 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==2,'Group.2']), 1,
                                        ifelse(subset.tree$PLOT==3 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==3,'Group.2']), 1,0)))
      subset.tree <- subset.tree[subset.tree$keep == 1,]                                     
      
      subset.shrub$keep <- ifelse(subset.shrub$PLOT==1 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==1,'Group.2']), 1,
                                  ifelse(subset.shrub$PLOT==2 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==2,'Group.2']), 1,
                                         ifelse(subset.shrub$PLOT==3 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==3,'Group.2']), 1,0)))
      subset.shrub <- subset.shrub[subset.shrub$keep == 1,]                                
      
    }
    
    ##########################################################################################################
    
    #### GET MODELS ####
    model <-loadRData(paste('Jags/Output.SA1.Density/',d,sep=''))
    output <- as.data.frame(model$summary)
    output <- output[-nrow(output),]
    
    ## covariates
    anal.datt <- eval(parse(text = paste('subset',g,sep='.')))
    plots <- anal.datt$PLOT
    
    cons <- anal.datt[,grep(paste('den.cons.',m,sep = ''), colnames(anal.datt), fixed = TRUE, value = TRUE)]
    het.s <- anal.datt[,grep(paste('den.same.',m,sep = ''), colnames(anal.datt), fixed = TRUE, value = TRUE)]
    het.d <- anal.datt[,grep(paste('den.diff.',m,sep = ''), colnames(anal.datt), fixed = TRUE, value = TRUE)]
    rich.s <- anal.datt[,grep('rich.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    rich.d <- anal.datt[,grep('rich.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    
    param <- as.matrix(cbind(cons,het.s,het.d,rich.s,rich.d))
    
    survival <- anal.datt$DA
    survival <- ifelse(survival==1,0,1)
    
    # linear model: use estimated betas to calculate survival probability / classification
    Xmat <- model.matrix(~as.factor(plots) + cons + het.s + het.d + rich.s + rich.d + (het.s*rich.s) + (het.d*rich.d) - 1) # with interaction 
    prob <- plogis(Xmat %*% output$mean)
    
    #create auc.roc plot
    ObsPred <- data.frame(survival, Predicted=prob)
    ObsPred$ID <- anal.datt$STEM_TAG
    ObsPred <- ObsPred[,c(3,1,2)]
    
    AUC <- roc.area(ObsPred[,2], ObsPred[,3])$A
    AUC.table.DEN[a,'AUC.den'] <- AUC
    AUC.table.DEN[a,'DIC.den'] <- model$DIC
    AUC.table.DEN[a,'model'] <- paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
    
    rm(final.datt)
    rm(anal.datt)
    rm(model)
    rm(output)
    rm(AUC)
    rm(ObsPred)
  }
  
  AUC.table.DEN <- AUC.table.DEN[order(AUC.table.DEN$model),]
  AUC.table.DEN$AUC <- round (AUC.table.DEN$AUC, 4)
  # save(AUC.table.DEN,file = 'Tables/AUC_comparison_144models_DENSITYonly.Rdata')
  # write.csv(AUC.table.DEN, file = 'Tables/AUC_comparison_144models_DENSITYonly.csv', row.names = F)
  

  
  ### ---------------------- Best of AUC Comparison ---------------------- ###
  ### the following data frames are pasted into the excel table created for the SI, "Model_Comparison"
  
  treesDF.all.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('tree_', AUC.table.DEN$model, value = T, fixed = T) &
                             AUC.table.DEN$model %in% grep('_1quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(treesDF.all, file = 'Tables/AUC_comparison_tree_All.csv', row.names = F)
  
  treesDF.big.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('tree_', AUC.table.DEN$model, value = T, fixed = T) &
                             AUC.table.DEN$model %in% grep('0.9quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(treesDF.big, file = 'Tables/AUC_comparison_tree_Big.csv', row.names = F)
  
  treesDF.small.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('tree_', AUC.table.DEN$model, value = T, fixed = T) &
                               AUC.table.DEN$model %in% grep('0.1quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(treesDF.small, file = 'Tables/AUC_comparison_tree_Small.csv', row.names = F)
  
  
  shrubDF.all.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('shrub_', AUC.table.DEN$model, value = T, fixed = T) &
                             AUC.table.DEN$model %in% grep('_1quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(shrubDF.all, file = 'Tables/AUC_comparison_shrub_All.csv', row.names = F)
  
  shrubDF.big.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('shrub_', AUC.table.DEN$model, value = T, fixed = T) &
                             AUC.table.DEN$model %in% grep('0.9quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(shrubDF.big, file = 'Tables/AUC_comparison_shrub_Big.csv', row.names = F)
  
  shrubDF.small.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('shrub_', AUC.table.DEN$model, value = T, fixed = T) &
                               AUC.table.DEN$model %in% grep('0.1quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(shrubDF.small, file = 'Tables/AUC_comparison_shrub_Small.csv', row.names = F)
  
  
  allDF.all.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('all_', AUC.table.DEN$model, value = T, fixed = T) &
                           AUC.table.DEN$model %in% grep('_1quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(allDF.all, file = 'Tables/AUC_comparison_all_All.csv', row.names = F)
  
  allDF.big.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('all_', AUC.table.DEN$model, value = T, fixed = T) &
                           AUC.table.DEN$model %in% grep('0.9quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(allDF.big, file = 'Tables/AUC_comparison_all_Big.csv', row.names = F)
  
  allDF.small.DEN <- AUC.table.DEN[AUC.table.DEN$model %in% grep('all_', AUC.table.DEN$model, value = T, fixed = T) &
                             AUC.table.DEN$model %in% grep('0.1quant', AUC.table.DEN$model, value = T, fixed = T), ]
  # write.csv(allDF.small, file = 'Tables/AUC_comparison_all_Small.csv', row.names = F)
}


### COMPARE BOTH ###
if(RUN.SA1==T){
  
  final.AUC.table <- merge(AUC.table,AUC.table.DEN,by='model')
  
  final.AUC.table$AUC.best <- ifelse(final.AUC.table$AUC.den>final.AUC.table$AUC,
                                 'density','hegyi')
  final.AUC.table$AUC.difference <- final.AUC.table$AUC - final.AUC.table$AUC.den
  
  final.AUC.table$DIC.best <- ifelse(final.AUC.table$DIC.den<final.AUC.table$DIC,
                                     'density','hegyi')
  final.AUC.table$DIC.difference <- final.AUC.table$DIC - final.AUC.table$DIC.den
  
  nrow(final.AUC.table[final.AUC.table$AUC.best=='density',])
  nrow(final.AUC.table[final.AUC.table$AUC.best=='hegyi',])
  
  nrow(final.AUC.table[final.AUC.table$DIC.best=='density',])
  nrow(final.AUC.table[final.AUC.table$DIC.best=='hegyi',])
  
  summary(final.AUC.table$AUC.difference)
  summary(final.AUC.table$DIC.difference)
  

  ###############-
  
  
  treesDF.all.final <- final.AUC.table[final.AUC.table$model %in% grep('tree_', final.AUC.table$model, value = T, fixed = T) &
                                     final.AUC.table$model %in% grep('_1quant', final.AUC.table$model, value = T, fixed = T), ]

  treesDF.big.final <- final.AUC.table[final.AUC.table$model %in% grep('tree_', final.AUC.table$model, value = T, fixed = T) &
                                     final.AUC.table$model %in% grep('0.9quant', final.AUC.table$model, value = T, fixed = T), ]

  treesDF.small.final <- final.AUC.table[final.AUC.table$model %in% grep('tree_', final.AUC.table$model, value = T, fixed = T) &
                                       final.AUC.table$model %in% grep('0.1quant', final.AUC.table$model, value = T, fixed = T), ]

  shrubDF.all.final <- final.AUC.table[final.AUC.table$model %in% grep('shrub_', final.AUC.table$model, value = T, fixed = T) &
                                     final.AUC.table$model %in% grep('_1quant', final.AUC.table$model, value = T, fixed = T), ]

  shrubDF.big.final <- final.AUC.table[final.AUC.table$model %in% grep('shrub_', final.AUC.table$model, value = T, fixed = T) &
                                     final.AUC.table$model %in% grep('0.9quant', final.AUC.table$model, value = T, fixed = T), ]

  shrubDF.small.final <- final.AUC.table[final.AUC.table$model %in% grep('shrub_', final.AUC.table$model, value = T, fixed = T) &
                                       final.AUC.table$model %in% grep('0.1quant', final.AUC.table$model, value = T, fixed = T), ]
  
  allDF.all.final <- final.AUC.table[final.AUC.table$model %in% grep('all_', final.AUC.table$model, value = T, fixed = T) &
                                   final.AUC.table$model %in% grep('_1quant', final.AUC.table$model, value = T, fixed = T), ]

  allDF.big.final <- final.AUC.table[final.AUC.table$model %in% grep('all_', final.AUC.table$model, value = T, fixed = T) &
                                   final.AUC.table$model %in% grep('0.9quant', final.AUC.table$model, value = T, fixed = T), ]

  allDF.small.final <- final.AUC.table[final.AUC.table$model %in% grep('all_', final.AUC.table$model, value = T, fixed = T) &
                                     final.AUC.table$model %in% grep('0.1quant', final.AUC.table$model, value = T, fixed = T), ]
  
  ###############-
  
  
  nrow(treesDF.big.final[treesDF.big.final$AUC.best=='density',])
  nrow(treesDF.big.final[treesDF.big.final$AUC.best=='hegyi',])
  
  nrow(treesDF.big.final[treesDF.big.final$DIC.best=='density',])
  nrow(treesDF.big.final[treesDF.big.final$DIC.best=='hegyi',])

  summary(treesDF.big.final$AUC.difference)
  summary(treesDF.big.final$DIC.difference)

  treesDF.big.final[treesDF.big.final$DIC == min(treesDF.big.final$DIC), 'model']
 
  
  ###############-
  
 a = NA
  for(m in c('_5',10,15,20)){ # neighborhood radii considered
    aa <- treesDF.big.final[treesDF.big.final$model %in% grep(paste(m,'m_',sep=''), treesDF.big.final$model, value = T, fixed = T) &
                             treesDF.big.final$model %in% grep('', treesDF.big.final$model, value = T, fixed = T), ] ### can enter x in here to specify guild designations
    a <- rbind(a,aa)
  }
  
 b = NA
 for(m in c('_5',10,15,20)){ # neighborhood radii considered
   bb <- treesDF.small.final[treesDF.small.final$model %in% grep(paste(m,'m_',sep=''), treesDF.small.final$model, value = T, fixed = T) &
                               treesDF.small.final$model %in% grep('', treesDF.small.final$model, value = T, fixed = T), ] ### can enter x in here to specify guild designations
   b <- rbind(b,bb)
 }
  
 c = NA
  for(m in c('_5',10,15,20)){ # neighborhood radii considered
    cc <- shrubDF.big.final[shrubDF.big.final$model %in% grep(paste(m,'m_',sep=''), shrubDF.big.final$model, value = T, fixed = T) &
                               shrubDF.big.final$model %in% grep('', shrubDF.big.final$model, value = T, fixed = T), ] ### can enter x in here to specify guild designations
    c <- rbind(c,cc)
  }
  
 d = NA
  for(m in c('_5',10,15,20)){ # neighborhood radii considered
   dd <- shrubDF.small.final[shrubDF.small.final$model %in% grep(paste(m,'m_',sep=''), shrubDF.small.final$model, value = T, fixed = T) &
                                 shrubDF.small.final$model %in% grep('', shrubDF.small.final$model, value = T, fixed = T), ] ### can enter x in here to specify guild designations
    d <- rbind(d,dd)
  }
  
 e = NA
 for(m in c('_5',10,15,20)){ # neighborhood radii considered
   ee <- allDF.big.final[allDF.big.final$model %in% grep(paste(m,'m_',sep=''), allDF.big.final$model, value = T, fixed = T) &
                            allDF.big.final$model %in% grep('', allDF.big.final$model, value = T, fixed = T), ] ### can enter x in here to specify guild designations
   e <- rbind(e,ee)
 }
 
 f = NA
 for(m in c('_5',10,15,20)){ # neighborhood radii considered
   ff <- allDF.small.final[allDF.small.final$model %in% grep(paste(m,'m_',sep=''), allDF.small.final$model, value = T, fixed = T) &
                            allDF.small.final$model %in% grep('', allDF.small.final$model, value = T, fixed = T), ] ### can enter x in here to specify guild designations
   f <- rbind(f,ff)
 }
 
 # write.csv(rbind(e,f,a,b,c,d) , file = 'Tables/Den.Heg.288models.comparison.csv')
 
 }


##########################################################################################################

##########################################################################################################-
##################################      SA2: PARAMETER COMPARISON       ##################################-
#----------------------------------------------------------------------------------------------------------

### HEGYI ###
if(RUN.SA2==T){
#---------------------### SET PARAMETERS ###--------------------------#
### allow SA1 to inform how we will handle guild designations and species inclusion
## specify what parameters were chosen based on AUC comparison
x <- 'ericoidDIFF.bothDIFF' 
INCLUDE.BOTH = T
INCLUDE.ERICOID = T

if(INCLUDE.BOTH == T & INCLUDE.ERICOID == T){
  included <- 'quant.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == T){
    included <- 'quant_noB.Rdata'} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == F){
      included <- 'quant_noE.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == F){included <- 'quant_noB_noE.Rdata'}

### ---------------------- Interaction Parameters Comparison Table ---------------------- ###
### use this SA2 to inform neighborhood radii 
PARAM.table <- NA
for(m in c(5,10,15,20)){
  for(DBH.quant in c(0.1,0.9,1)){
    for(g in c('all','tree','shrub')){
      rm(output)
      
      output <- loadRData(file = paste('Jags/Output/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
      output <- as.data.frame(output$summary)
      output <- output[-nrow(output),]
      
      model <- paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
      same <- output[rownames(output)=='beta6','mean']
      same.signif <- output[rownames(output)=='beta6','overlap0']
      diff <- output[rownames(output)=='beta7','mean']
      diff.signif <- output[rownames(output)=='beta7','overlap0']

      all <- cbind( model, same, same.signif, diff, diff.signif )
      
      PARAM.table <- rbind( PARAM.table, all)
    }
  }
}

PARAM.table <- as.data.frame(PARAM.table)
PARAM.table <- PARAM.table[-1,]

PARAM.table[2:5] <- apply(PARAM.table[2:5], 2, FUN = as.numeric )

PARAM.table <- PARAM.table[order(PARAM.table$model),]
PARAM.table[c(2,4)] <- apply(PARAM.table[c(2,4)], 2, FUN = function(x) {round(x, 5)} )
PARAM.table[c(3,5)] <- apply(PARAM.table[c(3,5)], 2, FUN = function(x) {ifelse(x==0,'yes','no')} )
# save(PARAM.table,file = 'Tables/PARAM_comparison_36models.Rdata')
# write.csv(PARAM.table,file = 'Tables/PARAM_comparison_36models.csv', row.names = F)

# load(file = 'Tables/PARAM_comparison_36models.Rdata')


###############################################################-
#################       VISUALIZATIONS      ###################-
#--------------------------------------------------------------#
{
# get param.table in right format
{
  
  PARAM.list.shrub.large <- list()
  PARAM.list.tree.large <- list()
  PARAM.list.all.large <- list()
  PARAM.list.shrub.small <- list()
  PARAM.list.tree.small <- list()
  PARAM.list.all.small <- list()
  
  for(m in c(5,10,15,20)){
    for(DBH.quant in c(0.1,0.9)){
      for(g in c('all','tree','shrub')){
        
        print(paste('Now on model : radius=', m, ', DBH=', DBH.quant,', ' , g, sep =''))
        rm(output)
        
        output <- loadRData(file = paste('Jags/Output/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
        output <- as.data.frame(output$summary)
        output <- output[-nrow(output),c("mean","2.5%","97.5%")]
        
        name<-paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
        
        if(DBH.quant == 0.1){
          if(g == 'all'){
            PARAM.list.all.small[[name]] <- output
          } else if(g == 'tree'){
            PARAM.list.tree.small[[name]] <- output
          } else if(g == 'shrub'){
            PARAM.list.shrub.small[[name]] <- output
          }
        }
        
        if(DBH.quant == 0.9){
          if(g == 'all'){
            PARAM.list.all.large[[name]] <- output
          } else if(g == 'tree'){
            PARAM.list.tree.large[[name]] <- output
          } else if(g == 'shrub'){
            PARAM.list.shrub.large[[name]] <- output
          }
        }
        
        
      }
    }
  }
  
  ### make concise tables
  {
    PARAM.matrix.all.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.all.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.all.large[[1]])), c("2.5%","97.5%"))))
    PARAM.matrix.all.large[,1] <- apply(sapply(PARAM.list.all.large, `[[`, "2.5%"), 1, min)
    PARAM.matrix.all.large[,2] <- apply(sapply(PARAM.list.all.large, `[[`, "97.5%"), 1, max)
    PARAM.matrix.all.large$mean <- apply(PARAM.matrix.all.large, 1, FUN = mean)
    
    PARAM.matrix.tree.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.tree.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.tree.large[[1]])), c("2.5%","97.5%"))))
    PARAM.matrix.tree.large[,1] <- apply(sapply(PARAM.list.tree.large, `[[`, "2.5%"), 1, min)
    PARAM.matrix.tree.large[,2] <- apply(sapply(PARAM.list.tree.large, `[[`, "97.5%"), 1, max)
    PARAM.matrix.tree.large$mean <- apply(PARAM.matrix.tree.large, 1, FUN = mean)
    
    PARAM.matrix.shrub.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.shrub.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.shrub.large[[1]])), c("2.5%","97.5%"))))
    PARAM.matrix.shrub.large[,1] <- apply(sapply(PARAM.list.shrub.large, `[[`, "2.5%"), 1, min)
    PARAM.matrix.shrub.large[,2] <- apply(sapply(PARAM.list.shrub.large, `[[`, "97.5%"), 1, max)
    PARAM.matrix.shrub.large$mean <- apply(PARAM.matrix.shrub.large, 1, FUN = mean)
    
    ###
    
    PARAM.matrix.all.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.all.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.all.small[[1]])), c("2.5%","97.5%"))))
    PARAM.matrix.all.small[,1] <- apply(sapply(PARAM.list.all.small, `[[`, "2.5%"), 1, min)
    PARAM.matrix.all.small[,2] <- apply(sapply(PARAM.list.all.small, `[[`, "97.5%"), 1, max)
    PARAM.matrix.all.small$mean <- apply(PARAM.matrix.all.small, 1, FUN = mean)
    
    PARAM.matrix.tree.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.tree.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.tree.small[[1]])), c("2.5%","97.5%"))))
    PARAM.matrix.tree.small[,1] <- apply(sapply(PARAM.list.tree.small, `[[`, "2.5%"), 1, min)
    PARAM.matrix.tree.small[,2] <- apply(sapply(PARAM.list.tree.small, `[[`, "97.5%"), 1, max)
    PARAM.matrix.tree.small$mean <- apply(PARAM.matrix.tree.small, 1, FUN = mean)
    
    PARAM.matrix.shrub.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.shrub.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.shrub.small[[1]])), c("2.5%","97.5%"))))
    PARAM.matrix.shrub.small[,1] <- apply(sapply(PARAM.list.shrub.small, `[[`, "2.5%"), 1, min)
    PARAM.matrix.shrub.small[,2] <- apply(sapply(PARAM.list.shrub.small, `[[`, "97.5%"), 1, max)
    PARAM.matrix.shrub.small$mean <- apply(PARAM.matrix.shrub.small, 1, FUN = mean)
  }
}

plot.names <- c('Wind River, WA','Yosemite, CA','Cedar Breaks, UT')
param.names <- c('Conspecifics','Heterospecifics: Shared','Heterospecifics: Different','Richness: Shared','Richness: Different', 'Interaction: Shared', 'Interaction: Different')
plots <- c(1,2,3)

# all parameters
{
  output.tree.large <- PARAM.matrix.tree.large
  output.tree.small <- PARAM.matrix.tree.small
  output.shrub.large <- PARAM.matrix.shrub.large
  output.shrub.small <- PARAM.matrix.shrub.small
  
  output.tree.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.tree.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.shrub.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.shrub.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  
  output.tree.large$names=as.numeric(output.tree.large$names) - 0.15
  output.shrub.small$names=as.numeric(output.shrub.small$names) - 0.30
  output.shrub.large$names=as.numeric(output.shrub.large$names) - 0.45
  
  output.tree.small$color <- 'green'
  output.tree.large$color <- 'blue'
  output.shrub.small$color <- 'orange'
  output.shrub.large$color <- 'red'
  
  output.tree.small$signif <- ifelse(output.tree.small$`97.5%` <= 0 & output.tree.small$`2.5%` <=0, 21,
                                     ifelse(output.tree.small$`97.5%` >= 0 & output.tree.small$`2.5%` >=0, 21, 1))
  output.tree.large$signif <- ifelse(output.tree.large$`97.5%` <= 0 & output.tree.large$`2.5%` <=0, 21,
                                     ifelse(output.tree.large$`97.5%` >= 0 & output.tree.large$`2.5%` >=0, 21, 1))
  output.shrub.small$signif <- ifelse(output.shrub.small$`97.5%` <= 0 & output.shrub.small$`2.5%` <=0, 21,
                                      ifelse(output.shrub.small$`97.5%` >= 0 & output.shrub.small$`2.5%` >=0, 21, 1))
  output.shrub.large$signif <- ifelse(output.shrub.large$`97.5%` <= 0 & output.shrub.large$`2.5%` <=0, 21,
                                      ifelse(output.shrub.large$`97.5%` >= 0 & output.shrub.large$`2.5%` >=0, 21, 1))
  
  output.tree.small$oddsmean <- exp(output.tree.small$mean)
  output.tree.large$oddsmean <- exp(output.tree.large$mean)
  output.tree.small$oddslo <- exp(output.tree.small$`2.5%`)
  output.tree.large$oddslo <- exp(output.tree.large$`2.5%`)
  output.tree.small$oddshi <- exp(output.tree.small$`97.5%`)
  output.tree.large$oddshi <- exp(output.tree.large$`97.5%`)
  
  output.shrub.small$oddsmean <- exp(output.shrub.small$mean)
  output.shrub.large$oddsmean <- exp(output.shrub.large$mean)
  output.shrub.small$oddslo <- exp(output.shrub.small$`2.5%`)
  output.shrub.large$oddslo <- exp(output.shrub.large$`2.5%`)
  output.shrub.small$oddshi <- exp(output.shrub.small$`97.5%`)
  output.shrub.large$oddshi <- exp(output.shrub.large$`97.5%`)
  
  ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  
  tree.large$names=factor(param.names, levels = param.names)
  tree.small$names=factor(param.names, levels = param.names)
  shrub.large$names=factor(param.names, levels = param.names)
  shrub.small$names=factor(param.names, levels = param.names)
  
  tree.large$names=as.numeric(tree.large$names)-0.15
  shrub.small$names=as.numeric(shrub.small$names)-0.30
  shrub.large$names=as.numeric(shrub.large$names)-0.45
  
  ggplot(data=tree.small, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=tree.small, color = tree.small$color, fill = tree.small$color, shape = tree.small$signif) + 
    geom_errorbarh(data=tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=tree.large, color = tree.large$color, fill = tree.large$color, shape = tree.large$signif) + 
    geom_errorbarh(data=tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=shrub.small, color = shrub.small$color, fill = shrub.small$color, shape = shrub.small$signif) + 
    geom_errorbarh(data=shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=shrub.large, color = shrub.large$color, fill = shrub.large$color, shape = shrub.large$signif) + 
    geom_errorbarh(data=shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
  
  ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  plots.tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  
  plots.tree.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.tree.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.shrub.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.shrub.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  
  plots.tree.large$names=as.numeric(plots.tree.large$names)-0.15
  plots.shrub.small$names=as.numeric(plots.shrub.small$names)-0.30
  plots.shrub.large$names=as.numeric(plots.shrub.large$names)-0.45
  
  ggplot(data=plots.tree.small, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=plots.tree.small, color = plots.tree.small$color, fill = plots.tree.small$color, shape = plots.tree.small$signif) + 
    geom_errorbarh(data=plots.tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.tree.large, color = plots.tree.large$color, fill = plots.tree.large$color, shape = plots.tree.large$signif) + 
    geom_errorbarh(data=plots.tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.shrub.small, color = plots.shrub.small$color, fill = plots.shrub.small$color, shape = plots.shrub.small$signif) + 
    geom_errorbarh(data=plots.shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.shrub.large, color = plots.shrub.large$color, fill = plots.shrub.large$color, shape = plots.shrub.large$signif) + 
    geom_errorbarh(data=plots.shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
} 


# all parameters, big and small combined
{

  output.all.all <- PARAM.matrix.all
  output.tree.all <- PARAM.matrix.tree
  output.shrub.all <- PARAM.matrix.shrub
  
  output.tree.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.shrub.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.all.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  
  output.tree.all$names=as.numeric(output.tree.all$names) - 0.15
  output.shrub.all$names=as.numeric(output.shrub.all$names) - 0.30
  
  output.tree.all$color <- 'blue'
  output.shrub.all$color <- 'red'
  output.all.all$color <- 'black'
  
  output.tree.all$signif <- ifelse(output.tree.all$`97.5%` <= 0 & output.tree.all$`2.5%` <=0, 21,
                                   ifelse(output.tree.all$`97.5%` >= 0 & output.tree.all$`2.5%` >=0, 21, 1))
  output.shrub.all$signif <- ifelse(output.shrub.all$`97.5%` <= 0 & output.shrub.all$`2.5%` <=0, 21,
                                    ifelse(output.shrub.all$`97.5%` >= 0 & output.shrub.all$`2.5%` >=0, 21, 1))
  output.all.all$signif <- ifelse(output.all.all$`97.5%` <= 0 & output.all.all$`2.5%` <=0, 21,
                                  ifelse(output.all.all$`97.5%` >= 0 & output.all.all$`2.5%` >=0, 21, 1))
  
  output.all.all$oddsmean <- exp(output.all.all$mean)
  output.all.all$oddslo <- exp(output.all.all$`2.5%`)
  output.all.all$oddshi <- exp(output.all.all$`97.5%`)
  
  output.tree.all$oddsmean <- exp(output.tree.all$mean)
  output.tree.all$oddslo <- exp(output.tree.all$`2.5%`)
  output.tree.all$oddshi <- exp(output.tree.all$`97.5%`)
  
  output.shrub.all$oddsmean <- exp(output.shrub.all$mean)
  output.shrub.all$oddslo <- exp(output.shrub.all$`2.5%`)
  output.shrub.all$oddshi <- exp(output.shrub.all$`97.5%`)
  
  
  ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  all.all <- output.all.all[rownames(output.all.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  
  all.all$names=factor(param.names, levels = param.names)
  tree.all$names=factor(param.names, levels = param.names)
  shrub.all$names=factor(param.names, levels = param.names)
  
  tree.all$names=as.numeric(tree.all$names)-0.15
  shrub.all$names=as.numeric(shrub.all$names)-0.30
  
  ggplot(data=all.all, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=all.all, color = all.all$color, fill = all.all$color, shape = all.all$signif) + 
    geom_errorbarh(data=all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=tree.all, color = tree.all$color, fill = tree.all$color, shape = tree.all$signif) + 
    geom_errorbarh(data=tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=shrub.all, color = shrub.all$color, fill = shrub.all$color, shape = shrub.all$signif) + 
    geom_errorbarh(data=shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_alldiams_allspp_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
  
  ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  plots.all.all <- output.all.all[rownames(output.all.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  
  plots.all.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.tree.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.shrub.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  
  plots.tree.all$names=as.numeric(plots.tree.all$names)-0.15
  plots.shrub.all$names=as.numeric(plots.shrub.all$names)-0.30
  
  ggplot(data=plots.tree.all, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=plots.all.all, color = plots.all.all$color, fill = plots.all.all$color, shape = plots.all.all$signif) + 
    geom_errorbarh(data=plots.all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.tree.all, color = plots.tree.all$color, fill = plots.tree.all$color, shape = plots.tree.all$signif) + 
    geom_errorbarh(data=plots.tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.shrub.all, color = plots.shrub.all$color, fill = plots.shrub.all$color, shape = plots.shrub.all$signif) + 
    geom_errorbarh(data=plots.shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_alldiams_allspp_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
} 
}

}


### DENSITY ###
if(RUN.SA2==T){
  #---------------------### SET PARAMETERS ###--------------------------#
  ### allow SA1 to inform how we will handle guild designations and species inclusion
  ## specify what parameters were chosen based on AUC comparison
  x <- 'ericoidDIFF.bothDIFF'
  INCLUDE.BOTH = T
  INCLUDE.ERICOID = T
  
  if(INCLUDE.BOTH == T & INCLUDE.ERICOID == T){
    included <- 'quant_DENSITYonly.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == T){
      included <- 'quant_DENSITYonly_noB.Rdata'} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == F){
        included <- 'quant_DENSITYonly_noE.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == F){included <- 'quant_DENSITYonly_noB_noE.Rdata'}
  
  ### ---------------------- Interaction Parameters Comparison Table ---------------------- ###
  ### use this SA2 to inform neighborhood radii 
  PARAM.table <- NA
  for(m in c(5,10,15,20)){
    for(DBH.quant in c(0.1,0.9,1)){
      for(g in c('all','tree','shrub')){
        rm(output)
        
        output <-loadRData(paste('Jags/Output.SA1.Density/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
        output <- as.data.frame(output$summary)
        output <- output[-nrow(output),]
        
        model <- paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
        same <- output[rownames(output)=='beta6','mean']
        same.signif <- output[rownames(output)=='beta6','overlap0']
        diff <- output[rownames(output)=='beta7','mean']
        diff.signif <- output[rownames(output)=='beta7','overlap0']
        
        all <- cbind( model, same, same.signif, diff, diff.signif )
        
        PARAM.table <- rbind( PARAM.table, all)
      }
    }
  }
  
  PARAM.table <- as.data.frame(PARAM.table)
  PARAM.table <- PARAM.table[-1,]
  
  PARAM.table[2:5] <- apply(PARAM.table[2:5], 2, FUN = as.numeric )
  
  PARAM.table <- PARAM.table[order(PARAM.table$model),]
  PARAM.table[c(2,4)] <- apply(PARAM.table[c(2,4)], 2, FUN = function(x) {round(x, 5)} )
  PARAM.table[c(3,5)] <- apply(PARAM.table[c(3,5)], 2, FUN = function(x) {ifelse(x==0,'yes','no')} )
  # save(PARAM.table,file = 'Tables/PARAM_comparison_36models.Rdata')
  # write.csv(PARAM.table,file = 'Tables/PARAM_comparison_36models.csv', row.names = F)
  
  # load(file = 'Tables/PARAM_comparison_36models.Rdata')
  
  
  ###############################################################-
  #################       VISUALIZATIONS      ###################-
  #--------------------------------------------------------------#
  {
    # get param.table in right format
    {
      
      PARAM.list.shrub.large <- list()
      PARAM.list.tree.large <- list()
      PARAM.list.all.large <- list()
      PARAM.list.shrub.small <- list()
      PARAM.list.tree.small <- list()
      PARAM.list.all.small <- list()
      
      for(m in c(5,10,15,20)){
        for(DBH.quant in c(0.1,0.9)){
          for(g in c('all','tree','shrub')){
            
            print(paste('Now on model : radius=', m, ', DBH=', DBH.quant,', ' , g, sep =''))
            rm(output)
            
            output <- loadRData(file = paste('Jags/Output.SA1.Hegyi/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
            output <- as.data.frame(output$summary)
            output <- output[-nrow(output),c("mean","2.5%","97.5%")]
            
            name<-paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
            
            if(DBH.quant == 0.1){
              if(g == 'all'){
                PARAM.list.all.small[[name]] <- output
              } else if(g == 'tree'){
                PARAM.list.tree.small[[name]] <- output
              } else if(g == 'shrub'){
                PARAM.list.shrub.small[[name]] <- output
              }
            }
            
            if(DBH.quant == 0.9){
              if(g == 'all'){
                PARAM.list.all.large[[name]] <- output
              } else if(g == 'tree'){
                PARAM.list.tree.large[[name]] <- output
              } else if(g == 'shrub'){
                PARAM.list.shrub.large[[name]] <- output
              }
            }
            
            
          }
        }
      }
      
      ### make concise tables
      {
        PARAM.matrix.all.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.all.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.all.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.all.large[,1] <- apply(sapply(PARAM.list.all.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.all.large[,2] <- apply(sapply(PARAM.list.all.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.all.large$mean <- apply(PARAM.matrix.all.large, 1, FUN = mean)
        
        PARAM.matrix.tree.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.tree.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.tree.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.tree.large[,1] <- apply(sapply(PARAM.list.tree.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.tree.large[,2] <- apply(sapply(PARAM.list.tree.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.tree.large$mean <- apply(PARAM.matrix.tree.large, 1, FUN = mean)
        
        PARAM.matrix.shrub.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.shrub.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.shrub.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.shrub.large[,1] <- apply(sapply(PARAM.list.shrub.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.shrub.large[,2] <- apply(sapply(PARAM.list.shrub.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.shrub.large$mean <- apply(PARAM.matrix.shrub.large, 1, FUN = mean)
        
        ###
        
        PARAM.matrix.all.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.all.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.all.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.all.small[,1] <- apply(sapply(PARAM.list.all.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.all.small[,2] <- apply(sapply(PARAM.list.all.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.all.small$mean <- apply(PARAM.matrix.all.small, 1, FUN = mean)
        
        PARAM.matrix.tree.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.tree.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.tree.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.tree.small[,1] <- apply(sapply(PARAM.list.tree.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.tree.small[,2] <- apply(sapply(PARAM.list.tree.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.tree.small$mean <- apply(PARAM.matrix.tree.small, 1, FUN = mean)
        
        PARAM.matrix.shrub.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.shrub.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.shrub.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.shrub.small[,1] <- apply(sapply(PARAM.list.shrub.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.shrub.small[,2] <- apply(sapply(PARAM.list.shrub.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.shrub.small$mean <- apply(PARAM.matrix.shrub.small, 1, FUN = mean)
      }
    }
    
    plot.names <- c('Wind River, WA','Yosemite, CA','Cedar Breaks, UT')
    param.names <- c('Conspecifics','Heterospecifics: Shared','Heterospecifics: Different','Richness: Shared','Richness: Different', 'Interaction: Shared', 'Interaction: Different')
    plots <- c(1,2,3)
    
    # all parameters
    {
      output.tree.large <- PARAM.matrix.tree.large
      output.tree.small <- PARAM.matrix.tree.small
      output.shrub.large <- PARAM.matrix.shrub.large
      output.shrub.small <- PARAM.matrix.shrub.small
      
      output.tree.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.tree.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.shrub.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.shrub.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      
      output.tree.large$names=as.numeric(output.tree.large$names) - 0.15
      output.shrub.small$names=as.numeric(output.shrub.small$names) - 0.30
      output.shrub.large$names=as.numeric(output.shrub.large$names) - 0.45
      
      output.tree.small$color <- 'green'
      output.tree.large$color <- 'blue'
      output.shrub.small$color <- 'orange'
      output.shrub.large$color <- 'red'
      
      output.tree.small$signif <- ifelse(output.tree.small$`97.5%` <= 0 & output.tree.small$`2.5%` <=0, 21,
                                         ifelse(output.tree.small$`97.5%` >= 0 & output.tree.small$`2.5%` >=0, 21, 1))
      output.tree.large$signif <- ifelse(output.tree.large$`97.5%` <= 0 & output.tree.large$`2.5%` <=0, 21,
                                         ifelse(output.tree.large$`97.5%` >= 0 & output.tree.large$`2.5%` >=0, 21, 1))
      output.shrub.small$signif <- ifelse(output.shrub.small$`97.5%` <= 0 & output.shrub.small$`2.5%` <=0, 21,
                                          ifelse(output.shrub.small$`97.5%` >= 0 & output.shrub.small$`2.5%` >=0, 21, 1))
      output.shrub.large$signif <- ifelse(output.shrub.large$`97.5%` <= 0 & output.shrub.large$`2.5%` <=0, 21,
                                          ifelse(output.shrub.large$`97.5%` >= 0 & output.shrub.large$`2.5%` >=0, 21, 1))
      
      output.tree.small$oddsmean <- exp(output.tree.small$mean)
      output.tree.large$oddsmean <- exp(output.tree.large$mean)
      output.tree.small$oddslo <- exp(output.tree.small$`2.5%`)
      output.tree.large$oddslo <- exp(output.tree.large$`2.5%`)
      output.tree.small$oddshi <- exp(output.tree.small$`97.5%`)
      output.tree.large$oddshi <- exp(output.tree.large$`97.5%`)
      
      output.shrub.small$oddsmean <- exp(output.shrub.small$mean)
      output.shrub.large$oddsmean <- exp(output.shrub.large$mean)
      output.shrub.small$oddslo <- exp(output.shrub.small$`2.5%`)
      output.shrub.large$oddslo <- exp(output.shrub.large$`2.5%`)
      output.shrub.small$oddshi <- exp(output.shrub.small$`97.5%`)
      output.shrub.large$oddshi <- exp(output.shrub.large$`97.5%`)
      
      ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      
      tree.large$names=factor(param.names, levels = param.names)
      tree.small$names=factor(param.names, levels = param.names)
      shrub.large$names=factor(param.names, levels = param.names)
      shrub.small$names=factor(param.names, levels = param.names)
      
      tree.large$names=as.numeric(tree.large$names)-0.15
      shrub.small$names=as.numeric(shrub.small$names)-0.30
      shrub.large$names=as.numeric(shrub.large$names)-0.45
      
      ggplot(data=tree.small, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=tree.small, color = tree.small$color, fill = tree.small$color, shape = tree.small$signif) + 
        geom_errorbarh(data=tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=tree.large, color = tree.large$color, fill = tree.large$color, shape = tree.large$signif) + 
        geom_errorbarh(data=tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=shrub.small, color = shrub.small$color, fill = shrub.small$color, shape = shrub.small$signif) + 
        geom_errorbarh(data=shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=shrub.large, color = shrub.large$color, fill = shrub.large$color, shape = shrub.large$signif) + 
        geom_errorbarh(data=shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_oddsratio_fixed_DENSITY.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
      
      ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      plots.tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      
      plots.tree.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.tree.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.shrub.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.shrub.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      
      plots.tree.large$names=as.numeric(plots.tree.large$names)-0.15
      plots.shrub.small$names=as.numeric(plots.shrub.small$names)-0.30
      plots.shrub.large$names=as.numeric(plots.shrub.large$names)-0.45
      
      ggplot(data=plots.tree.small, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=plots.tree.small, color = plots.tree.small$color, fill = plots.tree.small$color, shape = plots.tree.small$signif) + 
        geom_errorbarh(data=plots.tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.tree.large, color = plots.tree.large$color, fill = plots.tree.large$color, shape = plots.tree.large$signif) + 
        geom_errorbarh(data=plots.tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.shrub.small, color = plots.shrub.small$color, fill = plots.shrub.small$color, shape = plots.shrub.small$signif) + 
        geom_errorbarh(data=plots.shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.shrub.large, color = plots.shrub.large$color, fill = plots.shrub.large$color, shape = plots.shrub.large$signif) + 
        geom_errorbarh(data=plots.shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_oddsratio_random_DENSITY.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
    } 
    
    
    # all parameters, big and small combined
    {
      
      output.all.all <- PARAM.matrix.all
      output.tree.all <- PARAM.matrix.tree
      output.shrub.all <- PARAM.matrix.shrub
      
      output.tree.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.shrub.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.all.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      
      output.tree.all$names=as.numeric(output.tree.all$names) - 0.15
      output.shrub.all$names=as.numeric(output.shrub.all$names) - 0.30
      
      output.tree.all$color <- 'blue'
      output.shrub.all$color <- 'red'
      output.all.all$color <- 'black'
      
      output.tree.all$signif <- ifelse(output.tree.all$`97.5%` <= 0 & output.tree.all$`2.5%` <=0, 21,
                                       ifelse(output.tree.all$`97.5%` >= 0 & output.tree.all$`2.5%` >=0, 21, 1))
      output.shrub.all$signif <- ifelse(output.shrub.all$`97.5%` <= 0 & output.shrub.all$`2.5%` <=0, 21,
                                        ifelse(output.shrub.all$`97.5%` >= 0 & output.shrub.all$`2.5%` >=0, 21, 1))
      output.all.all$signif <- ifelse(output.all.all$`97.5%` <= 0 & output.all.all$`2.5%` <=0, 21,
                                      ifelse(output.all.all$`97.5%` >= 0 & output.all.all$`2.5%` >=0, 21, 1))
      
      output.all.all$oddsmean <- exp(output.all.all$mean)
      output.all.all$oddslo <- exp(output.all.all$`2.5%`)
      output.all.all$oddshi <- exp(output.all.all$`97.5%`)
      
      output.tree.all$oddsmean <- exp(output.tree.all$mean)
      output.tree.all$oddslo <- exp(output.tree.all$`2.5%`)
      output.tree.all$oddshi <- exp(output.tree.all$`97.5%`)
      
      output.shrub.all$oddsmean <- exp(output.shrub.all$mean)
      output.shrub.all$oddslo <- exp(output.shrub.all$`2.5%`)
      output.shrub.all$oddshi <- exp(output.shrub.all$`97.5%`)
      
      
      ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      all.all <- output.all.all[rownames(output.all.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      
      all.all$names=factor(param.names, levels = param.names)
      tree.all$names=factor(param.names, levels = param.names)
      shrub.all$names=factor(param.names, levels = param.names)
      
      tree.all$names=as.numeric(tree.all$names)-0.15
      shrub.all$names=as.numeric(shrub.all$names)-0.30
      
      ggplot(data=all.all, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=all.all, color = all.all$color, fill = all.all$color, shape = all.all$signif) + 
        geom_errorbarh(data=all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=tree.all, color = tree.all$color, fill = tree.all$color, shape = tree.all$signif) + 
        geom_errorbarh(data=tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=shrub.all, color = shrub.all$color, fill = shrub.all$color, shape = shrub.all$signif) + 
        geom_errorbarh(data=shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_alldiams_allspp_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
      
      ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      plots.all.all <- output.all.all[rownames(output.all.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      
      plots.all.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.tree.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.shrub.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      
      plots.tree.all$names=as.numeric(plots.tree.all$names)-0.15
      plots.shrub.all$names=as.numeric(plots.shrub.all$names)-0.30
      
      ggplot(data=plots.tree.all, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=plots.all.all, color = plots.all.all$color, fill = plots.all.all$color, shape = plots.all.all$signif) + 
        geom_errorbarh(data=plots.all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.tree.all, color = plots.tree.all$color, fill = plots.tree.all$color, shape = plots.tree.all$signif) + 
        geom_errorbarh(data=plots.tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.shrub.all, color = plots.shrub.all$color, fill = plots.shrub.all$color, shape = plots.shrub.all$signif) + 
        geom_errorbarh(data=plots.shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_alldiams_allspp_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
    } 
  }
  
}


### AM versus EM ###
if(RUN.SA2==T & AMvEM==T){
  #---------------------### SET PARAMETERS ###--------------------------#
  ### allow SA1 to inform how we will handle guild designations and species inclusion
  ## specify what parameters were chosen based on AUC comparison
  x = 'ericoidDIFF.bothDIFF'
  INCLUDE.BOTH = T
  INCLUDE.ERICOID = T
  
  if(INCLUDE.BOTH == T & INCLUDE.ERICOID == T){
    included <- 'quant.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == T){
      included <- 'quant_noB.Rdata'} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == F){
        included <- 'quant_noE.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == F){included <- 'quant_noB_noE.Rdata'}
  
  ###############################################################-
  #################       VISUALIZATIONS      ###################-
  #--------------------------------------------------------------#
  {
    # all parameters
    {
    # get param.table in right format
    {
      
      PARAM.list.AM.large <- list()
      PARAM.list.EM.large <- list()
      PARAM.list.AM.small <- list()
      PARAM.list.EM.small <- list()

      for(m in c(20)){
        for(DBH.quant in c(0.1,0.9)){
          for(g in c('AM','EM')){
            
            print(paste('Now on model : radius=', m, ', DBH=', DBH.quant,', ' , g, sep =''))
            rm(output)
            
            output <- loadRData(file = paste('Jags/Output.AMvEM/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
            output <- as.data.frame(output$summary)
            output <- output[-nrow(output),c("mean","2.5%","97.5%")]
            
            name<-paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
            
            if(DBH.quant == 0.1){
              if(g == 'EM'){
                PARAM.list.EM.small[[name]] <- output
              } else if(g == 'AM'){
                PARAM.list.AM.small[[name]] <- output
              }
            }
            
            if(DBH.quant == 0.9){
              if(g == 'EM'){
                PARAM.list.EM.large[[name]] <- output
              } else if(g == 'AM'){
                PARAM.list.AM.large[[name]] <- output
              }
            }
            
            
          }
        }
      }
      
      ### make concise tables
      {
        PARAM.matrix.EM.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.EM.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.EM.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.EM.large[,1] <- apply(sapply(PARAM.list.EM.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.EM.large[,2] <- apply(sapply(PARAM.list.EM.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.EM.large$mean <- apply(PARAM.matrix.EM.large, 1, FUN = mean)
        
        PARAM.matrix.AM.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.AM.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.AM.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.AM.large[,1] <- apply(sapply(PARAM.list.AM.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.AM.large[,2] <- apply(sapply(PARAM.list.AM.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.AM.large$mean <- apply(PARAM.matrix.AM.large, 1, FUN = mean)
        
        ###

        PARAM.matrix.EM.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.EM.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.EM.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.EM.small[,1] <- apply(sapply(PARAM.list.EM.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.EM.small[,2] <- apply(sapply(PARAM.list.EM.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.EM.small$mean <- apply(PARAM.matrix.EM.small, 1, FUN = mean)
        
        PARAM.matrix.AM.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.AM.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.AM.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.AM.small[,1] <- apply(sapply(PARAM.list.AM.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.AM.small[,2] <- apply(sapply(PARAM.list.AM.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.AM.small$mean <- apply(PARAM.matrix.AM.small, 1, FUN = mean)
      }
    }
    
    plot.names <- c('Wind River, WA','Yosemite, CA','Cedar Breaks, UT')
    param.names <- c('Conspecifics','Heterospecifics: Shared','Heterospecifics: Different','Richness: Shared','Richness: Different', 'Interaction: Shared', 'Interaction: Different')
    plots <- c(1,2,3)
    
    # make plots
    {
      output.EM.large <- PARAM.matrix.EM.large
      output.EM.small <- PARAM.matrix.EM.small
      output.AM.large <- PARAM.matrix.AM.large; output.AM.large <- rbind(output.AM.large,c(NA,NA,NA)); output.AM.large <- output.AM.large[c(1:2,10,3:9),]
      output.AM.small <- PARAM.matrix.AM.small; output.AM.small <- rbind(output.AM.small,c(NA,NA,NA)); output.AM.small <- output.AM.small[c(1:2,10,3:9),]
      
      output.EM.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.EM.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.AM.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.AM.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      
      output.EM.large$names=as.numeric(output.EM.large$names) - 0.15
      output.AM.small$names=as.numeric(output.AM.small$names) - 0.30
      output.AM.large$names=as.numeric(output.AM.large$names) - 0.45
      
      output.EM.small$color <- 'green'
      output.EM.large$color <- 'blue'
      output.AM.small$color <- 'orange'
      output.AM.large$color <- 'red'
      
      output.EM.small$signif <- ifelse(output.EM.small$`97.5%` <= 0 & output.EM.small$`2.5%` <=0, 21,
                                         ifelse(output.EM.small$`97.5%` >= 0 & output.EM.small$`2.5%` >=0, 21, 1))
      output.EM.large$signif <- ifelse(output.EM.large$`97.5%` <= 0 & output.EM.large$`2.5%` <=0, 21,
                                         ifelse(output.EM.large$`97.5%` >= 0 & output.EM.large$`2.5%` >=0, 21, 1))
      output.AM.small$signif <- ifelse(output.AM.small$`97.5%` <= 0 & output.AM.small$`2.5%` <=0, 21,
                                          ifelse(output.AM.small$`97.5%` >= 0 & output.AM.small$`2.5%` >=0, 21, 1))
      output.AM.large$signif <- ifelse(output.AM.large$`97.5%` <= 0 & output.AM.large$`2.5%` <=0, 21,
                                          ifelse(output.AM.large$`97.5%` >= 0 & output.AM.large$`2.5%` >=0, 21, 1))
      
      output.EM.small$oddsmean <- exp(output.EM.small$mean)
      output.EM.large$oddsmean <- exp(output.EM.large$mean)
      output.EM.small$oddslo <- exp(output.EM.small$`2.5%`)
      output.EM.large$oddslo <- exp(output.EM.large$`2.5%`)
      output.EM.small$oddshi <- exp(output.EM.small$`97.5%`)
      output.EM.large$oddshi <- exp(output.EM.large$`97.5%`)
      
      output.AM.small$oddsmean <- exp(output.AM.small$mean)
      output.AM.large$oddsmean <- exp(output.AM.large$mean)
      output.AM.small$oddslo <- exp(output.AM.small$`2.5%`)
      output.AM.large$oddslo <- exp(output.AM.large$`2.5%`)
      output.AM.small$oddshi <- exp(output.AM.small$`97.5%`)
      output.AM.large$oddshi <- exp(output.AM.large$`97.5%`)
      
      ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      EM.large <- output.EM.large[rownames(output.EM.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      EM.small <- output.EM.small[rownames(output.EM.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      AM.large <- output.AM.large[rownames(output.AM.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      AM.small <- output.AM.small[rownames(output.AM.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      
      EM.large$names=factor(param.names, levels = param.names)
      EM.small$names=factor(param.names, levels = param.names)
      AM.large$names=factor(param.names, levels = param.names)
      AM.small$names=factor(param.names, levels = param.names)
      
      EM.large$names=as.numeric(EM.large$names)-0.15
      AM.small$names=as.numeric(AM.small$names)-0.30
      AM.large$names=as.numeric(AM.large$names)-0.45
      
      ggplot(data=EM.small, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=EM.small, color = EM.small$color, fill = EM.small$color, shape = EM.small$signif) + 
        geom_errorbarh(data=EM.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=EM.large, color = EM.large$color, fill = EM.large$color, shape = EM.large$signif) + 
        geom_errorbarh(data=EM.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=AM.small, color = AM.small$color, fill = AM.small$color, shape = AM.small$signif) + 
        geom_errorbarh(data=AM.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=AM.large, color = AM.large$color, fill = AM.large$color, shape = AM.large$signif) + 
        geom_errorbarh(data=AM.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_AMvEM_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
      
      ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      plots.EM.large <- output.EM.large[rownames(output.EM.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.EM.small <- output.EM.small[rownames(output.EM.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.AM.large <- output.AM.large[rownames(output.AM.large) %in% c("beta0[1]","beta0[2]","10","beta3"),]
      plots.AM.small <- output.AM.small[rownames(output.AM.small) %in% c("beta0[1]","beta0[2]","10","beta3"),]
      
      plots.EM.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.EM.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.AM.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.AM.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      
      plots.EM.large$names=as.numeric(plots.EM.large$names)-0.15
      plots.AM.small$names=as.numeric(plots.AM.small$names)-0.30
      plots.AM.large$names=as.numeric(plots.AM.large$names)-0.45
      
      ggplot(data=plots.EM.small, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=plots.EM.small, color = plots.EM.small$color, fill = plots.EM.small$color, shape = plots.EM.small$signif) + 
        geom_errorbarh(data=plots.EM.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.EM.large, color = plots.EM.large$color, fill = plots.EM.large$color, shape = plots.EM.large$signif) + 
        geom_errorbarh(data=plots.EM.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.AM.small, color = plots.AM.small$color, fill = plots.AM.small$color, shape = plots.AM.small$signif) + 
        geom_errorbarh(data=plots.AM.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.AM.large, color = plots.AM.large$color, fill = plots.AM.large$color, shape = plots.AM.large$signif) + 
        geom_errorbarh(data=plots.AM.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_AMvEM_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
    } 
    }
  
    # interactions plots
    {
      g = 'EM'
      m = 20
      DBH.quant = 0.9
      
      num <- ifelse(g == 'AM',2,3)
      
      ### use same specified covariate ranges  for all - m and x will be pre-specified, but should be the same for combos of shrub/tree or diameter subset ### 
      {
        chosen.datt <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.20200928.Rdata', sep = '')) # final.datt # *** PUBLISHED = .20200928.Rdata ***
        
        ## covariates
        plots <- 1:num
        cons <- rep(mean(chosen.datt[,grep('con.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),num)
        het.s <- rep(mean(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),num)
        het.d <- rep(mean(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),num)
        rich.s <- rep(mean(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),num)
        rich.d <- rep(mean(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),num)
        
        ## set interaction bounds
        rich.s.max <- rep(as.numeric(summary(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),num)
        rich.s.min <- rep(as.numeric(summary(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),num)
        
        het.s.max <- rep(as.numeric(summary(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),num)
        het.s.min <- rep(as.numeric(summary(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),num)
        
        rich.d.max <- rep(as.numeric(summary(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),num)
        rich.d.min <- rep(as.numeric(summary(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),num)
        
        het.d.max <- rep(as.numeric(summary(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),num)
        het.d.min <- rep(as.numeric(summary(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),num)
        
      }
      
      ## ---------------------- INTERACTION PLOTS ---------------------- ###
      {
        model <- loadRData(file = paste('Jags/Output.AMvEM/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
        output <- as.data.frame(model$summary)
        output <- output[-nrow(output),]
        
                ########   SAME GUILD INTERACTIONS   ######## -
        sg.Xmat.min.min <- model.matrix(~as.factor(plots) + cons + het.s.min + het.d + rich.s.min + rich.d + (het.s.min*rich.s.min) + (het.d*rich.d) - 1) # with interaction 
        sg.prob.min.min <- plogis(sg.Xmat.min.min %*% output$mean)
        sg.prob.min.min.lo <- plogis(sg.Xmat.min.min %*% output$`2.5%`)
        sg.prob.min.min.hi <- plogis(sg.Xmat.min.min %*% output$`97.5%`)
        
        sg.Xmat.min.max <- model.matrix(~as.factor(plots) + cons + het.s.min + het.d + rich.s.max + rich.d + (het.s.min*rich.s.max) + (het.d*rich.d) - 1) # with interaction 
        sg.prob.min.max <- plogis(sg.Xmat.min.max %*% output$mean)
        sg.prob.min.max.lo <- plogis(sg.Xmat.min.max %*% output$`2.5%`)
        sg.prob.min.max.hi <- plogis(sg.Xmat.min.max %*% output$`97.5%`)
        
        sg.Xmat.max.max <- model.matrix(~as.factor(plots) + cons + het.s.max + het.d + rich.s.max + rich.d + (het.s.max*rich.s.max) + (het.d*rich.d) - 1) # with interaction 
        sg.prob.max.max <- plogis(sg.Xmat.max.max %*% output$mean)
        sg.prob.max.max.lo <- plogis(sg.Xmat.max.max %*% output$`2.5%`)
        sg.prob.max.max.hi <- plogis(sg.Xmat.max.max %*% output$`97.5%`)
        
        sg.Xmat.max.min <- model.matrix(~as.factor(plots) + cons + het.s.max + het.d + rich.s.min + rich.d + (het.s.max*rich.s.min) + (het.d*rich.d) - 1) # with interaction 
        sg.prob.max.min <- plogis(sg.Xmat.max.min %*% output$mean)
        sg.prob.max.min.lo <- plogis(sg.Xmat.max.min %*% output$`2.5%`)
        sg.prob.max.min.hi <- plogis(sg.Xmat.max.min %*% output$`97.5%`)
        
        sg.all.probs <- data.frame("prob" = c(sg.prob.min.min,sg.prob.min.max,sg.prob.max.max,sg.prob.max.min),
                                   "prob.lo" = c(sg.prob.min.min.lo,sg.prob.min.max.lo,sg.prob.max.max.lo,sg.prob.max.min.lo),
                                   "prob.hi" = c(sg.prob.min.min.hi,sg.prob.min.max.hi,sg.prob.max.max.hi,sg.prob.max.min.hi),
                                   "model" = c(rep("minmin",num),rep("minmax",num),rep('maxmax',num),rep('maxmin',num)),
                                   "plot" = rep(c(1:num),4),
                                   "het.s" = factor(c(rep("low",num*2),rep('high',num*2)),levels = c('low','high')),
                                   "rich.s" = factor(c(rep("low",num),rep('high',num*2),rep("low",num)),levels = c('low','high')))
        
        inx.same <- ggplot(data = sg.all.probs, aes(x = het.s, y = prob, colour=rich.s, linetype = as.factor(plot), group = interaction(rich.s,plot))) + 
          geom_line(size=1) + geom_point(size=3) + coord_cartesian(ylim = c(0,1)) +
          # geom_errorbar(aes(ymax = prob.hi, ymin = prob.lo), width=.1, alpha = 0.7, position=position_dodge(0.1), show.legend=FALSE) +
          theme_prefs + theme(legend.position = "none") +
          theme(legend.title = element_blank()) +
          labs(x="",y="")
        
        
        ########   DIFFERENT GUILD INTERACTIONS   ######## -
        
        dg.Xmat.min.min <- model.matrix(~as.factor(plots) + cons + het.s + het.d.min + rich.s + rich.d.min + (het.s*rich.s) + (het.d.min*rich.d.min) - 1) # with interaction 
        dg.prob.min.min <- plogis(dg.Xmat.min.min %*% output$mean)
        dg.prob.min.min.lo <- plogis(dg.Xmat.min.min %*% output$`2.5%`)
        dg.prob.min.min.hi <- plogis(dg.Xmat.min.min %*% output$`97.5%`)
        
        dg.Xmat.min.max <- model.matrix(~as.factor(plots) + cons + het.s + het.d.min + rich.s + rich.d.max + (het.s*rich.s) + (het.d.min*rich.d.max) - 1) # with interaction 
        dg.prob.min.max <- plogis(dg.Xmat.min.max %*% output$mean)
        dg.prob.min.max.lo <- plogis(dg.Xmat.min.max %*% output$`2.5%`)
        dg.prob.min.max.hi <- plogis(dg.Xmat.min.max %*% output$`97.5%`)
        
        dg.Xmat.max.max <- model.matrix(~as.factor(plots) + cons + het.s + het.d.max + rich.s + rich.d.max + (het.s*rich.s) + (het.d.max*rich.d.max) - 1) # with interaction 
        dg.prob.max.max <- plogis(dg.Xmat.max.max %*% output$mean)
        dg.prob.max.max.lo <- plogis(dg.Xmat.max.max %*% output$`2.5%`)
        dg.prob.max.max.hi <- plogis(dg.Xmat.max.max %*% output$`97.5%`)
        
        dg.Xmat.max.min <- model.matrix(~as.factor(plots) + cons + het.s + het.d.max + rich.s + rich.d.min + (het.s*rich.s) + (het.d.max*rich.d.min) - 1) # with interaction 
        dg.prob.max.min <- plogis(dg.Xmat.max.min %*% output$mean)
        dg.prob.max.min.lo <- plogis(dg.Xmat.max.min %*% output$`2.5%`)
        dg.prob.max.min.hi <- plogis(dg.Xmat.max.min %*% output$`97.5%`)
        
        dg.all.probs <- data.frame("prob" = c(dg.prob.min.min,dg.prob.min.max,dg.prob.max.max,dg.prob.max.min),
                                   "prob.lo" = c(dg.prob.min.min.lo,dg.prob.min.max.lo,dg.prob.max.max.lo,dg.prob.max.min.lo),
                                   "prob.hi" = c(dg.prob.min.min.hi,dg.prob.min.max.hi,dg.prob.max.max.hi,dg.prob.max.min.hi),
                                   "model" = c(rep("minmin",num),rep("minmax",num),rep('maxmax',num),rep('maxmin',num)),
                                   "plot" = rep(c(1:num),4),
                                   "rich.d" = factor(c(rep("low",num),rep('high',num*2),rep("low",num)),levels = c('low','high')),
                                   "het.d" = factor(c(rep("low",num*2),rep('high',num*2)),levels = c('low','high')))
        
        inx.diff <- ggplot(data = dg.all.probs, aes(x = het.d, y = prob, colour=rich.d, linetype = as.factor(plot), group = interaction(rich.d,plot))) + 
          geom_line(size=1) + geom_point(size=3) + coord_cartesian(ylim = c(0,1)) +
          # geom_errorbar(aes(ymax = prob.hi, ymin = prob.lo), width=.1, alpha = 0.7, position=position_dodge(0.1), show.legend=FALSE) +
          theme_prefs + theme(legend.position = "none") +
          # theme(legend.title = element_blank()) + 
          labs(x="",y="")
        
        plot<-plot_grid(inx.same,inx.diff, nrow=2, ncol=1, align='v')
        y.grob<-textGrob("Survival Probability", gp=gpar(col="black", fontsize=10), rot=90)
        x.grob<-textGrob("Crowding", gp=gpar(col="black", fontsize=10))
        gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
        # dev.print(file= paste('./Figures/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,'quant_inxplot.tif',sep = ''),tiff,width=5,height=4,res=600,units='in',compression='lzw')
      }
      
    }
  }
  
}


##########################################################################################################

##########################################################################################################-
##################################      SA3: DENSITY COMPARISON       ##################################-
#----------------------------------------------------------------------------------------------------------

if(RUN.SA3==T){
  
  ### ---------------------- AUC Comparison ---------------------- ###
  
  AUC.table <- as.data.frame(matrix(ncol = 2, nrow = length(dir('Jags/Output.SA3/'))))
  colnames(AUC.table) <- c('model', 'AUC')
  
  for(a in 1:nrow(AUC.table)){
    print( paste('Now on: ', a, ' of ',length(dir('Jags/Output.SA3/')), sep = '' ))
    
    #### SET PARAMETERS FOR DATA SETUP ####
    d = dir('Jags/Output.SA3/')[a]
    
    INCLUDE.BOTH <- ifelse(str_detect(d, 'noB')==T, FALSE, TRUE)
    INCLUDE.ERICOID <- ifelse(str_detect(d, 'noE')==T, FALSE, TRUE)
    
    g <- ifelse(str_detect(d, 'all')==T, 'all',
                ifelse(str_detect(d, 'tree')==T, 'tree', 'shrub'))
    x <- ifelse(str_detect(d, 'ericoidDIFF.bothDIFF')==T, 'ericoidDIFF.bothDIFF',
                ifelse(str_detect(d,'ericoidSAME.bothDIFF')==T, 'ericoidSAME.bothDIFF', 
                       ifelse(str_detect(d,'ericoidDIFF.bothSAME')==T, 'ericoidDIFF.bothSAME', 'ericoidSAME.bothSAME')))
    m <- ifelse(str_detect(d, '_5m')==T, 5,
                ifelse(str_detect(d, '_10m')==T, 10,
                       ifelse(str_detect(d, '_15m')==T, 15, 20)))
    DBH.quant <- ifelse(str_detect(d, '_0.1quant')==T, 0.1,
                        ifelse(str_detect(d, '_0.9quant')==T, 0.9,1))
    
    print( paste(g,'_',x,'_',m,'m_',DBH.quant,'quant :   Both = ', INCLUDE.BOTH, ', Ericoid = ', INCLUDE.ERICOID, sep = '') )
    
    ##########################################################################################################-
    #########################################       DATA SETUP      ##########################################-
    #----------------------------------------------------------------------------------------------------------
    
    #### GET DATA ####
    final.datt <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.20200928.Rdata', sep = '')) # final.datt # *** PUBLISHED = .20200928.Rdata ***
    density <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep = '')) # final.datt # *** PUBLISHED = .DENSITYonly.20201020.Rdata ***
    final.datt<-merge(final.datt,density[,c("ID",grep(paste('den.cons.',m,sep = ''),colnames(density),value=T,fixed=T),
                                            grep(paste('den.diff.',m,sep = ''),colnames(density),value=T,fixed=T),
                                            grep(paste('den.same.',m,sep = ''),colnames(density),value=T,fixed=T))],by=c('ID'))
    
    min.num <-2 # minimum number of subsetted individuals necessary to be included in analyses
    
    ### ---------------------- SUBSET TREES BY DIAMETER ---------------------- ###
    {
      final.datt$REAL_DBH <- exp(final.datt$DBH)
      
      ## set threshold per plot / species
      species <- aggregate(final.datt$ID,by=list(final.datt$PLOT,final.datt$SPECIES),FUN=nrow)
      species$QUANT <-NA
      species<-species[,-3]
      
      for(i in 1:nrow(species)){ # shows the DBH at the given quantile
        species[i,'QUANT'] <- quantile(final.datt[final.datt$SPECIES == species[i,'Group.2'] &
                                                    final.datt$PLOT == species[i,'Group.1'],'REAL_DBH'],DBH.quant)
      }
      species<-species[order(species$Group.1),]
      
      final.datt$SUB <- NA
      for(i in 1:nrow(final.datt)){
        
        ifelse(DBH.quant == 1,
               final.datt[i,'SUB'] <- 1, 
               ifelse(DBH.quant > 0.5,
                      final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] >= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                          species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0), 
                      final.datt[i,'SUB'] <- ifelse(final.datt[i,'REAL_DBH'] <= species[species$Group.2==final.datt[i,'SPECIES'] &
                                                                                          species$Group.1==final.datt[i,'PLOT'],'QUANT'], 1, 0)) )
      }
      
      subset.all <- final.datt[final.datt$SUB==1,]
    }
    
    ### ---------------------- SUBSET TREES BY SPECIES ---------------------- ###
    {
      subset.tree <- subset.all[subset.all$SPECIES %in% c('PIPO','PILO','ABBI','PIFL','PIPU','PIEN','PSME.G','PIED','JUSC','ABCO','TSHE','ABAM','TABR','PSME.M','ABPR','ABGR','THPL','PIMO','PILA','CADE','ABMA'),] # trees aka single-stem, non-vegetatively reproducing spp
      
      if(INCLUDE.BOTH==F & INCLUDE.ERICOID==F){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD %in% c('ericoid','both'),'SPECIES']),]
        
      } else if(INCLUDE.BOTH==F & INCLUDE.ERICOID==T){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='both','SPECIES']),]
        
      } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==F){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='ericoid','SPECIES']),]
        
      } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==T){
        subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES),]
      }
      
      subset.all$SPECIES_NUM <- as.numeric(as.factor(subset.all$SPECIES))
      subset.tree$SPECIES_NUM <- as.numeric(as.factor(subset.tree$SPECIES))
      subset.shrub$SPECIES_NUM <- as.numeric(as.factor(subset.shrub$SPECIES))
      
      subset.all$BA <- BA.function(subset.all$REAL_DBH)
      subset.tree$BA <- BA.function(subset.tree$REAL_DBH)
      subset.shrub$BA <- BA.function(subset.shrub$REAL_DBH)
    }
    
    ### ---------------------- SUBSET TREES BY min.num ---------------------- ###
    {
      all.summary <- aggregate(subset.all$STEM_TAG, by=list(subset.all$PLOT,subset.all$SPECIES), FUN=NROW)
      tree.summary <- aggregate(subset.tree$STEM_TAG, by=list(subset.tree$PLOT,subset.tree$SPECIES), FUN=NROW)
      shrub.summary <- aggregate(subset.shrub$STEM_TAG, by=list(subset.shrub$PLOT,subset.shrub$SPECIES), FUN=NROW)
      
      plenty.all <- all.summary[all.summary$x >= min.num,]
      plenty.tree <- tree.summary[tree.summary$x >= min.num,]
      plenty.shrub <- shrub.summary[shrub.summary$x >= min.num,]
      
      subset.all$keep <- ifelse(subset.all$PLOT==1 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==1,'Group.2']), 1,
                                ifelse(subset.all$PLOT==2 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==2,'Group.2']), 1,
                                       ifelse(subset.all$PLOT==3 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==3,'Group.2']), 1,0)))
      subset.all <- subset.all[subset.all$keep == 1,] 
      
      subset.tree$keep <- ifelse(subset.tree$PLOT==1 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==1,'Group.2']), 1,
                                 ifelse(subset.tree$PLOT==2 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==2,'Group.2']), 1,
                                        ifelse(subset.tree$PLOT==3 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==3,'Group.2']), 1,0)))
      subset.tree <- subset.tree[subset.tree$keep == 1,]                                     
      
      subset.shrub$keep <- ifelse(subset.shrub$PLOT==1 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==1,'Group.2']), 1,
                                  ifelse(subset.shrub$PLOT==2 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==2,'Group.2']), 1,
                                         ifelse(subset.shrub$PLOT==3 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==3,'Group.2']), 1,0)))
      subset.shrub <- subset.shrub[subset.shrub$keep == 1,]                                
      
    }
    
    ##########################################################################################################
    
    #### GET MODELS ####
    model <-loadRData(paste('Jags/Output.SA3/',d,sep=''))
    output <- as.data.frame(model$summary)
    output <- output[-nrow(output),]
    
    ## covariates
    anal.datt <- eval(parse(text = paste('subset',g,sep='.')))
    plots <- anal.datt$PLOT
    
    cons <- anal.datt[,grep('den.cons.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    het.s <- anal.datt[,grep('den.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    het.d <- anal.datt[,grep('den.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    rich.s <- anal.datt[,grep('rich.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    rich.d <- anal.datt[,grep('rich.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
    
    param <- as.matrix(cbind(cons,het.s,het.d,rich.s,rich.d))
    
    survival <- anal.datt$DA
    survival <- ifelse(survival==1,0,1)
    
    # linear model: use estimated betas to calculate survival probability / classification
    Xmat <- model.matrix(~as.factor(plots) + cons + het.s + het.d + rich.s + rich.d + (het.s*rich.s) + (het.d*rich.d) - 1) # with interaction 
    prob <- plogis(Xmat %*% output$mean)
    
    #create auc.roc plot
    ObsPred <- data.frame(survival, Predicted=prob)
    ObsPred$ID <- anal.datt$STEM_TAG
    ObsPred <- ObsPred[,c(3,1,2)]
    
    AUC <- roc.area(ObsPred[,2], ObsPred[,3])$A
    AUC.table[a,'AUC'] <- AUC
    AUC.table[a,'model'] <- paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
    
    rm(final.datt)
    rm(anal.datt)
    rm(model)
    rm(output)
    rm(AUC)
    rm(ObsPred)
  }
  
  AUC.table <- AUC.table[order(AUC.table$model),]
  AUC.table$AUC <- round (AUC.table$AUC, 4)
  # save(AUC.table,file = 'Tables/AUC_comparison_DENSITYonly.Rdata')
  # write.csv(AUC.table,file = 'Tables/AUC_comparison_DENSITYonly.csv')
  
  
  ###############################################################-
  #################       VISUALIZATIONS      ###################-
  #--------------------------------------------------------------#
  {
    x <- 'ericoidDIFF.bothDIFF'
    INCLUDE.BOTH = T
    INCLUDE.ERICOID = T
    
    if(INCLUDE.BOTH == T & INCLUDE.ERICOID == T){
      included <- 'quant.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == T){
        included <- 'quant_noB.Rdata'} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == F){
          included <- 'quant_noE.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == F){included <- 'quant_noB_noE.Rdata'}
    
    # get param.table in right format
    {
      
      PARAM.list.shrub.large <- list()
      PARAM.list.tree.large <- list()
      PARAM.list.all.large <- list()
      PARAM.list.shrub.small <- list()
      PARAM.list.tree.small <- list()
      PARAM.list.all.small <- list()
      
      for(m in c(5,10,15,20)){
        for(DBH.quant in c(0.1,0.9)){
          for(g in c('all','tree','shrub')){
            
            print(paste('Now on model : radius=', m, ', DBH=', DBH.quant,', ' , g, sep =''))
            rm(output)
            
            output <- loadRData(file = paste('Jags/Output.SA3/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,'quant_DENSITYonly.Rdata', sep = '')) 
            output <- as.data.frame(output$summary)
            output <- output[-nrow(output),c("mean","2.5%","97.5%")]
            
            name<-paste(g,'_',x,'_',m,'m_',DBH.quant,'quant_Both', INCLUDE.BOTH, '_Ericoid', INCLUDE.ERICOID, sep = '')
            
            if(DBH.quant == 0.1){
              if(g == 'all'){
                PARAM.list.all.small[[name]] <- output
              } else if(g == 'tree'){
                PARAM.list.tree.small[[name]] <- output
              } else if(g == 'shrub'){
                PARAM.list.shrub.small[[name]] <- output
              }
            }
            
            if(DBH.quant == 0.9){
              if(g == 'all'){
                PARAM.list.all.large[[name]] <- output
              } else if(g == 'tree'){
                PARAM.list.tree.large[[name]] <- output
              } else if(g == 'shrub'){
                PARAM.list.shrub.large[[name]] <- output
              }
            }
            
            
          }
        }
      }
      
      ### make concise tables
      {
        PARAM.matrix.all.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.all.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.all.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.all.large[,1] <- apply(sapply(PARAM.list.all.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.all.large[,2] <- apply(sapply(PARAM.list.all.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.all.large$mean <- apply(PARAM.matrix.all.large, 1, FUN = mean)
        
        PARAM.matrix.tree.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.tree.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.tree.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.tree.large[,1] <- apply(sapply(PARAM.list.tree.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.tree.large[,2] <- apply(sapply(PARAM.list.tree.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.tree.large$mean <- apply(PARAM.matrix.tree.large, 1, FUN = mean)
        
        PARAM.matrix.shrub.large <- as.data.frame(matrix(nrow = nrow(PARAM.list.shrub.large[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.shrub.large[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.shrub.large[,1] <- apply(sapply(PARAM.list.shrub.large, `[[`, "2.5%"), 1, min)
        PARAM.matrix.shrub.large[,2] <- apply(sapply(PARAM.list.shrub.large, `[[`, "97.5%"), 1, max)
        PARAM.matrix.shrub.large$mean <- apply(PARAM.matrix.shrub.large, 1, FUN = mean)
        
        ###
        
        PARAM.matrix.all.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.all.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.all.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.all.small[,1] <- apply(sapply(PARAM.list.all.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.all.small[,2] <- apply(sapply(PARAM.list.all.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.all.small$mean <- apply(PARAM.matrix.all.small, 1, FUN = mean)
        
        PARAM.matrix.tree.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.tree.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.tree.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.tree.small[,1] <- apply(sapply(PARAM.list.tree.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.tree.small[,2] <- apply(sapply(PARAM.list.tree.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.tree.small$mean <- apply(PARAM.matrix.tree.small, 1, FUN = mean)
        
        PARAM.matrix.shrub.small <- as.data.frame(matrix(nrow = nrow(PARAM.list.shrub.small[[1]]), ncol = 2, dimnames = list(c(rownames(PARAM.list.shrub.small[[1]])), c("2.5%","97.5%"))))
        PARAM.matrix.shrub.small[,1] <- apply(sapply(PARAM.list.shrub.small, `[[`, "2.5%"), 1, min)
        PARAM.matrix.shrub.small[,2] <- apply(sapply(PARAM.list.shrub.small, `[[`, "97.5%"), 1, max)
        PARAM.matrix.shrub.small$mean <- apply(PARAM.matrix.shrub.small, 1, FUN = mean)
      }
    }
    
    plot.names <- c('Wind River, WA','Yosemite, CA','Cedar Breaks, UT')
    param.names <- c('Conspecifics','Heterospecifics: Shared','Heterospecifics: Different','Richness: Shared','Richness: Different', 'Interaction: Shared', 'Interaction: Different')
    plots <- c(1,2,3)
    
    # all parameters
    {
      output.tree.large <- PARAM.matrix.tree.large
      output.tree.small <- PARAM.matrix.tree.small
      output.shrub.large <- PARAM.matrix.shrub.large
      output.shrub.small <- PARAM.matrix.shrub.small
      
      output.tree.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.tree.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.shrub.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.shrub.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      
      output.tree.large$names=as.numeric(output.tree.large$names) - 0.15
      output.shrub.small$names=as.numeric(output.shrub.small$names) - 0.30
      output.shrub.large$names=as.numeric(output.shrub.large$names) - 0.45
      
      output.tree.small$color <- 'green'
      output.tree.large$color <- 'blue'
      output.shrub.small$color <- 'orange'
      output.shrub.large$color <- 'red'
      
      output.tree.small$signif <- ifelse(output.tree.small$`97.5%` <= 0 & output.tree.small$`2.5%` <=0, 21,
                                         ifelse(output.tree.small$`97.5%` >= 0 & output.tree.small$`2.5%` >=0, 21, 1))
      output.tree.large$signif <- ifelse(output.tree.large$`97.5%` <= 0 & output.tree.large$`2.5%` <=0, 21,
                                         ifelse(output.tree.large$`97.5%` >= 0 & output.tree.large$`2.5%` >=0, 21, 1))
      output.shrub.small$signif <- ifelse(output.shrub.small$`97.5%` <= 0 & output.shrub.small$`2.5%` <=0, 21,
                                          ifelse(output.shrub.small$`97.5%` >= 0 & output.shrub.small$`2.5%` >=0, 21, 1))
      output.shrub.large$signif <- ifelse(output.shrub.large$`97.5%` <= 0 & output.shrub.large$`2.5%` <=0, 21,
                                          ifelse(output.shrub.large$`97.5%` >= 0 & output.shrub.large$`2.5%` >=0, 21, 1))
      
      output.tree.small$oddsmean <- exp(output.tree.small$mean)
      output.tree.large$oddsmean <- exp(output.tree.large$mean)
      output.tree.small$oddslo <- exp(output.tree.small$`2.5%`)
      output.tree.large$oddslo <- exp(output.tree.large$`2.5%`)
      output.tree.small$oddshi <- exp(output.tree.small$`97.5%`)
      output.tree.large$oddshi <- exp(output.tree.large$`97.5%`)
      
      output.shrub.small$oddsmean <- exp(output.shrub.small$mean)
      output.shrub.large$oddsmean <- exp(output.shrub.large$mean)
      output.shrub.small$oddslo <- exp(output.shrub.small$`2.5%`)
      output.shrub.large$oddslo <- exp(output.shrub.large$`2.5%`)
      output.shrub.small$oddshi <- exp(output.shrub.small$`97.5%`)
      output.shrub.large$oddshi <- exp(output.shrub.large$`97.5%`)
      
      ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      
      tree.large$names=factor(param.names, levels = param.names)
      tree.small$names=factor(param.names, levels = param.names)
      shrub.large$names=factor(param.names, levels = param.names)
      shrub.small$names=factor(param.names, levels = param.names)
      
      tree.large$names=as.numeric(tree.large$names)-0.15
      shrub.small$names=as.numeric(shrub.small$names)-0.30
      shrub.large$names=as.numeric(shrub.large$names)-0.45
      
      ggplot(data=tree.small, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=tree.small, color = tree.small$color, fill = tree.small$color, shape = tree.small$signif) + 
        geom_errorbarh(data=tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=tree.large, color = tree.large$color, fill = tree.large$color, shape = tree.large$signif) + 
        geom_errorbarh(data=tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=shrub.small, color = shrub.small$color, fill = shrub.small$color, shape = shrub.small$signif) + 
        geom_errorbarh(data=shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=shrub.large, color = shrub.large$color, fill = shrub.large$color, shape = shrub.large$signif) + 
        geom_errorbarh(data=shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_oddsratio_fixed_DENSITY.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
      
      ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      plots.tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      
      plots.tree.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.tree.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.shrub.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.shrub.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      
      plots.tree.large$names=as.numeric(plots.tree.large$names)-0.15
      plots.shrub.small$names=as.numeric(plots.shrub.small$names)-0.30
      plots.shrub.large$names=as.numeric(plots.shrub.large$names)-0.45
      
      ggplot(data=plots.tree.small, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=plots.tree.small, color = plots.tree.small$color, fill = plots.tree.small$color, shape = plots.tree.small$signif) + 
        geom_errorbarh(data=plots.tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.tree.large, color = plots.tree.large$color, fill = plots.tree.large$color, shape = plots.tree.large$signif) + 
        geom_errorbarh(data=plots.tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.shrub.small, color = plots.shrub.small$color, fill = plots.shrub.small$color, shape = plots.shrub.small$signif) + 
        geom_errorbarh(data=plots.shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.shrub.large, color = plots.shrub.large$color, fill = plots.shrub.large$color, shape = plots.shrub.large$signif) + 
        geom_errorbarh(data=plots.shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_oddsratio_random_DENSITY.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
    } 
    
    
    # all parameters, big and small combined
    {
      
      output.all.all <- PARAM.matrix.all
      output.tree.all <- PARAM.matrix.tree
      output.shrub.all <- PARAM.matrix.shrub
      
      output.tree.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.shrub.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      output.all.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
      
      output.tree.all$names=as.numeric(output.tree.all$names) - 0.15
      output.shrub.all$names=as.numeric(output.shrub.all$names) - 0.30
      
      output.tree.all$color <- 'blue'
      output.shrub.all$color <- 'red'
      output.all.all$color <- 'black'
      
      output.tree.all$signif <- ifelse(output.tree.all$`97.5%` <= 0 & output.tree.all$`2.5%` <=0, 21,
                                       ifelse(output.tree.all$`97.5%` >= 0 & output.tree.all$`2.5%` >=0, 21, 1))
      output.shrub.all$signif <- ifelse(output.shrub.all$`97.5%` <= 0 & output.shrub.all$`2.5%` <=0, 21,
                                        ifelse(output.shrub.all$`97.5%` >= 0 & output.shrub.all$`2.5%` >=0, 21, 1))
      output.all.all$signif <- ifelse(output.all.all$`97.5%` <= 0 & output.all.all$`2.5%` <=0, 21,
                                      ifelse(output.all.all$`97.5%` >= 0 & output.all.all$`2.5%` >=0, 21, 1))
      
      output.all.all$oddsmean <- exp(output.all.all$mean)
      output.all.all$oddslo <- exp(output.all.all$`2.5%`)
      output.all.all$oddshi <- exp(output.all.all$`97.5%`)
      
      output.tree.all$oddsmean <- exp(output.tree.all$mean)
      output.tree.all$oddslo <- exp(output.tree.all$`2.5%`)
      output.tree.all$oddshi <- exp(output.tree.all$`97.5%`)
      
      output.shrub.all$oddsmean <- exp(output.shrub.all$mean)
      output.shrub.all$oddslo <- exp(output.shrub.all$`2.5%`)
      output.shrub.all$oddshi <- exp(output.shrub.all$`97.5%`)
      
      
      ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      all.all <- output.all.all[rownames(output.all.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
      
      all.all$names=factor(param.names, levels = param.names)
      tree.all$names=factor(param.names, levels = param.names)
      shrub.all$names=factor(param.names, levels = param.names)
      
      tree.all$names=as.numeric(tree.all$names)-0.15
      shrub.all$names=as.numeric(shrub.all$names)-0.30
      
      ggplot(data=all.all, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=all.all, color = all.all$color, fill = all.all$color, shape = all.all$signif) + 
        geom_errorbarh(data=all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=tree.all, color = tree.all$color, fill = tree.all$color, shape = tree.all$signif) + 
        geom_errorbarh(data=tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=shrub.all, color = shrub.all$color, fill = shrub.all$color, shape = shrub.all$signif) + 
        geom_errorbarh(data=shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_alldiams_allspp_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
      
      ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
      
      # with interaction 
      plots.all.all <- output.all.all[rownames(output.all.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      plots.shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
      
      plots.all.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.tree.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      plots.shrub.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
      
      plots.tree.all$names=as.numeric(plots.tree.all$names)-0.15
      plots.shrub.all$names=as.numeric(plots.shrub.all$names)-0.30
      
      ggplot(data=plots.tree.all, aes(x=oddsmean, y=names)) + 
        xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
        coord_cartesian(ylim = c(0.75,7)) +
        geom_point(data=plots.all.all, color = plots.all.all$color, fill = plots.all.all$color, shape = plots.all.all$signif) + 
        geom_errorbarh(data=plots.all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.tree.all, color = plots.tree.all$color, fill = plots.tree.all$color, shape = plots.tree.all$signif) + 
        geom_errorbarh(data=plots.tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        geom_point(data=plots.shrub.all, color = plots.shrub.all$color, fill = plots.shrub.all$color, shape = plots.shrub.all$signif) + 
        geom_errorbarh(data=plots.shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
        theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
      # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_SA2_alldiams_allspp_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
      
    } 
  }
  
}

##########################################################################################################

stop("SUCCESS! Run by hand from here")

##########################################################################################################-
###################################       SET UP FINAL DATASET      ######################################-
#----------------------------------------------------------------------------------------------------------

#---------------------### SET PARAMETERS ###--------------------------#
## specify what parameters were chosen based on AUC comparison
x <- 'ericoidDIFF.bothDIFF' # *** PUBLISHED = ericoidDIFF.bothDIFF ***
m <- 20  # *** PUBLISHED = 20 ***
INCLUDE.BOTH = T  # *** PUBLISHED = T ***
INCLUDE.ERICOID = T  # *** PUBLISHED = T ***
DENSITY = F  # *** PUBLISHED = F ***


## must do tree and shrub individuals separately; hard coded 
## must do large and small individuals separately; hard coded 
g <- 'tree' #choose tree or shrub
DBH.quant <- 0.9 # 0.1 for small, 0.9 for large trees


### ---------------------### GET MODELS ###--------------------------### 

if(DENSITY==T){
  if(INCLUDE.BOTH == T & INCLUDE.ERICOID == T){
    included <- 'quant_DENSITYonly.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == T){
      included <- 'quant_noB_DENSITYonly.Rdata'} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == F){
        included <- 'quant_noE_DENSITYonly.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == F){included <- 'quant_noB_noE_DENSITYonly.Rdata'}
  
} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == T){
  included <- 'quant.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == T){
    included <- 'quant_noB.Rdata'} else if(INCLUDE.BOTH == T & INCLUDE.ERICOID == F){
      included <- 'quant_noE.Rdata'} else if(INCLUDE.BOTH == F & INCLUDE.ERICOID == F){included <- 'quant_noB_noE.Rdata'}


model <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,included, sep = '')) 
output <- as.data.frame(model$summary)
output <- output[-nrow(output),]

### SET UP ASSOCIATED DATA SUBSET
{
chosen.datt <- loadRData(paste('./Data_Setup/Data_Outputs/All.plots.',m,'m.Hegyi.all.centered.',x,'.20200928.Rdata', sep = '')) # final.datt # *** PUBLISHED = .20200928.Rdata ***
min.num <-2 # minimum number of subsetted individuals necessary to be included in analyses

### ---------------------- SUBSET TREES BY DIAMETER ---------------------- ###
{
  chosen.datt$REAL_DBH <- exp(chosen.datt$DBH)
  
  ## set threshold per plot / species
  species <- aggregate(chosen.datt$ID,by=list(chosen.datt$PLOT,chosen.datt$SPECIES),FUN=nrow)
  species$QUANT <-NA
  species<-species[,-3]
  
  for(i in 1:nrow(species)){ # shows the DBH at the given quantile
    species[i,'QUANT'] <- quantile(chosen.datt[chosen.datt$SPECIES == species[i,'Group.2'] &
                                                 chosen.datt$PLOT == species[i,'Group.1'],'REAL_DBH'],DBH.quant)
  }
  species<-species[order(species$Group.1),]

  chosen.datt$SUB <- NA
  for(i in 1:nrow(chosen.datt)){
    
    ifelse(DBH.quant == 1,
           chosen.datt[i,'SUB'] <- 1, 
           ifelse(DBH.quant > 0.5,
                  chosen.datt[i,'SUB'] <- ifelse(chosen.datt[i,'REAL_DBH'] >= species[species$Group.2==chosen.datt[i,'SPECIES'] &
                                                                                        species$Group.1==chosen.datt[i,'PLOT'],'QUANT'], 1, 0), 
                  chosen.datt[i,'SUB'] <- ifelse(chosen.datt[i,'REAL_DBH'] <= species[species$Group.2==chosen.datt[i,'SPECIES'] &
                                                                                        species$Group.1==chosen.datt[i,'PLOT'],'QUANT'], 1, 0)) )
  }
  
  subset.all <- chosen.datt[chosen.datt$SUB==1,]

  #### get summaries for MS tables ####-
  # subset.all$live <- ifelse(is.na(subset.all$MORT_DATE)==T, 1, 0)
  # subset.all$BA <- BA.function(subset.all$REAL_DBH)
  # species1 <- setNames(aggregate(subset.all$ID,by=list(subset.all$PLOT,subset.all$SPECIES),FUN=NROW),c('Group.1','Group.2','n'))
  # species1$BA <- aggregate(subset.all$BA,by=list(subset.all$PLOT,subset.all$SPECIES),FUN=sum)$x
  # species2 <- setNames(aggregate(subset.all$ID,by=list(subset.all$PLOT,subset.all$SPECIES,subset.all$live),FUN=NROW),c('Group.1','Group.2','status','status.n'))
  # species3 <- merge(species1,species,by=c('Group.1','Group.2'), all.x = T)
  # species3 <- merge(species3,species2[species2$status==0,c(1,2,4)],by=c('Group.1','Group.2'), all.x = T)
  # species3 <- merge(species3,species2[species2$status==1,c(1,2,4)],by=c('Group.1','Group.2'), all.x = T)
  # species3[is.na(species3)] <- 0
  # names(species3) <- c('plot', 'species', 'n', 'BA.meters', 'quant1.0', 'dead.n', 'live.n')
  # species3 <- merge(species3,guild_designations[,1:2],by.x='species', by.y = 'SPECIES', all.x = T)
  # write.csv(species3, file='Tables/All.plots.20m.analyzed.Hegyi.1DBHquant.20201102.csv')

}

### ---------------------- SUBSET TREES BY SPECIES ---------------------- ###
{
  subset.tree <- subset.all[subset.all$SPECIES %in% c('PIPO','PILO','ABBI','PIFL','PIPU','PIEN','PSME.G','PIED','JUSC','ABCO','TSHE','ABAM','TABR','PSME.M','ABPR','ABGR','THPL','PIMO','PILA','CADE','ABMA'),] # trees aka single-stem, non-vegetatively reproducing spp
  
  if(INCLUDE.BOTH==F & INCLUDE.ERICOID==F){
    subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD %in% c('ericoid','both'),'SPECIES']),]
    
  } else if(INCLUDE.BOTH==F & INCLUDE.ERICOID==T){
    subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='both','SPECIES']),]
    
  } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==F){
    subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES,guild_designations[guild_designations$GUILD=='ericoid','SPECIES']),]
    
  } else if(INCLUDE.BOTH==T & INCLUDE.ERICOID==T){
    subset.shrub <- subset.all[!subset.all$SPECIES %in% c(subset.tree$SPECIES),]
  }
  
  subset.all$SPECIES_NUM <- as.numeric(as.factor(subset.all$SPECIES))
  subset.tree$SPECIES_NUM <- as.numeric(as.factor(subset.tree$SPECIES))
  subset.shrub$SPECIES_NUM <- as.numeric(as.factor(subset.shrub$SPECIES))
  
  subset.all$BA <- BA.function(subset.all$REAL_DBH)
  subset.tree$BA <- BA.function(subset.tree$REAL_DBH)
  subset.shrub$BA <- BA.function(subset.shrub$REAL_DBH)
}

### ---------------------- SUBSET TREES BY min.num ---------------------- ###
{
  all.summary <- aggregate(subset.all$STEM_TAG, by=list(subset.all$PLOT,subset.all$SPECIES), FUN=NROW)
  tree.summary <- aggregate(subset.tree$STEM_TAG, by=list(subset.tree$PLOT,subset.tree$SPECIES), FUN=NROW)
  shrub.summary <- aggregate(subset.shrub$STEM_TAG, by=list(subset.shrub$PLOT,subset.shrub$SPECIES), FUN=NROW)
  
  plenty.all <- all.summary[all.summary$x >= min.num,]
  plenty.tree <- tree.summary[tree.summary$x >= min.num,]
  plenty.shrub <- shrub.summary[shrub.summary$x >= min.num,]
  
  subset.all$keep <- ifelse(subset.all$PLOT==1 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==1,'Group.2']), 1,
                            ifelse(subset.all$PLOT==2 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==2,'Group.2']), 1,
                                   ifelse(subset.all$PLOT==3 & (subset.all$SPECIES %in% plenty.all[plenty.all$Group.1==3,'Group.2']), 1,0)))
  subset.all <- subset.all[subset.all$keep == 1,] 
  
  subset.tree$keep <- ifelse(subset.tree$PLOT==1 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==1,'Group.2']), 1,
                             ifelse(subset.tree$PLOT==2 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==2,'Group.2']), 1,
                                    ifelse(subset.tree$PLOT==3 & (subset.tree$SPECIES %in% plenty.tree[plenty.tree$Group.1==3,'Group.2']), 1,0)))
  subset.tree <- subset.tree[subset.tree$keep == 1,]                                     
  
  subset.shrub$keep <- ifelse(subset.shrub$PLOT==1 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==1,'Group.2']), 1,
                              ifelse(subset.shrub$PLOT==2 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==2,'Group.2']), 1,
                                     ifelse(subset.shrub$PLOT==3 & (subset.shrub$SPECIES %in% plenty.shrub[plenty.shrub$Group.1==3,'Group.2']), 1,0)))
  subset.shrub <- subset.shrub[subset.shrub$keep == 1,]                                
  
}
}


##########################################################################################################

##########################################################################################################-
####################################        FINAL VALIDATIONS        #####################################-
#----------------------------------------------------------------------------------------------------------

### ---------------------- PREDICTIONS ---------------------- ###
if(FINAL.VALIDATIONS == T){
  anal.datt <- eval(parse(text= paste('subset.', g, sep = '')))   # choose which dataset to use for analysis
  
  ## covariates
  trees <- anal.datt$ID 
  plots <- anal.datt$PLOT
  
  cons <- anal.datt[,grep('con.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  het.s <- anal.datt[,grep('het.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  het.d <- anal.datt[,grep('het.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  rich.s <- anal.datt[,grep('rich.same.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  rich.d <- anal.datt[,grep('rich.diff.', colnames(anal.datt), fixed = TRUE, value = TRUE)]
  
  param <- as.matrix(cbind(cons,het.s,het.d,rich.s,rich.d))
  
  survival <- anal.datt$DA
  survival <- ifelse(survival==1,0,1)
  
  # linear model: use estimated betas to calculate survival probability / classification
  Xmat <- model.matrix(~as.factor(plots) + cons + het.s + het.d + rich.s + rich.d + (het.s*rich.s) + (het.d*rich.d) - 1) # with interaction 
  prob <- plogis(Xmat %*% output$mean)

  #create auc.roc plot
  ObsPred <- data.frame(survival, Predicted=prob)
  ObsPred$ID <- anal.datt$STEM_TAG
  ObsPred <- ObsPred[,c(3,1,2)]
  AUC <- roc.area(ObsPred[,2], ObsPred[,3])$A
  auc.roc.plot(ObsPred, xlab="1-Specificity (false positives)",
               ylab="Sensitivity (true positives)", main="ROC", color=TRUE,
               find.auc=TRUE, opt.thresholds=TRUE, opt.methods=9) 
  
  #update pred.surv with optimal cutoff value  ### MUST HARD CODE THIS BASED ON ABOVE PLOT
  cutoff<- 0.87
  pred.surv <- ifelse(prob>cutoff,1,0)
  class.sum(survival,pred.surv)
  
  #compare rates
  length(pred.surv[pred.surv==1]) / length(pred.surv) #predicted.survival.rate using cutoff 
  length(survival[survival==1]) / length(survival) #observed.survival.rate
  
  ## odds ratio of predicted neighborhood effects
  # exp(output[rownames(output) %in% c("beta1","beta2","beta3","beta4","beta5"),'mean']) 
  
}

##########################################################################################################

##########################################################################################################-
#####################################     FINAL VISUALIZATIONS    ########################################-
#----------------------------------------------------------------------------------------------------------

plot.names <- c('Wind River, WA','Yosemite, CA','Cedar Breaks, UT')
param.names <- c('Conspecifics','Heterospecifics: Shared','Heterospecifics: Different','Richness: Shared','Richness: Different', 'Interaction: Shared', 'Interaction: Different')
plots <- c(1,2,3)

 # interactions plots
{
  
  ### use same specified covariate ranges  for all - m and x will be pre-specified, but should be the same for combos of shrub/tree or diameter subset ### 
  {
    ## covariates
    cons <- rep(mean(chosen.datt[,grep('con.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),3)
    het.s <- rep(mean(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),3)
    het.d <- rep(mean(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),3)
    rich.s <- rep(mean(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),3)
    rich.d <- rep(mean(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)]),3)
    
    ## set interaction bounds -- absolute high and low (used in ms)
    rich.s.max <- rep(as.numeric(summary(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),3)
    rich.s.min <- rep(as.numeric(summary(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),3)

    het.s.max <- rep(as.numeric(summary(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),3)
    het.s.min <- rep(as.numeric(summary(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),3)

    rich.d.max <- rep(as.numeric(summary(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),3)
    rich.d.min <- rep(as.numeric(summary(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),3)

    het.d.max <- rep(as.numeric(summary(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[6]),3)
    het.d.min <- rep(as.numeric(summary(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)])[1]),3)
    
    
    ## set interaction bounds -- percentiles high and low (compare for reviewer)
    # rich.s.max <- rep(as.numeric(quantile(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.99)),3)
    # rich.s.min <- rep(as.numeric(quantile(chosen.datt[,grep('rich.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.01)),3)
    # 
    # het.s.max <- rep(as.numeric(quantile(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.99)),3)
    # het.s.min <- rep(as.numeric(quantile(chosen.datt[,grep('het.same.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.01)),3)
    # 
    # rich.d.max <- rep(as.numeric(quantile(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.99)),3)
    # rich.d.min <- rep(as.numeric(quantile(chosen.datt[,grep('rich.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.01)),3)
    # 
    # het.d.max <- rep(as.numeric(quantile(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.99)),3)
    # het.d.min <- rep(as.numeric(quantile(chosen.datt[,grep('het.diff.', colnames(chosen.datt), fixed = TRUE, value = TRUE)],0.01)),3)
    
  }
  
  ## ---------------------- INTERACTION PLOTS ---------------------- ###
  {

    ########   SAME GUILD INTERACTIONS   ######## -
    sg.Xmat.min.min <- model.matrix(~as.factor(plots) + cons + het.s.min + het.d + rich.s.min + rich.d + (het.s.min*rich.s.min) + (het.d*rich.d) - 1) # with interaction 
    sg.prob.min.min <- plogis(sg.Xmat.min.min %*% output$mean)
    sg.prob.min.min.lo <- plogis(sg.Xmat.min.min %*% output$`2.5%`)
    sg.prob.min.min.hi <- plogis(sg.Xmat.min.min %*% output$`97.5%`)
    
    sg.Xmat.min.max <- model.matrix(~as.factor(plots) + cons + het.s.min + het.d + rich.s.max + rich.d + (het.s.min*rich.s.max) + (het.d*rich.d) - 1) # with interaction 
    sg.prob.min.max <- plogis(sg.Xmat.min.max %*% output$mean)
    sg.prob.min.max.lo <- plogis(sg.Xmat.min.max %*% output$`2.5%`)
    sg.prob.min.max.hi <- plogis(sg.Xmat.min.max %*% output$`97.5%`)
    
    sg.Xmat.max.max <- model.matrix(~as.factor(plots) + cons + het.s.max + het.d + rich.s.max + rich.d + (het.s.max*rich.s.max) + (het.d*rich.d) - 1) # with interaction 
    sg.prob.max.max <- plogis(sg.Xmat.max.max %*% output$mean)
    sg.prob.max.max.lo <- plogis(sg.Xmat.max.max %*% output$`2.5%`)
    sg.prob.max.max.hi <- plogis(sg.Xmat.max.max %*% output$`97.5%`)
    
    sg.Xmat.max.min <- model.matrix(~as.factor(plots) + cons + het.s.max + het.d + rich.s.min + rich.d + (het.s.max*rich.s.min) + (het.d*rich.d) - 1) # with interaction 
    sg.prob.max.min <- plogis(sg.Xmat.max.min %*% output$mean)
    sg.prob.max.min.lo <- plogis(sg.Xmat.max.min %*% output$`2.5%`)
    sg.prob.max.min.hi <- plogis(sg.Xmat.max.min %*% output$`97.5%`)
    
    sg.all.probs <- data.frame("prob" = c(sg.prob.min.min,sg.prob.min.max,sg.prob.max.max,sg.prob.max.min),
                               "prob.lo" = c(sg.prob.min.min.lo,sg.prob.min.max.lo,sg.prob.max.max.lo,sg.prob.max.min.lo),
                               "prob.hi" = c(sg.prob.min.min.hi,sg.prob.min.max.hi,sg.prob.max.max.hi,sg.prob.max.min.hi),
                               "model" = c(rep("minmin",3),rep("minmax",3),rep('maxmax',3),rep('maxmin',3)),
                               "plot" = rep(c(1:3),4),
                               "het.s" = factor(c(rep("low",6),rep('high',6)),levels = c('low','high')),
                               "rich.s" = factor(c(rep("low",3),rep('high',6),rep("low",3)),levels = c('low','high')))

    inx.same <- ggplot(data = sg.all.probs, aes(x = het.s, y = prob, colour=rich.s, linetype = as.factor(plot), group = interaction(rich.s,plot))) + 
      geom_line(size=1) + geom_point(size=3) + coord_cartesian(ylim = c(0,1)) +
      # geom_errorbar(aes(ymax = prob.hi, ymin = prob.lo), width=.1, alpha = 0.7, position=position_dodge(0.1), show.legend=FALSE) +
      theme_prefs + theme(legend.position = "none") +
      theme(legend.title = element_blank()) +
      labs(x="",y="")
    
    
    ########   DIFFERENT GUILD INTERACTIONS   ######## -
    
    dg.Xmat.min.min <- model.matrix(~as.factor(plots) + cons + het.s + het.d.min + rich.s + rich.d.min + (het.s*rich.s) + (het.d.min*rich.d.min) - 1) # with interaction 
    dg.prob.min.min <- plogis(dg.Xmat.min.min %*% output$mean)
    dg.prob.min.min.lo <- plogis(dg.Xmat.min.min %*% output$`2.5%`)
    dg.prob.min.min.hi <- plogis(dg.Xmat.min.min %*% output$`97.5%`)
    
    dg.Xmat.min.max <- model.matrix(~as.factor(plots) + cons + het.s + het.d.min + rich.s + rich.d.max + (het.s*rich.s) + (het.d.min*rich.d.max) - 1) # with interaction 
    dg.prob.min.max <- plogis(dg.Xmat.min.max %*% output$mean)
    dg.prob.min.max.lo <- plogis(dg.Xmat.min.max %*% output$`2.5%`)
    dg.prob.min.max.hi <- plogis(dg.Xmat.min.max %*% output$`97.5%`)
    
    dg.Xmat.max.max <- model.matrix(~as.factor(plots) + cons + het.s + het.d.max + rich.s + rich.d.max + (het.s*rich.s) + (het.d.max*rich.d.max) - 1) # with interaction 
    dg.prob.max.max <- plogis(dg.Xmat.max.max %*% output$mean)
    dg.prob.max.max.lo <- plogis(dg.Xmat.max.max %*% output$`2.5%`)
    dg.prob.max.max.hi <- plogis(dg.Xmat.max.max %*% output$`97.5%`)
    
    dg.Xmat.max.min <- model.matrix(~as.factor(plots) + cons + het.s + het.d.max + rich.s + rich.d.min + (het.s*rich.s) + (het.d.max*rich.d.min) - 1) # with interaction 
    dg.prob.max.min <- plogis(dg.Xmat.max.min %*% output$mean)
    dg.prob.max.min.lo <- plogis(dg.Xmat.max.min %*% output$`2.5%`)
    dg.prob.max.min.hi <- plogis(dg.Xmat.max.min %*% output$`97.5%`)
    
    dg.all.probs <- data.frame("prob" = c(dg.prob.min.min,dg.prob.min.max,dg.prob.max.max,dg.prob.max.min),
                               "prob.lo" = c(dg.prob.min.min.lo,dg.prob.min.max.lo,dg.prob.max.max.lo,dg.prob.max.min.lo),
                               "prob.hi" = c(dg.prob.min.min.hi,dg.prob.min.max.hi,dg.prob.max.max.hi,dg.prob.max.min.hi),
                               "model" = c(rep("minmin",3),rep("minmax",3),rep('maxmax',3),rep('maxmin',3)),
                               "plot" = rep(c(1:3),4),
                               "rich.d" = factor(c(rep("low",3),rep('high',6),rep("low",3)),levels = c('low','high')),
                               "het.d" = factor(c(rep("low",6),rep('high',6)),levels = c('low','high')))
    
    inx.diff <- ggplot(data = dg.all.probs, aes(x = het.d, y = prob, colour=rich.d, linetype = as.factor(plot), group = interaction(rich.d,plot))) + 
      geom_line(size=1) + geom_point(size=3) + coord_cartesian(ylim = c(0,1)) +
      # geom_errorbar(aes(ymax = prob.hi, ymin = prob.lo), width=.1, alpha = 0.7, position=position_dodge(0.1), show.legend=FALSE) +
      theme_prefs + theme(legend.position = "none") +
      # theme(legend.title = element_blank()) + 
      labs(x="",y="")
    
    plot<-plot_grid(inx.same,inx.diff, nrow=2, ncol=1, align='v')
    y.grob<-textGrob("Survival Probability", gp=gpar(col="black", fontsize=10), rot=90)
    x.grob<-textGrob("Crowding", gp=gpar(col="black", fontsize=10))
    gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
    # dev.print(file= paste('./Figures/obs_hegyirich_model_INX_',g,'_',x,'_',m,'m_',DBH.quant,'quant_0.99v0.01_inxplot.tif',sep = ''),tiff,width=5,height=4,res=600,units='in',compression='lzw')
  }
  
}

 # all parameters, big and small separate
{
  model.tree.large <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_tree_',x,'_',m,'m_0.9quant.Rdata',sep = '')) 
  output.tree.large <- as.data.frame(model.tree.large$summary)
  output.tree.large <- output.tree.large[-nrow(output.tree.large),]
  
  model.tree.small <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_tree_',x,'_',m,'m_0.1quant.Rdata',sep = '')) 
  output.tree.small <- as.data.frame(model.tree.small$summary)
  output.tree.small <- output.tree.small[-nrow(output.tree.small),]
  
  model.shrub.large <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_shrub_',x,'_',m,'m_0.9quant.Rdata',sep = '')) 
  output.shrub.large <- as.data.frame(model.shrub.large$summary)
  output.shrub.large <- output.shrub.large[-nrow(output.shrub.large),]
  
  model.shrub.small <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_shrub_',x,'_',m,'m_0.1quant.Rdata',sep = '')) 
  output.shrub.small <- as.data.frame(model.shrub.small$summary)
  output.shrub.small <- output.shrub.small[-nrow(output.shrub.small),]
  
  output.tree.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.tree.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.shrub.small$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.shrub.large$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  
  output.tree.large$names=as.numeric(output.tree.large$names) - 0.15
  output.shrub.small$names=as.numeric(output.shrub.small$names) - 0.30
  output.shrub.large$names=as.numeric(output.shrub.large$names) - 0.45
  
  output.tree.small$color <- 'green'
  output.tree.large$color <- 'blue'
  output.shrub.small$color <- 'orange'
  output.shrub.large$color <- 'red'
  
  output.tree.small$signif <- ifelse(output.tree.small$`97.5%` <= 0 & output.tree.small$`2.5%` <=0, 21,
                                     ifelse(output.tree.small$`97.5%` >= 0 & output.tree.small$`2.5%` >=0, 21, 1))
  output.tree.large$signif <- ifelse(output.tree.large$`97.5%` <= 0 & output.tree.large$`2.5%` <=0, 21,
                                     ifelse(output.tree.large$`97.5%` >= 0 & output.tree.large$`2.5%` >=0, 21, 1))
  output.shrub.small$signif <- ifelse(output.shrub.small$`97.5%` <= 0 & output.shrub.small$`2.5%` <=0, 21,
                                      ifelse(output.shrub.small$`97.5%` >= 0 & output.shrub.small$`2.5%` >=0, 21, 1))
  output.shrub.large$signif <- ifelse(output.shrub.large$`97.5%` <= 0 & output.shrub.large$`2.5%` <=0, 21,
                                      ifelse(output.shrub.large$`97.5%` >= 0 & output.shrub.large$`2.5%` >=0, 21, 1))
  
  output.tree.small$oddsmean <- exp(output.tree.small$mean)
  output.tree.large$oddsmean <- exp(output.tree.large$mean)
  output.tree.small$oddslo <- exp(output.tree.small$`2.5%`)
  output.tree.large$oddslo <- exp(output.tree.large$`2.5%`)
  output.tree.small$oddshi <- exp(output.tree.small$`97.5%`)
  output.tree.large$oddshi <- exp(output.tree.large$`97.5%`)
  
  output.shrub.small$oddsmean <- exp(output.shrub.small$mean)
  output.shrub.large$oddsmean <- exp(output.shrub.large$mean)
  output.shrub.small$oddslo <- exp(output.shrub.small$`2.5%`)
  output.shrub.large$oddslo <- exp(output.shrub.large$`2.5%`)
  output.shrub.small$oddshi <- exp(output.shrub.small$`97.5%`)
  output.shrub.large$oddshi <- exp(output.shrub.large$`97.5%`)
  
  ### ---------------------- ALL BETAS, ALL MODELS ---------------------- ###
  
  # ggplot(data=output.tree.small, aes(x=oddsmean, y=names)) + 
  #   xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
  #   coord_cartesian(ylim = c(0.5,10.5)) +
  #   geom_point(data=output.tree.small, color = output.tree.small$color, fill = output.tree.small$color, shape = output.tree.small$signif) + 
  #   geom_errorbarh(data=output.tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   geom_point(data=output.tree.large, color = output.tree.large$color, fill = output.tree.large$color, shape = output.tree.large$signif) +
  #   geom_errorbarh(data=output.tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   geom_point(data=output.shrub.small, color = output.shrub.small$color, fill = output.shrub.small$color, shape = output.shrub.small$signif) + 
  #   geom_errorbarh(data=output.shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   geom_point(data=output.shrub.large, color = output.shrub.large$color, fill = output.shrub.large$color, shape = output.shrub.large$signif) +
  #   geom_errorbarh(data=output.shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   theme_prefs + scale_x_log10(breaks = base_breaks())
  # dev.print(file='./Figures/obs_hegyirich_model_BIG_SPP90_INX_shrubtree_20000_oddsratio.tif',tiff,width=6,height=6,res=600,units='in',compression='lzw')
  
  ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  
  tree.large$names=factor(param.names, levels = param.names)
  tree.small$names=factor(param.names, levels = param.names)
  shrub.large$names=factor(param.names, levels = param.names)
  shrub.small$names=factor(param.names, levels = param.names)
  
  tree.large$names=as.numeric(tree.large$names)-0.15
  shrub.small$names=as.numeric(shrub.small$names)-0.30
  shrub.large$names=as.numeric(shrub.large$names)-0.45

  ggplot(data=tree.small, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=tree.small, color = tree.small$color, fill = tree.small$color, shape = tree.small$signif) + 
    geom_errorbarh(data=tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=tree.large, color = tree.large$color, fill = tree.large$color, shape = tree.large$signif) + 
    geom_errorbarh(data=tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=shrub.small, color = shrub.small$color, fill = shrub.small$color, shape = shrub.small$signif) + 
    geom_errorbarh(data=shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=shrub.large, color = shrub.large$color, fill = shrub.large$color, shape = shrub.large$signif) + 
    geom_errorbarh(data=shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_',x,'_',m,'m_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  

  ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  plots.tree.large <- output.tree.large[rownames(output.tree.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.tree.small <- output.tree.small[rownames(output.tree.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.shrub.large <- output.shrub.large[rownames(output.shrub.large) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.shrub.small <- output.shrub.small[rownames(output.shrub.small) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  
  plots.tree.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.tree.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.shrub.large$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.shrub.small$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  
  plots.tree.large$names=as.numeric(plots.tree.large$names)-0.15
  plots.shrub.small$names=as.numeric(plots.shrub.small$names)-0.30
  plots.shrub.large$names=as.numeric(plots.shrub.large$names)-0.45
  
  ggplot(data=plots.tree.small, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=plots.tree.small, color = plots.tree.small$color, fill = plots.tree.small$color, shape = plots.tree.small$signif) + 
    geom_errorbarh(data=plots.tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.tree.large, color = plots.tree.large$color, fill = plots.tree.large$color, shape = plots.tree.large$signif) + 
    geom_errorbarh(data=plots.tree.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.shrub.small, color = plots.shrub.small$color, fill = plots.shrub.small$color, shape = plots.shrub.small$signif) + 
    geom_errorbarh(data=plots.shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.shrub.large, color = plots.shrub.large$color, fill = plots.shrub.large$color, shape = plots.shrub.large$signif) + 
    geom_errorbarh(data=plots.shrub.large, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_',x,'_',m,'m_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
} 

# all parameters, big and small combined
{
  model.all.all <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_all_',x,'_',m,'m_1quant.Rdata',sep = '')) 
  output.all.all <- as.data.frame(model.all.all$summary)
  output.all.all <- output.all.all[-nrow(output.all.all),]
  
  model.tree.all <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_tree_',x,'_',m,'m_1quant.Rdata',sep = '')) 
  output.tree.all <- as.data.frame(model.tree.all$summary)
  output.tree.all <- output.tree.all[-nrow(output.tree.all),]
  
  model.shrub.all <- loadRData(file = paste('Jags/Output.Final/obs_hegyirich_model_INX_shrub_',x,'_',m,'m_1quant.Rdata',sep = '')) 
  output.shrub.all <- as.data.frame(model.shrub.all$summary)
  output.shrub.all <- output.shrub.all[-nrow(output.shrub.all),]
  
  output.tree.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.shrub.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  output.all.all$names=factor(c(plot.names,param.names), levels = c(plot.names,param.names))
  
  output.tree.all$names=as.numeric(output.tree.all$names) - 0.15
  output.shrub.all$names=as.numeric(output.shrub.all$names) - 0.30
  
  output.tree.all$color <- 'blue'
  output.shrub.all$color <- 'red'
  output.all.all$color <- 'black'
  
  output.tree.all$signif <- ifelse(output.tree.all$`97.5%` <= 0 & output.tree.all$`2.5%` <=0, 21,
                                     ifelse(output.tree.all$`97.5%` >= 0 & output.tree.all$`2.5%` >=0, 21, 1))
  output.shrub.all$signif <- ifelse(output.shrub.all$`97.5%` <= 0 & output.shrub.all$`2.5%` <=0, 21,
                                      ifelse(output.shrub.all$`97.5%` >= 0 & output.shrub.all$`2.5%` >=0, 21, 1))
  output.all.all$signif <- ifelse(output.all.all$`97.5%` <= 0 & output.all.all$`2.5%` <=0, 21,
                                    ifelse(output.all.all$`97.5%` >= 0 & output.all.all$`2.5%` >=0, 21, 1))
  
  output.all.all$oddsmean <- exp(output.all.all$mean)
  output.all.all$oddslo <- exp(output.all.all$`2.5%`)
  output.all.all$oddshi <- exp(output.all.all$`97.5%`)
  
  output.tree.all$oddsmean <- exp(output.tree.all$mean)
  output.tree.all$oddslo <- exp(output.tree.all$`2.5%`)
  output.tree.all$oddshi <- exp(output.tree.all$`97.5%`)
  
  output.shrub.all$oddsmean <- exp(output.shrub.all$mean)
  output.shrub.all$oddslo <- exp(output.shrub.all$`2.5%`)
  output.shrub.all$oddshi <- exp(output.shrub.all$`97.5%`)
  
  ### ---------------------- ALL BETAS, ALL MODELS ---------------------- ###
  
  # ggplot(data=output.tree.small, aes(x=oddsmean, y=names)) + 
  #   xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
  #   coord_cartesian(ylim = c(0.5,10.5)) +
  #   geom_point(data=output.tree.small, color = output.tree.small$color, fill = output.tree.small$color, shape = output.tree.small$signif) + 
  #   geom_errorbarh(data=output.tree.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   geom_point(data=output.tree.all, color = output.tree.all$color, fill = output.tree.all$color, shape = output.tree.all$signif) +
  #   geom_errorbarh(data=output.tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   geom_point(data=output.shrub.small, color = output.shrub.small$color, fill = output.shrub.small$color, shape = output.shrub.small$signif) + 
  #   geom_errorbarh(data=output.shrub.small, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   geom_point(data=output.shrub.all, color = output.shrub.all$color, fill = output.shrub.all$color, shape = output.shrub.all$signif) +
  #   geom_errorbarh(data=output.shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
  #   theme_prefs + scale_x_log10(breaks = base_breaks())
  # dev.print(file='./Figures/obs_hegyirich_model_BIG_SPP90_INX_shrubtree_20000_oddsratio.tif',tiff,width=6,height=6,res=600,units='in',compression='lzw')
  
  ## ---------------------- NEIGHBOR BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  all.all <- output.all.all[rownames(output.all.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]
  shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta1","beta2","beta3","beta4","beta5","beta6", "beta7"),]

  all.all$names=factor(param.names, levels = param.names)
  tree.all$names=factor(param.names, levels = param.names)
  shrub.all$names=factor(param.names, levels = param.names)

  tree.all$names=as.numeric(tree.all$names)-0.15
  shrub.all$names=as.numeric(shrub.all$names)-0.30
  
  ggplot(data=all.all, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=all.all, color = all.all$color, fill = all.all$color, shape = all.all$signif) + 
    geom_errorbarh(data=all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=tree.all, color = tree.all$color, fill = tree.all$color, shape = tree.all$signif) + 
    geom_errorbarh(data=tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=shrub.all, color = shrub.all$color, fill = shrub.all$color, shape = shrub.all$signif) + 
    geom_errorbarh(data=shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n=5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_',x,'_',m,'m_alldiams_allspp_oddsratio_fixed.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
  
  ## ---------------------- PLOT BETAS, ALL MODELS ---------------------- ###
  
  # with interaction 
  plots.all.all <- output.all.all[rownames(output.all.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.tree.all <- output.tree.all[rownames(output.tree.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]
  plots.shrub.all <- output.shrub.all[rownames(output.shrub.all) %in% c("beta0[1]","beta0[2]","beta0[3]","beta3"),]

  plots.all.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.tree.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))
  plots.shrub.all$names=factor(c(plot.names,'Heterospecifics: Different'), levels = c(plot.names,'Heterospecifics: Different'))

  plots.tree.all$names=as.numeric(plots.tree.all$names)-0.15
  plots.shrub.all$names=as.numeric(plots.shrub.all$names)-0.30
  
  ggplot(data=plots.tree.all, aes(x=oddsmean, y=names)) + 
    xlab('Odds Ratio')  +  ylab('')  +   geom_vline(linetype='dashed', aes(xintercept=1)) + 
    coord_cartesian(ylim = c(0.75,7)) +
    geom_point(data=plots.all.all, color = plots.all.all$color, fill = plots.all.all$color, shape = plots.all.all$signif) + 
    geom_errorbarh(data=plots.all.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.tree.all, color = plots.tree.all$color, fill = plots.tree.all$color, shape = plots.tree.all$signif) + 
    geom_errorbarh(data=plots.tree.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    geom_point(data=plots.shrub.all, color = plots.shrub.all$color, fill = plots.shrub.all$color, shape = plots.shrub.all$signif) + 
    geom_errorbarh(data=plots.shrub.all, aes(xmax = oddshi,xmin = oddslo, height = 0), colour='black',show.legend=FALSE) +
    theme_prefs + scale_x_log10(breaks = base_breaks(n = 5))
  # dev.print(file=paste('./Figures/obs_hegyirich_model_INX_',x,'_',m,'m_alldiams_allspp_oddsratio_random.tif',sep = ''),tiff,width=6.7,height=2.5,res=600,units='in',compression='lzw')
  
} 

##########################################################################################################


