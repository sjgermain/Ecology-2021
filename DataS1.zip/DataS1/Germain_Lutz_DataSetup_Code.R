######################################
#                                    #
#  Code for:                         #
#    Shared friends > shared enemies #
#  Code author:                      #
#    Sara Germain                    #
#  Function credits:                 #
#    Richard Cutler (two functions)  #
#    Daniel Johnson (one function)   #
#  Code contents:                    #
#    Neighborhood calculations       #
#    Data setup for analyses         #
#                                    #
######################################


## SET INITIAL CONDITIONS, THEN SOURCE CODE ##

DATA.SETUP=T        # choose F if "initialize data" code has been run, file saved 
RUN.NEIGHBORHOOD=F   # choose F if "initialize data" code has been run, file saved 
LOAD.NEIGHBORS=T     # choose T if "initialize data" code has been run, file saved; opens global environment saved from "initialize data" phase

RUN.SPECIALISTS=F    # choose T to subset data by specialist mort agent, save separate file *** PUBLISHED = F ***
RUN.GENERALISTS=F    # choose T to subset data by generalist mort agent, save separate file *** PUBLISHED = F ***

CENTER.HEGYI=T       # center cons, het.d, and het.s neighborhood values by species and DBH bin *** PUBLISHED = T ***

ERICOID.SAME=F       # categorize ericoids as EcM for neighborhood analyses *** PUBLISHED = F ***
BOTH.SAME=F          # categorize species forming dual mycorrhizas (AM / EM) as "sharing" both guilds *** PUBLISHED = F  ***

##########################################################################################################-
##########################################          LIBFUN          ######################################-
#----------------------------------------------------------------------------------------------------------

library(ggplot2)

BA.function = function(tree.DBH){
  return(0.0001*(pi*((0.5*tree.DBH)^2)))
} # BA in square meters

# calculate neighborhood influence values - *** Hegyi without DBH ratio ***
hegyi <- function(focal.DBH, neighbor.DBH, distance){
  return(neighbor.DBH/(1+distance))}

# sum Hegyi values for all members of neighborhood per mycorrhizal guild
# this function was adapted from one initially written by Daniel Johnson, University of Florida.
Myco.DD <- function(data.row, plot.data, neighborhood.size)  {  
  x.row <- data.row$PLOT_X
  y.row <- data.row$PLOT_Y
  spp <- data.row$SPECIES_NUM
  guild <- data.row$GUILD_NUM
  size <- data.row$DBH
  focal.tag <- data.row$STEM_TAG
  year <- data.row$CENSUS

  
  for(n in neighborhood.size){
    # Create a smaller data set which only includes stems that are within a square around the focal point (and does not include the focal individual)
    # this makes the next step faster, when we calculate the exact distance between the focal individual and its neighbors
    # make sure focal individuals are in same census year
    square <- plot.data[plot.data$CENSUS==year & plot.data$PLOT_X<=x.row+n & plot.data$PLOT_X>=x.row-n & 
                          plot.data$PLOT_Y<=y.row+n & plot.data$PLOT_Y>=y.row-n,]
    square$dist <- ( ( square$PLOT_X - x.row )^2 + ( square$PLOT_Y - y.row )^2 )     # calculate distance between neighbors and focal tree
    neighb <- as.matrix(square[square$dist<=I(n^2) & square$STEM_TAG!=focal.tag, c('DBH','dist','GUILD_NUM','SPECIES_NUM', 'DA')])
    
    # the next for loop goes through each row of live tree data to calculate its hegyi value
    if(data.row[,'GUILD_NUM']%in%c(1,2)){
      
      if(BOTH.SAME==F){
        assign(paste('het.same',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('het.diff',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('con',n,sep = '.'), sum( ifelse((neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('rich.same',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('rich.diff',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.same',n,sep = '.'), length(neighb[neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM']))
        assign(paste('den.diff',n,sep = '.'), length(neighb[neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM']))
        
        
      } else if(BOTH.SAME==T){
        assign(paste('het.same',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM'] %in% c(4,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('het.diff',n,sep = '.'), sum( ifelse((!neighb[,'GUILD_NUM'] %in% c(4,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('con',n,sep = '.'), sum( ifelse((neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('rich.same',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM'] %in% c(4,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('rich.diff',n,sep = '.'), length (unique(neighb[!neighb[,'GUILD_NUM'] %in% c(4,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.same',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM'] %in% c(4,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.diff',n,sep = '.'), length((neighb[!neighb[,'GUILD_NUM'] %in% c(4,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
      
        }
      
    } else if(data.row[,'GUILD_NUM']==3){
      
      if(ERICOID.SAME==F){
        assign(paste('het.same',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('het.diff',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('con',n,sep = '.'), sum( ifelse((neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('rich.same',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('rich.diff',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.same',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.diff',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        
        
      } else if(ERICOID.SAME==T){
        assign(paste('het.same',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM'] %in% c(2,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('het.diff',n,sep = '.'), sum( ifelse((!neighb[,'GUILD_NUM'] %in% c(2,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('con',n,sep = '.'), sum( ifelse((neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('rich.same',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM'] %in% c(2,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('rich.diff',n,sep = '.'), length (unique(neighb[!neighb[,'GUILD_NUM'] %in% c(2,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.same',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM'] %in% c(2,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.diff',n,sep = '.'), length((neighb[!neighb[,'GUILD_NUM'] %in% c(2,guild) & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
      }
      
    } else if(data.row[,'GUILD_NUM']==4){
      
      if(BOTH.SAME==F){
        assign(paste('het.same',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('het.diff',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('con',n,sep = '.'), sum( ifelse((neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('rich.same',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('rich.diff',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.same',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM']== guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.diff',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM']!= guild & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        
        
      } else if(BOTH.SAME==T){
        assign(paste('het.same',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']!=3 & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('het.diff',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']==3 & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('con',n,sep = '.'), sum( ifelse((neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
        assign(paste('rich.same',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']!=3 & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('rich.diff',n,sep = '.'), length (unique(neighb[neighb[,'GUILD_NUM']==3 & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.same',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM']!=3 & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
        assign(paste('den.diff',n,sep = '.'), length((neighb[neighb[,'GUILD_NUM']==3 & neighb[,'SPECIES_NUM']!=spp & neighb[,'DA'] == 0,'SPECIES_NUM'])))
      }
      
    } else ''
    
    assign(paste('AM',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']==1 & neighb[, 'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
    assign(paste('EM',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']==2 & neighb[, 'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))     # calculate hegyi of EM neighbors
    assign(paste('ericoid',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']==3 & neighb[, 'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
    assign(paste('both',n,sep = '.'), sum( ifelse((neighb[,'GUILD_NUM']==4 & neighb[, 'DA'] == 0), hegyi(size,neighb[,'DBH'],neighb[,'dist']),0), na.rm=T))
    assign(paste('richness',n,sep = '.'), length(unique(neighb[,'SPECIES_NUM'])))
    assign(paste('den.total',n,sep = '.'), length(neighb[neighb[,'DA'] == 0,'SPECIES_NUM']))
    assign(paste('den.cons',n,sep = '.'), length(neighb[neighb[,'SPECIES_NUM']==spp & neighb[,'DA'] == 0,'SPECIES_NUM']))
  
    rm(neighb)
    rm(square)
  }
  
  # fill in tmp.mat data.frame with all neighborhood.size tables just created
  tmp.mat <-c(mapply(function(x){eval(parse(text=x))}, grep('het.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('con.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('rich.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('EM.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('AM.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('ericoid.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('both.', ls(), fixed = TRUE, value = TRUE) ),
               mapply(function(x){eval(parse(text=x))}, grep('richness.', ls(), fixed = TRUE, value = TRUE) ),
              mapply(function(x){eval(parse(text=x))}, grep('den.', ls(), fixed = TRUE, value = TRUE) )   )
  # if(length(tmp.mat)!=14*length(neighborhood.size)){stop('error')}
  return(tmp.mat)
}


# for DBH bins
mround<-function(x,base){
  base*round((x-(base/2-0.1))/base)
}

#standardizing function for species-specific influences
stand = function(focal.influence,mean.influence,sd.influence){
  (focal.influence-mean.influence)/sd.influence
}

#centering function
center = function(focal.influence,mean.influence){
  focal.influence-mean.influence
}

# model validation
# these functions were written by Richard Cutler, Utah State University
kappa=function(x){
  n=sum(x)
  pobs=(x[1,1]+x[2,2])/n
  pexp=(sum(x[1,])*sum(x[,1])+sum(x[2,])*sum(x[,2]))/n^2
  kappa=(pobs-pexp)/(1-pexp)
  t1=0
  t2=0
  t3=0
  pii=x/n
  pidot=apply(pii,1,sum)
  pdotj=apply(pii,2,sum)
  for(i in 1:2){
    t1 = t1 + pii[i,i]*((1-pexp) - (1-pobs)*(pidot[i]+pdotj[i]))^2
  }
  t2 = pii[1,2]*(pdotj[1]+pidot[2])^2 + pii[2,1]*(pdotj[2] + pidot[1])^2
  t3 = (pobs*pexp-2*pexp+pobs)^2
  vhat = (t1 + t2*(1-pobs)^2 -t3)/(n*(1-pexp)^4)
  se=sqrt(vhat)
  return(c(kappa,se))
}

class.sum=function(truth,predicted){
  xt=table(truth,round(predicted+0.000001))
  pcc=round(100*sum(diag(xt))/sum(xt),2)
  spec=round(100*xt[1,1]/sum(xt[1,]),2)
  sens=round(100*xt[2,2]/sum(xt[2,]),2)
  kap=round(kappa(xt)[1],4)
  return(cbind(c("Percent Correctly Classified = ","Specificity = ","Sensitivity = ","Kappa ="),c(pcc,spec,sens,kap)))
}

# plotting
theme_prefs<-theme_classic() + theme(axis.title.x = element_text(size=10),
                                     axis.title.y = element_text(size=10),
                                     axis.text.x = element_text(size=10, colour='black'),
                                     axis.text.y = element_text(size=10, colour='black'),
                                     axis.ticks = element_line(colour='black'),
                                     legend.text = element_text(size=8),
                                     legend.title = element_text(size=8),
                                     plot.title=element_text(size=10,hjust=0.5, vjust=-3))

##########################################################################################################

##########################################################################################################-
#########################################       INITIALIZE DATA      #####################################-
#----------------------------------------------------------------------------------------------------------

guild_designations<-read.csv("./Data_Setup/Raw_Data/guild_designations.csv",na.strings='NULL')
guild_designations$SPECIES <- as.character(guild_designations$SPECIES)
guild_designations$GUILD <- as.character(guild_designations$GUILD)

if(DATA.SETUP==T){
  WFDP_Tree<-read.csv("./Data_Setup/Raw_Data/WFDP_Tree.csv",na.strings='NULL')
  UFDP_Tree<-read.csv("./Data_Setup/Raw_Data/UFDP_Tree.csv",na.strings='NULL')
  YFDP_Tree<-read.csv("./Data_Setup/Raw_Data/YFDP_Tree.csv",na.strings='NULL')
  
  WFDP_Tree$STEM_TAG <- as.character(WFDP_Tree$STEM_TAG)
  UFDP_Tree$STEM_TAG <- as.character(UFDP_Tree$STEM_TAG)
  YFDP_Tree$STEM_TAG <- as.character(YFDP_Tree$STEM_TAG)
  
  WFDP_Tree$SPECIES <- as.character(WFDP_Tree$SPECIES)
  UFDP_Tree$SPECIES <- as.character(UFDP_Tree$SPECIES)
  YFDP_Tree$SPECIES <- as.character(YFDP_Tree$SPECIES)
  
  # make _IN_YR column to show when trees entered dataset
  YFDP_Tree <- YFDP_Tree[YFDP_Tree$DA != 'CWD',]
  YFDP_inyr<-aggregate(YFDP_Tree$CENSUS,by=list(YFDP_Tree$STEM_TAG),FUN=function(x) return(min(x)))
  colnames(YFDP_inyr) <- c('STEM_TAG','IN_YR')
  
  YFDP_sum<-aggregate(YFDP_inyr,by=list(YFDP_inyr$IN_YR),FUN=NROW)
  
  YFDP_tot<-aggregate(YFDP_Tree$CENSUS,by=list(YFDP_Tree$STEM_TAG),FUN=function(x) return(max(x)))
  colnames(YFDP_tot) <- c('STEM_TAG','CENSUS')
  
  YFDP_temp <- merge(YFDP_Tree,YFDP_tot, by=c('STEM_TAG','CENSUS'), all.y = T)
  YFDP_Final <- merge(YFDP_temp,YFDP_inyr[,c('STEM_TAG','IN_YR')], by='STEM_TAG', all.x = T)
  
  nrow(YFDP_Final) == sum(YFDP_sum$IN_YR) # NEEDS TO BE TRUE! this is all trees that were ever in the dataset. Should match total for final YFDP treelist
  head(YFDP_Final[is.na(YFDP_Final$DBH)==T,]) # check for missing DBH
  
  #pick biggest DBH / most recent measurement for NA's
  YFDP_dbh<-aggregate(YFDP_Tree$DBH,by=list(YFDP_Tree$STEM_TAG, YFDP_Tree$CENSUS),FUN=function(x) return((x)))
  YFDP_dbh<-YFDP_dbh[is.na(YFDP_dbh$x)==F,]
  YFDP_dbh<-YFDP_dbh[order(YFDP_dbh$Group.1,YFDP_dbh$Group.2),]
  colnames(YFDP_dbh) <- c('STEM_TAG','CENSUS','DBH')
  YFDP_dbh<-aggregate(YFDP_dbh$DBH,by=list(YFDP_dbh$STEM_TAG),FUN=function(x) return(max(x)))
  YFDP_dbh<-YFDP_dbh[order(YFDP_dbh$Group.1),]
  colnames(YFDP_dbh) <- c('STEM_TAG','DBH')
  YFDP_dbh <- YFDP_dbh[YFDP_dbh$STEM_TAG %in% YFDP_Final[is.na(YFDP_Final$DBH)==T,'STEM_TAG'],]
  
  YFDP_Final <- merge(YFDP_dbh,YFDP_Final,by=c('STEM_TAG'), all.y=T)
  YFDP_Final$DBH <- ifelse(is.na(YFDP_Final$DBH.y)==T,YFDP_Final$DBH.x,YFDP_Final$DBH.y)
  YFDP_Final <- YFDP_Final[,-which(names(YFDP_Final) %in% c('DBH.x','DBH.y'))] 
  head(YFDP_Final[is.na(YFDP_Final$DBH)==T,]) # check for missing DBH. These are all seedlings
  
  ############
  
  UFDP_inyr<-aggregate(UFDP_Tree$CENSUS,by=list(UFDP_Tree$STEM_TAG),FUN=function(x) return(min(x)))
  colnames(UFDP_inyr) <- c('STEM_TAG','IN_YR')
  
  UFDP_sum<-aggregate(UFDP_inyr,by=list(UFDP_inyr$IN_YR),FUN=NROW)
  
  UFDP_tot<-aggregate(UFDP_Tree$CENSUS,by=list(UFDP_Tree$STEM_TAG),FUN=function(x) return(max(x)))
  colnames(UFDP_tot) <- c('STEM_TAG','CENSUS')
  
  UFDP_temp <- merge(UFDP_Tree,UFDP_tot, by=c('STEM_TAG','CENSUS'), all.y = T)
  UFDP_Final <- merge(UFDP_temp,UFDP_inyr[,c('STEM_TAG','IN_YR')], by='STEM_TAG', all.x = T)
  
  nrow(UFDP_Final) == sum(UFDP_sum$IN_YR) # this is all trees that were ever in the dataset. Should match total for final UFDP treelist
  head(UFDP_Final[is.na(UFDP_Final$DBH)==T,]) # check for missing DBH - these are all seedlings.
  
  ############
  
  WFDP_Tree <- WFDP_Tree[,-which(names(WFDP_Tree) %in% c('IN_YR'))] # this was calculated in a different way. Replace for consistency
  WFDP_Tree <- WFDP_Tree[WFDP_Tree$COMMENT != "CWD at establishment",]
  WFDP_inyr<-aggregate(WFDP_Tree$CENSUS,by=list(WFDP_Tree$STEM_TAG),FUN=function(x) return(min(x)))
  colnames(WFDP_inyr) <- c('STEM_TAG','IN_YR')
  
  WFDP_sum<-aggregate(WFDP_inyr,by=list(WFDP_inyr$IN_YR),FUN=NROW)
  
  WFDP_tot<-aggregate(WFDP_Tree$CENSUS,by=list(WFDP_Tree$STEM_TAG),FUN=function(x) return(max(x)))
  colnames(WFDP_tot) <- c('STEM_TAG','CENSUS')
  
  WFDP_temp <- merge(WFDP_Tree,WFDP_tot, by=c('STEM_TAG','CENSUS'), all.y = T)
  WFDP_Final <- merge(WFDP_temp,WFDP_inyr[,c('STEM_TAG','IN_YR')], by='STEM_TAG', all.x = T)
  
  nrow(WFDP_Final) == sum(WFDP_sum$IN_YR) # this is all trees that were ever in the dataset. Should match total for final WFDP treelist
  head(WFDP_Final[is.na(WFDP_Final$DBH)==T,]) # check for missing DBH. These are seedlings.
  
  ####
  
  for (i in 1:nrow(UFDP_Final)){
    UFDP_Final[i,'PLOT_X'] <- UFDP_Final[i,'UTM_X'] - min(UFDP_Final$UTM_X)
    UFDP_Final[i,'PLOT_Y'] <- UFDP_Final[i,'UTM_Y'] - min(UFDP_Final$UTM_Y)}
  
  WFDP_Final<-WFDP_Final[is.na(WFDP_Final$DBH)==F&is.na(WFDP_Final$SPECIES)==F&
                           is.na(WFDP_Final$PLOT_X)==F&is.na(WFDP_Final$PLOT_Y)==F,]
  UFDP_Final<-UFDP_Final[is.na(UFDP_Final$DBH)==F&is.na(UFDP_Final$SPECIES)==F&
                           is.na(UFDP_Final$PLOT_X)==F&is.na(UFDP_Final$PLOT_Y)==F,]
  YFDP_Final<-YFDP_Final[is.na(YFDP_Final$DBH)==F&is.na(YFDP_Final$SPECIES)==F&
                           is.na(YFDP_Final$PLOT_X)==F&is.na(YFDP_Final$PLOT_Y)==F,]
  
  WFDP_Final<-merge(WFDP_Final,guild_designations,by="SPECIES")
  UFDP_Final<-merge(UFDP_Final,guild_designations,by="SPECIES")
  YFDP_Final<-merge(YFDP_Final,guild_designations,by="SPECIES")
  
  #### for table 1 ###
  # WFDP_Final$PLOT <- 1
  # YFDP_Final$PLOT <- 2
  # UFDP_Final$PLOT <- 3
  # final <- rbind(WFDP_Final[!duplicated(WFDP_Final$STEM_TAG) & (is.na(WFDP_Final$MORT_DATE)==T|(is.na(WFDP_Final$MORT_DATE)==F & WFDP_Final$MORT_DATE >0)),c('PLOT','STEM_TAG','CENSUS','DA','IN_YR','MORT_DATE','SPECIES','GUILD','DBH')],
  #                UFDP_Final[!duplicated(UFDP_Final$STEM_TAG) & (is.na(UFDP_Final$MORT_DATE)==T|(is.na(UFDP_Final$MORT_DATE)==F & UFDP_Final$MORT_DATE >0)),c('PLOT','STEM_TAG','CENSUS','DA','IN_YR','MORT_DATE','SPECIES','GUILD','DBH')],
  #                YFDP_Final[!duplicated(YFDP_Final$STEM_TAG) & (is.na(YFDP_Final$MORT_DATE)==T|(is.na(YFDP_Final$MORT_DATE)==F & YFDP_Final$MORT_DATE >0)),c('PLOT','STEM_TAG','CENSUS','DA','IN_YR','MORT_DATE','SPECIES','GUILD','DBH')])
  # final$DA <- ifelse(is.na(final$MORT_DATE),'A','D')
  # final$BA <- BA.function(final$DBH)
  # 
  # all.summary <- aggregate(final$STEM_TAG, by=list(final$PLOT,final$SPECIES), FUN=NROW)
  # all.summary$BA <- aggregate(final$BA, by=list(final$PLOT,final$SPECIES), FUN=sum)$x
  # all.summary$guild <- aggregate(final$GUILD, by=list(final$PLOT,final$SPECIES), FUN=function(x) unique(x))$x
  # all.summary$morts <- aggregate(final$DA=='D', by=list(final$PLOT,final$SPECIES), FUN=sum)$x
  # all.summary$survs <- aggregate(final$DA=='A', by=list(final$PLOT,final$SPECIES), FUN=sum)$x
  # 
  # write.csv(all.summary,file = "./Tables/All.plots.all.trees.csv",row.names = F)

  ##################### put into long format so each year has one row ######################-
  
  time.max <- 2019
  
  ################## WFDP ###################-
  timeframe<-(time.max+1)-2012
  
  WFDP_long<-WFDP_Final[!duplicated(WFDP_Final$STEM_TAG),c('STEM_TAG','CENSUS','DA','IN_YR','MORT_DATE','SPECIES_NUM','GUILD_NUM','DBH',"PLOT_X","PLOT_Y")]
  WFDP_long<-do.call("rbind", replicate(timeframe, WFDP_long, simplify = FALSE))
  nrows<-nrow(WFDP_long)
  WFDP_long<-WFDP_long[order(WFDP_long$STEM_TAG),]
  
  WFDP_long$CENSUS<-rep(paste(2012:time.max),(nrows/timeframe))
  WFDP_long$CENSUS<-as.numeric(WFDP_long$CENSUS)
  WFDP_long<-WFDP_long[order(WFDP_long$STEM_TAG),]
  
  #set DA to change to dead in year that tree died, then remove subsequent years for dead trees
  WFDP_long$DA<-0
  WFDP_long[is.na(WFDP_long$MORT_DATE)==F&WFDP_long$CENSUS>=WFDP_long$MORT_DATE,'DA']<-1
  WFDP_long<-WFDP_long[(is.na(WFDP_long$MORT_DATE)==F&WFDP_long$CENSUS<=WFDP_long$MORT_DATE)|is.na(WFDP_long$MORT_DATE)==T,]
  
  #reflect ingrowth dates
  WFDP_long[WFDP_long$IN_YR==12&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2011
  WFDP_long[WFDP_long$IN_YR==13&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2012
  WFDP_long[WFDP_long$IN_YR==14&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2013
  WFDP_long[WFDP_long$IN_YR==15&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2014
  WFDP_long[WFDP_long$IN_YR==16&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2015
  WFDP_long[WFDP_long$IN_YR==17&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2016
  WFDP_long[WFDP_long$IN_YR==18&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2017
  WFDP_long[WFDP_long$IN_YR==19&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2018
  WFDP_long[WFDP_long$IN_YR==20&is.na(WFDP_long$IN_YR)==F,'IN_YR']<-2019
  WFDP_long<-WFDP_long[(is.na(WFDP_long$IN_YR)==F&WFDP_long$CENSUS>=WFDP_long$IN_YR)|is.na(WFDP_long$IN_YR)==T,]
  
  # WFDP_long[duplicated(WFDP_long[,c("STEM_TAG","CENSUS")]),] # make sure no duplicate rows (i.e. duplicated census / stem_teg combos)
  # head(WFDP_long[WFDP_long$IN_YR>2011 & is.na(WFDP_long$MORT_DATE)==F,],50) # make sure trees come and go in right years
  
  ################## YFDP ###################-
  timeframe<-(time.max+1)-2011
  
  YFDP_long<-YFDP_Final[!duplicated(YFDP_Final$STEM_TAG),c('STEM_TAG','CENSUS','DA','IN_YR','MORT_DATE','SPECIES_NUM','GUILD_NUM','DBH',"PLOT_X","PLOT_Y")]
  YFDP_long<-do.call("rbind", replicate(timeframe, YFDP_long, simplify = FALSE))
  nrows<-nrow(YFDP_long)
  YFDP_long<-YFDP_long[order(YFDP_long$STEM_TAG),]
  
  YFDP_long$CENSUS<-rep(paste(2011:time.max),(nrows/timeframe))
  YFDP_long$CENSUS<-as.numeric(YFDP_long$CENSUS)
  YFDP_long<-YFDP_long[order(YFDP_long$STEM_TAG),]
  
  #set DA to change to dead in year that tree died, then remove subsequent years for dead trees
  YFDP_long$DA<-0
  YFDP_long[is.na(YFDP_long$MORT_DATE)==F&YFDP_long$CENSUS>=YFDP_long$MORT_DATE,'DA']<-1
  YFDP_long<-YFDP_long[(is.na(YFDP_long$MORT_DATE)==F&YFDP_long$CENSUS<=YFDP_long$MORT_DATE)|is.na(YFDP_long$MORT_DATE)==T,]
  
  #reflect ingrowth dates
  YFDP_long[YFDP_long$IN_YR==1&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2010
  YFDP_long[YFDP_long$IN_YR==2&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2011
  YFDP_long[YFDP_long$IN_YR==3&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2012
  YFDP_long[YFDP_long$IN_YR==4&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2013
  YFDP_long[YFDP_long$IN_YR==5&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2014
  YFDP_long[YFDP_long$IN_YR==6&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2015
  YFDP_long[YFDP_long$IN_YR==7&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2016
  YFDP_long[YFDP_long$IN_YR==8&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2017
  YFDP_long[YFDP_long$IN_YR==9&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2018
  YFDP_long[YFDP_long$IN_YR==10&is.na(YFDP_long$IN_YR)==F,'IN_YR']<-2019
  YFDP_long<-YFDP_long[(is.na(YFDP_long$IN_YR)==F&YFDP_long$CENSUS>=YFDP_long$IN_YR)|is.na(YFDP_long$IN_YR)==T,]
  
  ################## UFDP ###################-
  timeframe<-(time.max+1)-2015
  
  UFDP_long<-UFDP_Final[!duplicated(UFDP_Final$STEM_TAG),c('STEM_TAG','CENSUS','DA','IN_YR','MORT_DATE','SPECIES_NUM','GUILD_NUM','DBH',"PLOT_X","PLOT_Y")]
  UFDP_long<-do.call("rbind", replicate(timeframe, UFDP_long, simplify = FALSE))
  nrows<-nrow(UFDP_long)
  UFDP_long<-UFDP_long[order(UFDP_long$STEM_TAG),]
  
  UFDP_long$CENSUS<-rep(paste(2015:time.max),(nrows/timeframe))
  UFDP_long$CENSUS<-as.numeric(UFDP_long$CENSUS)
  UFDP_long<-UFDP_long[order(UFDP_long$STEM_TAG),]
  
  #set DA to change to dead in year that tree died, then remove subsequent years for dead trees
  UFDP_long$DA<-0
  UFDP_long[is.na(UFDP_long$MORT_DATE)==F&UFDP_long$CENSUS>=UFDP_long$MORT_DATE,'DA']<-1
  UFDP_long<-UFDP_long[(is.na(UFDP_long$MORT_DATE)==F&UFDP_long$CENSUS<=UFDP_long$MORT_DATE)|is.na(UFDP_long$MORT_DATE)==T,]
  
  #reflect ingrowth dates
  UFDP_long[UFDP_long$IN_YR==1&is.na(UFDP_long$IN_YR)==F,'IN_YR']<-2015
  UFDP_long[UFDP_long$IN_YR==2&is.na(UFDP_long$IN_YR)==F,'IN_YR']<-2016
  UFDP_long[UFDP_long$IN_YR==3&is.na(UFDP_long$IN_YR)==F,'IN_YR']<-2017
  UFDP_long[UFDP_long$IN_YR==4&is.na(UFDP_long$IN_YR)==F,'IN_YR']<-2018
  UFDP_long[UFDP_long$IN_YR==5&is.na(UFDP_long$IN_YR)==F,'IN_YR']<-2019
  UFDP_long<-UFDP_long[(is.na(UFDP_long$IN_YR)==F&UFDP_long$CENSUS>=UFDP_long$IN_YR)|is.na(UFDP_long$IN_YR)==T,]
  
  #########################################################################################-
  
  plots <- c('WFDP_long','UFDP_long','YFDP_long')
}

### ---------------------- CALCULATE NEIGHBORHOOD ---------------------- ###
neighborhood.size <- c(5,10,15,20)

if(RUN.NEIGHBORHOOD==T){
  ptm <- proc.time()
  
  for(x in c('ericoidSAME.bothDIFF','ericoidDIFF.bothSAME','ericoidSAME.bothSAME')){ # species guild assignments considered
    
    if(x == 'ericoidSAME.bothDIFF'){
      ERICOID.SAME=T      
      BOTH.SAME=F          
    } else if(x == 'ericoidDIFF.bothSAME'){
      ERICOID.SAME=F       
      BOTH.SAME=T          
    } else if(x == 'ericoidSAME.bothSAME'){
      ERICOID.SAME=T       
      BOTH.SAME=T          
    } 

  for(z in plots){
    
    datt <- eval(parse(text=z))
    # neighbor.matrix <- matrix(nrow=nrow(datt), ncol=14*length(neighborhood.size))
    neighbor.matrix <- matrix(nrow=nrow(datt), ncol=4*length(neighborhood.size))
    colnames(neighbor.matrix) <- names(Myco.DD(data.row = datt[1, ], plot.data = datt, neighborhood.size = neighborhood.size))
    
    for( i in 1:nrow(datt) ){    # start the for loop, which will run through each tree
      cat("Calculating neighborhood for stem", i, "out of", nrow(datt), (proc.time()-ptm)[3], "seconds" , "\n", sep=" " )
      neighbor.matrix[i,] <- unlist(Myco.DD(data.row = datt[i, ], plot.data = datt, neighborhood.size = neighborhood.size))
    }
    
    datt <- cbind(datt,neighbor.matrix)
    assign(paste(z,'neighbors',sep='.'),datt)
    rm(datt)
    rm(neighbor.matrix)
  }
  
  save.image(file=paste('./Data_Setup/Data_Outputs/All.neighbors.global.environment',x,'DENSITYonly',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
}

}

##########################################################################################################

##########################################################################################################-
######################################       FINAL CONFIGURATIONS       ##################################-
#----------------------------------------------------------------------------------------------------------

### ---------------------- MERGE ALL PLOTS ---------------------- ###

for(x in c('ericoidSAME.bothDIFF','ericoidDIFF.bothSAME','ericoidSAME.bothSAME')){ # species guild assignments considered
  print(paste('Now on: ',x,sep = ''))
  
if(LOAD.NEIGHBORS==T){
  load(file='./Data_Setup/Data_Outputs/All.neighbors.global.environment.ericoidDIFF.bothDIFF.20200929.Rdata') #20200412 misspelled HODI, did not count; 20200812 is final for ericoid diff; 20200928 is final for ericoid same/both same
  # load(file=paste('./Data_Setup/Data_Outputs/All.neighbors.global.environment.',x,'.DENSITYonly.20201026.Rdata', sep='' )) #20200412 misspelled HODI, did not count; 20200812 is final for ericoid diff; 20200928 is final for ericoid same/both same
}

WFDP.neighbors<-WFDP_long.neighbors
YFDP.neighbors<-YFDP_long.neighbors
UFDP.neighbors<-UFDP_long.neighbors

WFDP.neighbors$PLOT <- 'WFDP'
YFDP.neighbors$PLOT <- 'YFDP'
UFDP.neighbors$PLOT <- 'UFDP'

WFDP_Mortality<-read.csv("./Data_Setup/Raw_Data/WFDP_Mortality.csv",na.strings='NULL')
UFDP_Mortality<-read.csv("./Data_Setup/Raw_Data/UFDP_Mortality.csv",na.strings='NULL')
YFDP_Mortality<-read.csv("./Data_Setup/Raw_Data/YFDP_Mortality.csv",na.strings='NULL')

WFDP_Mortality$STEM_TAG <- as.character(WFDP_Mortality$STEM_TAG)
UFDP_Mortality$STEM_TAG <- as.character(UFDP_Mortality$STEM_TAG)
YFDP_Mortality$STEM_TAG <- as.character(YFDP_Mortality$STEM_TAG)


## do not consider fire or mechanical mortalities, subdivide by agent type if desired
{
  WFDP.neighbors.all <- WFDP.neighbors[(WFDP.neighbors$DA == 1 & WFDP.neighbors$STEM_TAG%in% 
                                        WFDP_Mortality[is.na(WFDP_Mortality$FAD1)==F &
                                                         !WFDP_Mortality$FAD1 %in% c(68,90:100) &
                                                         (WFDP_Mortality$FAD1 %in% c(40:65,70:73)|
                                                            WFDP_Mortality$FAD2 %in% c(40:65,70:73)|
                                                            WFDP_Mortality$FAD3 %in% c(40:65,70:73)|
                                                            WFDP_Mortality$FAD4 %in% c(40:65,70:73)|
                                                            WFDP_Mortality$FAD5 %in% c(40:65,70:73)),'STEM_TAG'])|
                                       (WFDP.neighbors$DA == 0 & WFDP.neighbors$STEM_TAG%in% 
                                          WFDP_Mortality[is.na(WFDP_Mortality$FAD1)==F &
                                                           !WFDP_Mortality$FAD1 %in% c(68,90:100) &
                                                           (WFDP_Mortality$FAD1 %in% c(40:65,70:73)|
                                                              WFDP_Mortality$FAD2 %in% c(40:65,70:73)|
                                                              WFDP_Mortality$FAD3 %in% c(40:65,70:73)|
                                                              WFDP_Mortality$FAD4 %in% c(40:65,70:73)|
                                                              WFDP_Mortality$FAD5 %in% c(40:65,70:73)),'STEM_TAG'])|
                                       (WFDP.neighbors$DA == 0 & !WFDP.neighbors$STEM_TAG%in%WFDP_Mortality$STEM_TAG),]

YFDP.neighbors.all <- YFDP.neighbors[(YFDP.neighbors$DA == 1 & YFDP.neighbors$STEM_TAG%in% 
                                        YFDP_Mortality[is.na(YFDP_Mortality$FAD1)==F &
                                                         !YFDP_Mortality$FAD1 %in% c(68,90:100) &
                                                         (YFDP_Mortality$FAD1 %in% c(40:65,70:73)|
                                                            YFDP_Mortality$FAD2 %in% c(40:65,70:73)|
                                                            YFDP_Mortality$FAD3 %in% c(40:65,70:73)|
                                                            YFDP_Mortality$FAD4 %in% c(40:65,70:73)|
                                                            YFDP_Mortality$FAD5 %in% c(40:65,70:73)),'STEM_TAG'])|
                                       (YFDP.neighbors$DA == 0 & YFDP.neighbors$STEM_TAG%in% 
                                          YFDP_Mortality[is.na(YFDP_Mortality$FAD1)==F &
                                                           !YFDP_Mortality$FAD1 %in% c(68,90:100) &
                                                           (YFDP_Mortality$FAD1 %in% c(40:65,70:73)|
                                                              YFDP_Mortality$FAD2 %in% c(40:65,70:73)|
                                                              YFDP_Mortality$FAD3 %in% c(40:65,70:73)|
                                                              YFDP_Mortality$FAD4 %in% c(40:65,70:73)|
                                                              YFDP_Mortality$FAD5 %in% c(40:65,70:73)),'STEM_TAG'])|
                                       (YFDP.neighbors$DA == 0 & !YFDP.neighbors$STEM_TAG%in%YFDP_Mortality$STEM_TAG),]

UFDP.neighbors.all <- UFDP.neighbors[(UFDP.neighbors$DA == 1 & UFDP.neighbors$STEM_TAG%in% 
                                        UFDP_Mortality[is.na(UFDP_Mortality$FAD1)==F &
                                                         !UFDP_Mortality$FAD1 %in% c(68,90:100) &
                                                         (UFDP_Mortality$FAD1 %in% c(40:65,70:73)|
                                                            UFDP_Mortality$FAD2 %in% c(40:65,70:73)|
                                                            UFDP_Mortality$FAD3 %in% c(40:65,70:73)|
                                                            UFDP_Mortality$FAD4 %in% c(40:65,70:73)|
                                                            UFDP_Mortality$FAD5 %in% c(40:65,70:73)),'STEM_TAG'])|
                                       (UFDP.neighbors$DA == 0 & UFDP.neighbors$STEM_TAG%in% 
                                          UFDP_Mortality[is.na(UFDP_Mortality$FAD1)==F &
                                                           !UFDP_Mortality$FAD1 %in% c(68,90:100) &
                                                           (UFDP_Mortality$FAD1 %in% c(40:65,70:73)|
                                                              UFDP_Mortality$FAD2 %in% c(40:65,70:73)|
                                                              UFDP_Mortality$FAD3 %in% c(40:65,70:73)|
                                                              UFDP_Mortality$FAD4 %in% c(40:65,70:73)|
                                                              UFDP_Mortality$FAD5 %in% c(40:65,70:73)),'STEM_TAG'])|
                                       (UFDP.neighbors$DA == 0 & !UFDP.neighbors$STEM_TAG%in%UFDP_Mortality$STEM_TAG),]
}

# give unique identifier (most important for when plot is not used as grouping variable...)
WFDP.neighbors.all$ID <- paste(substr(WFDP.neighbors.all$STEM_TAG,1,2),substr(WFDP.neighbors.all$STEM_TAG,4,7),'W',sep='')
YFDP.neighbors.all$ID <- paste(substr(YFDP.neighbors.all$STEM_TAG,1,2),substr(YFDP.neighbors.all$STEM_TAG,4,7),'Y',sep='')
UFDP.neighbors.all$ID <- paste(substr(UFDP.neighbors.all$STEM_TAG,1,2),substr(UFDP.neighbors.all$STEM_TAG,4,7),'U',sep='')


### to get table 1 info,  adjust datt to include all individuals (don't remove mortalities, but do remove duplicates)
# WFDP.neighbors$ID <- paste(substr(WFDP.neighbors$STEM_TAG,1,2),substr(WFDP.neighbors$STEM_TAG,4,7),'W',sep='')
# YFDP.neighbors$ID <- paste(substr(YFDP.neighbors$STEM_TAG,1,2),substr(YFDP.neighbors$STEM_TAG,4,7),'Y',sep='')
# UFDP.neighbors$ID <- paste(substr(UFDP.neighbors$STEM_TAG,1,2),substr(UFDP.neighbors$STEM_TAG,4,7),'U',sep='')
# datt.sum <- rbind(WFDP.neighbors,YFDP.neighbors,UFDP.neighbors)
# datt.sum <- datt.sum[!duplicated(datt.sum$ID),]
# datt.sum$BA <- BA.function(datt.sum$DBH)
# datt.sum <- merge(datt.sum,guild_designations[,c("SPECIES_NUM","SPECIES","GUILD")], by = "SPECIES_NUM")
# all.summary <- aggregate(datt.sum$STEM_TAG, by=list(datt.sum$PLOT,datt.sum$SPECIES), FUN=NROW)
# all.summary$BA <- aggregate(round(datt.sum$BA,5), by=list(datt.sum$PLOT,datt.sum$SPECIES), FUN=sum)$x
# all.summary<-all.summary[order(all.summary$Group.1),]
# write.csv(all.summary,file = "./Tables/allindivids_allspp_data_20200928.csv",row.names = F)
# sum(all.summary$BA)

## remake "datt"s with whatever neighbors you want from above
datt <- rbind(WFDP.neighbors.all,YFDP.neighbors.all,UFDP.neighbors.all)
{
  datt <- merge(datt,guild_designations[,c("SPECIES_NUM","SPECIES","GUILD")], by = "SPECIES_NUM")
  datt <- datt[order(datt$PLOT,datt$ID,datt$CENSUS),]
  
  ## take out trees with only 1 line (those ingrowthed in the very last census for each plot)
  datt2 <- datt[(datt$PLOT=='UFDP' & (is.na(datt$IN_YR)==F & datt$IN_YR<max(datt[datt$PLOT=='UFDP','CENSUS'])) | is.na(datt$IN_YR)==T)|
                  (datt$PLOT=='YFDP' & (is.na(datt$IN_YR)==F & datt$IN_YR<max(datt[datt$PLOT=='YFDP','CENSUS'])) | is.na(datt$IN_YR)==T)|
                  (datt$PLOT=='WFDP' & (is.na(datt$IN_YR)==F & datt$IN_YR<max(datt[datt$PLOT=='WFDP','CENSUS'])) | is.na(datt$IN_YR)==T),]
  
  # omit trees representing the only stem of a species
  {
    min.num <- 2 # min number of stems per species/plot needs to be represented

    WFDP.alone <- aggregate(WFDP_Final$STEM_TAG,by=list(WFDP_Final$SPECIES),FUN=NROW)
    WFDP.alone <- WFDP.alone[WFDP.alone$x<min.num,]
    WFDP.alone$Group.1 <- as.character(WFDP.alone$Group.1)

    UFDP.alone <- aggregate(UFDP_Final$STEM_TAG,by=list(UFDP_Final$SPECIES),FUN=NROW)
    UFDP.alone <- UFDP.alone[UFDP.alone$x<min.num,]
    UFDP.alone$Group.1 <- as.character(UFDP.alone$Group.1)

    YFDP.alone <- aggregate(YFDP_Final$STEM_TAG,by=list(YFDP_Final$SPECIES),FUN=NROW)
    YFDP.alone <- YFDP.alone[YFDP.alone$x<min.num,]
    YFDP.alone$Group.1 <- as.character(YFDP.alone$Group.1)
    
  datt2 <- datt2[(datt2$PLOT == 'WFDP' & (!datt2$SPECIES %in% WFDP.alone$Group.1)) |
                   (datt2$PLOT == 'YFDP' & (!datt2$SPECIES %in% YFDP.alone$Group.1)) |
                   (datt2$PLOT == 'UFDP' & (!datt2$SPECIES %in% UFDP.alone$Group.1)),]
  # datt2<-datt2[!datt2$SPECIES %in% bad.spp$SPECIES,]
  small <- datt2[datt2$DBH <1 & datt2$DA==0,]
  datt2 <- datt2[!datt2$ID%in%small$ID,]
  }
}


### ---------------------- FINAL CONFIGURATION: SHORT FORMAT ---------------------- ###

# identify the last year per plot
datt2$lastyr <- ifelse(datt2$PLOT=='WFDP' & datt2$CENSUS == max(datt2[datt2$PLOT=='WFDP','CENSUS']),1,
                         ifelse(datt2$PLOT=='YFDP' & datt2$CENSUS == max(datt2[datt2$PLOT=='YFDP','CENSUS']),1,
                                ifelse(datt2$PLOT=='UFDP' & datt2$CENSUS == max(datt2[datt2$PLOT=='UFDP','CENSUS']),1,0)))

# make a shortened dataset with only one row per individual, where that row is either the year it died, or the final year of the dataset per plot
datt2 <- datt2[datt2$DA == 1 | (datt2$DA == 0 & datt2$lastyr == 1),]

# too.few.spp <- aggregate(datt2$ID, by = list(datt2$PLOT, datt2$SPECIES_NUM), FUN = NROW)
# too.few.spp <- too.few.spp[too.few.spp$x > 20,] # omit species with too few individuals per plot to draw meaningful conclusions. NOT RUN - this will shake out in analysis code

# datt3 <- datt2[(datt2$PLOT == 'WFDP' & datt2$SPECIES_NUM %in% too.few.spp[too.few.spp$Group.1 == 'WFDP','Group.2']) |
#                         (datt2$PLOT == 'YFDP' & datt2$SPECIES_NUM %in% too.few.spp[too.few.spp$Group.1 == 'YFDP','Group.2']) |
#                         (datt2$PLOT == 'UFDP' & datt2$SPECIES_NUM %in% too.few.spp[too.few.spp$Group.1 == 'UFDP','Group.2']),]
datt3<-datt2
datt3$PLOT <- ifelse(datt3$PLOT == 'WFDP', 1,
                          ifelse(datt3$PLOT == 'YFDP', 2,
                                 ifelse(datt3$PLOT == 'UFDP', 3, NA)))
datt3[datt3$SPECIES == 'PSME' & datt3$PLOT == 1,'SPECIES'] <- 'PSME.M'
datt3[datt3$SPECIES == 'PSME' & datt3$PLOT == 2,'SPECIES'] <- 'PSME.M'
datt3[datt3$SPECIES == 'PSME' & datt3$PLOT == 3,'SPECIES'] <- 'PSME.G'
datt3[datt3$SPECIES == 'SARA' & datt3$PLOT == 2,'SPECIES'] <- 'SACE'
datt3$SPECIES_NUM <- as.numeric(as.factor(datt3$SPECIES)) # renumber
datt3$BA <- BA.function(datt3$DBH)

### ---------------------- CENTER / STANDARDIZE ---------------------- ###

# variables <- c(grep('het.', colnames(datt3), fixed = TRUE, value = TRUE),
# grep('con.', colnames(datt3), fixed = TRUE, value = TRUE))

variables <- c(grep('den.', colnames(datt3), fixed = TRUE, value = TRUE))

if(CENTER.HEGYI==T){
  print('Centering Hegyi')
  
  tree <- datt3
  tree$DBH_BIN <- NA
  tree$DBH_BIN<-mround(tree$DBH,2)
  tree[tree$DBH>=10,'DBH_BIN']<-mround(tree[tree$DBH>=10,'DBH_BIN'],10)
  tree[tree$DBH>=40,'DBH_BIN']<-mround(tree[tree$DBH>=40,'DBH_BIN'],20)
  tree[tree$DBH>=100,'DBH_BIN']<-100
  
  for(i in variables){
    tree[is.na(tree[,i])==T,i]<-0
    
    #get mean for centering hegyi by spp / size class
    tree.gr.summary<-aggregate(tree[,i], by=list(tree$SPECIES,tree$DBH_BIN,tree$PLOT), FUN=mean)
    tree.gr.summary$count<-aggregate(tree[,i], by=list(tree$SPECIES,tree$DBH_BIN,tree$PLOT),FUN=NROW)$x
    
    for(j in 1:nrow(tree)){  
      tree[j,i] <-  center(tree[j,i], tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&
                                                        tree.gr.summary$Group.2==tree[j,'DBH_BIN']&
                                                        tree.gr.summary$Group.3==tree[j,'PLOT'],'x'])
    }  
  }
  
}


tree$DBH <- log(tree$DBH)

## cut off edge trees / create dataframes per radii
for(n in neighborhood.size){
  assign(paste('final.datt',n,sep='.'), tree[(tree$PLOT==3 & 
                        tree$PLOT_X<(max(tree[tree$PLOT==3,'PLOT_X'])-n) & 
                        tree$PLOT_Y<(max(tree[tree$PLOT==3,'PLOT_Y'])-n) &
                        tree$PLOT_X>(min(tree[tree$PLOT==3,'PLOT_X'])+n) & 
                        tree$PLOT_Y>(min(tree[tree$PLOT==3,'PLOT_Y'])+n))|
                       (tree$PLOT==1 & 
                          tree$PLOT_X<(max(tree[tree$PLOT==1,'PLOT_X'])-n) & 
                          tree$PLOT_Y<(max(tree[tree$PLOT==1,'PLOT_Y'])-n) &
                          tree$PLOT_X>(min(tree[tree$PLOT==1,'PLOT_X'])+n) & 
                          tree$PLOT_Y>(min(tree[tree$PLOT==1,'PLOT_Y'])+n))|
                       (tree$PLOT==2 & 
                          tree$PLOT_X<(max(tree[tree$PLOT==2,'PLOT_X'])-n) & 
                          tree$PLOT_Y<(max(tree[tree$PLOT==2,'PLOT_Y'])-n) &
                          tree$PLOT_X>(min(tree[tree$PLOT==2,'PLOT_X'])+n) & 
                          tree$PLOT_Y>(min(tree[tree$PLOT==2,'PLOT_Y'])+n)),])
}

## hard coded ##
# final.datt.5 <- final.datt.5[,c("PLOT","STEM_TAG","ID","CENSUS","DA","IN_YR","MORT_DATE","DBH","DBH_BIN","SPECIES","SPECIES_NUM","GUILD_NUM","GUILD","con.5","het.diff.5","het.same.5","richness.5","rich.diff.5","rich.same.5","PLOT_X","PLOT_Y")]
# final.datt.10 <- final.datt.10[,c("PLOT","STEM_TAG","ID","CENSUS","DA","IN_YR","MORT_DATE","DBH","DBH_BIN","SPECIES","SPECIES_NUM","GUILD_NUM","GUILD","con.10","het.diff.10","het.same.10","richness.10","rich.diff.10","rich.same.10","PLOT_X","PLOT_Y")]
# final.datt.15 <- final.datt.15[,c("PLOT","STEM_TAG","ID","CENSUS","DA","IN_YR","MORT_DATE","DBH","DBH_BIN","SPECIES","SPECIES_NUM","GUILD_NUM","GUILD","con.15","het.diff.15","het.same.15","richness.15","rich.diff.15","rich.same.15","PLOT_X","PLOT_Y")]
# final.datt.20 <- final.datt.20[,c("PLOT","STEM_TAG","ID","CENSUS","DA","IN_YR","MORT_DATE","DBH","DBH_BIN","SPECIES","SPECIES_NUM","GUILD_NUM","GUILD","con.20","het.diff.20","het.same.20","richness.20","rich.diff.20","rich.same.20","PLOT_X","PLOT_Y")]

# ## do not reduce dataset by "too small", "too few", or ericaceous spp to make this "full" file
# all.summary <- aggregate(final.datt.20$STEM_TAG, by=list(final.datt.20$PLOT,final.datt.20$SPECIES), FUN=NROW)
# all.summary$BA <- aggregate(final.datt.20$BA, by=list(final.datt.20$PLOT,final.datt.20$SPECIES), FUN=sum)$x
# all.summary$guild <- aggregate(final.datt.20$GUILD, by=list(final.datt.20$PLOT,final.datt.20$SPECIES), FUN=function(x) unique(x))$x
# write.csv(all.summary,file = "./Tables/All.plots.20m.analyzed.Hegyi.all.trees.20201102.csv",row.names = F) ## not used, use the previous csv file instead (all trees, all spp)

print('Saving....')

save(final.datt.5,file=paste('./Data_Setup/Data_Outputs/All.plots.5m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep='' ))
save(final.datt.10,file=paste('./Data_Setup/Data_Outputs/All.plots.10m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep='' ))
save(final.datt.15,file=paste('./Data_Setup/Data_Outputs/All.plots.15m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep='' ))
save(final.datt.20,file=paste('./Data_Setup/Data_Outputs/All.plots.20m.Hegyi.all.centered.',x,'.DENSITYonly.20201020.Rdata', sep='' ))

}


##########################################################################################################

##########################################################################################################-
####################################      CREATE AGENT-BASED SUBSETS      ################################-
#----------------------------------------------------------------------------------------------------------

if(RUN.SPECIALISTS==T){
  final.datt.spec <- final.datt[(final.datt$PLOT == 1 & ( final.datt$DA == 0 |
                                                            (final.datt$DA == 1 & final.datt$STEM_TAG%in% 
                                                               WFDP_Mortality[is.na(WFDP_Mortality$FAD1)==F &
                                                                                (WFDP_Mortality$FAD1 %in% c(63,70:73)|
                                                                                   WFDP_Mortality$FAD2 %in% c(63,70:73)|
                                                                                   WFDP_Mortality$FAD3 %in% c(63,70:73)|
                                                                                   WFDP_Mortality$FAD4 %in% c(63,70:73)|
                                                                                   WFDP_Mortality$FAD5 %in% c(63,70:73)),'STEM_TAG']) )) |
                                  (final.datt$PLOT == 2 & ( final.datt$DA == 0 |
                                                              (final.datt$DA == 1 & final.datt$STEM_TAG%in% 
                                                                 YFDP_Mortality[is.na(YFDP_Mortality$FAD1)==F &
                                                                                  (YFDP_Mortality$FAD1 %in% c(63,70:73)|
                                                                                     YFDP_Mortality$FAD2 %in% c(63,70:73)|
                                                                                     YFDP_Mortality$FAD3 %in% c(63,70:73)|
                                                                                     YFDP_Mortality$FAD4 %in% c(63,70:73)|
                                                                                     YFDP_Mortality$FAD5 %in% c(63,70:73)),'STEM_TAG']) )) |
                                  (final.datt$PLOT == 3 & ( final.datt$DA == 0 |
                                                              (final.datt$DA == 1 & final.datt$STEM_TAG%in% 
                                                                 UFDP_Mortality[is.na(UFDP_Mortality$FAD1)==F &
                                                                                  (UFDP_Mortality$FAD1 %in% c(63,70:73)|
                                                                                     UFDP_Mortality$FAD2 %in% c(63,70:73)|
                                                                                     UFDP_Mortality$FAD3 %in% c(63,70:73)|
                                                                                     UFDP_Mortality$FAD4 %in% c(63,70:73)|
                                                                                     UFDP_Mortality$FAD5 %in% c(63,70:73)),'STEM_TAG']) )) ,]
  
  final.datt.spec$SPECIES_NUM <- as.numeric(as.factor(final.datt.spec$SPECIES))
  save(final.datt.spec,file='./Data_Setup/Data_Outputs/All.plots.20m.Hegyi.spec.centered.Rdata') #made 20200506
}

if(RUN.GENERALISTS==T){
  final.datt.gen <- final.datt[(final.datt$PLOT == 1 & ( final.datt$DA == 0 |
                                         (final.datt$DA == 1 & final.datt$STEM_TAG%in% 
                                          WFDP_Mortality[is.na(WFDP_Mortality$FAD1)==F &
                                                           (WFDP_Mortality$FAD1 %in% c(40:65)|
                                                              WFDP_Mortality$FAD2 %in% c(40:65)|
                                                              WFDP_Mortality$FAD3 %in% c(40:65)|
                                                              WFDP_Mortality$FAD4 %in% c(40:65)|
                                                              WFDP_Mortality$FAD5 %in% c(40:65)),'STEM_TAG']) )) |
                                 (final.datt$PLOT == 2 & ( final.datt$DA == 0 |
                                                                 (final.datt$DA == 1 & final.datt$STEM_TAG%in% 
                                                                    YFDP_Mortality[is.na(YFDP_Mortality$FAD1)==F &
                                                                                     (YFDP_Mortality$FAD1 %in% c(40:65)|
                                                                                        YFDP_Mortality$FAD2 %in% c(40:65)|
                                                                                        YFDP_Mortality$FAD3 %in% c(40:65)|
                                                                                        YFDP_Mortality$FAD4 %in% c(40:65)|
                                                                                        YFDP_Mortality$FAD5 %in% c(40:65)),'STEM_TAG']) )) |
                                    (final.datt$PLOT == 3 & ( final.datt$DA == 0 |
                                                                    (final.datt$DA == 1 & final.datt$STEM_TAG%in% 
                                                                       UFDP_Mortality[is.na(UFDP_Mortality$FAD1)==F &
                                                                                        (UFDP_Mortality$FAD1 %in% c(40:65)|
                                                                                           UFDP_Mortality$FAD2 %in% c(40:65)|
                                                                                           UFDP_Mortality$FAD3 %in% c(40:65)|
                                                                                           UFDP_Mortality$FAD4 %in% c(40:65)|
                                                                                           UFDP_Mortality$FAD5 %in% c(40:65)),'STEM_TAG']) )) ,]
  final.datt.gen$SPECIES_NUM <- as.numeric(as.factor(final.datt.gen$SPECIES))
  save(final.datt.gen,file='./Data_Setup/Data_Outputs/All.plots.20m.Hegyi.gen.centered.Rdata') #made 20200506
}

##########################################################################################################

stop("SUCCESS! Run by hand from here")

##########################################################################################################-
##########################################       LOOK AT DATA       ######################################-
#----------------------------------------------------------------------------------------------------------

# ## check which species are rare - based on distributions + SD
min.num <- 2
datt.check <- datt.sum

check <- aggregate(datt.check$con.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=NROW)
check$con.sd <- aggregate(datt.check$con.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=sd)$x
check$con.mean <- aggregate(datt.check$con.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=mean)$x
names(check)[1:3] <- c('SPECIES','PLOT','n')

check$het.sd <- aggregate(datt.check$het.diff.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=sd)$x
check$het.mean <- aggregate(datt.check$het.diff.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=mean)$x

check$het.s.sd <- aggregate(datt.check$het.same.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=sd)$x
check$het.s.mean <- aggregate(datt.check$het.same.20,by=list(datt.check$SPECIES,datt.check$PLOT),FUN=mean)$x

check<-check[order(check$con.mean),]

bad.spp <- check[check$n < min.num,]

check <-check[!check$SPECIES %in% bad.spp$SPECIES,]

check$con.se <- check$con.sd / sqrt(check$n)
check$het.se <- check$het.sd / sqrt(check$n)
check$het.s.se <- check$het.s.sd / sqrt(check$n)

check[is.na(check)==T] <- 0

# plots
  barCenters <-  barplot(height = check$con.mean,
                         names.arg = check$SPECIES,
                         beside = true, las = 2,
                         cex.names = 0.75, xaxt = "n",
                         main = "",
                         border = "black", axes = TRUE)
  text(x = barCenters, y = par("usr")[3] - 1, srt = 60,
       adj = 1, labels = check$SPECIES, xpd = TRUE,cex=0.7)
  
  segments(barCenters, check$con.mean - check$con.se * 2, barCenters,
           check$con.mean + check$con.se * 2, lwd = 1.5)
  
  arrows(barCenters, check$con.mean - check$con.se * 2, barCenters,
         check$con.mean + check$con.se * 2, lwd = 1.5, angle = 90,
         code = 3, length = 0.05)
  
  dev.print(file=paste('./Figures/','conspecific_20_Distributions_2020','.tif',sep=''),tiff,width=7.25,height=4,res=600,units='in',compression='lzw')
  
  ####
  
  barCenters <-  barplot(height = check$het.mean,
                         names.arg = check$SPECIES,
                         beside = true, las = 2,
                         cex.names = 0.75, xaxt = "n",
                         ylim = c(0, 50),
                         main = "",
                         border = "black", axes = TRUE)
  text(x = barCenters, y = par("usr")[3] - 1, srt = 60,
       adj = 1, labels = check$SPECIES, xpd = TRUE,cex=0.7)
  
  segments(barCenters, check$het.mean - check$het.se * 2, barCenters,
           check$het.mean + check$het.se * 2, lwd = 1.5)
  
  arrows(barCenters, check$het.mean - check$het.se * 2, barCenters,
         check$het.mean + check$het.se * 2, lwd = 1.5, angle = 90,
         code = 3, length = 0.05)
  
  dev.print(file=paste('./Figures/','het.d.20_Distributions_2020','.tif',sep=''),tiff,width=7.25,height=4,res=600,units='in',compression='lzw')
  
  ####
  
  barCenters <-  barplot(height = check$het.s.mean,
                         names.arg = check$SPECIES,
                         beside = true, las = 2,
                         cex.names = 0.75, xaxt = "n",
                         ylim = c(0, 50),
                         main = "",
                         border = "black", axes = TRUE)
  text(x = barCenters, y = par("usr")[3] - 1, srt = 60,
       adj = 1, labels = check$SPECIES, xpd = TRUE,cex=0.7)
  
  segments(barCenters, check$het.s.mean - check$het.s.se * 2, barCenters,
           check$het.s.mean + check$het.s.se * 2, lwd = 1.5)
  
  arrows(barCenters, check$het.s.mean - check$het.s.se * 2, barCenters,
         check$het.s.mean + check$het.s.se * 2, lwd = 1.5, angle = 90,
         code = 3, length = 0.05)
  
  # dev.print(file=paste('./Figures/','het.s.20_Distributions_2020','.tif',sep=''),tiff,width=7.25,height=4,res=600,units='in',compression='lzw')
  
  ####

##########################################################################################################
